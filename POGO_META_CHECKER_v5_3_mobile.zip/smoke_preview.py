import subprocess,time,os
from pathlib import Path
from playwright.sync_api import sync_playwright
p=subprocess.Popen(['python','-m','http.server','8765','--bind','127.0.0.1'],cwd='/mnt/data/pogo-v5.3',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    time.sleep(.8)
    with sync_playwright() as b:
        browser=b.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
        page=browser.new_page(viewport={'width':1250,'height':980},device_scale_factor=1)
        errs=[]
        page.on('pageerror',lambda e:errs.append(str(e)))
        page.goto('http://127.0.0.1:8765/index.html',wait_until='domcontentloaded',timeout=25000)
        page.fill('#pkname','코코리')
        page.fill('#atk','15');page.fill('#def','14');page.fill('#hp','12')
        page.click('button#submit')
        page.wait_for_selector('.report-sheet',timeout=15000)
        headings=page.locator('.report-sheet h3').all_text_contents()
        details=page.locator('details.report-details')
        print('report_headings',headings)
        print('details_closed', not details.get_attribute('open'))
        print('heading',page.locator('#report-title').inner_text())
        print('errors',errs)
        page.locator('.report-sheet').screenshot(path='/mnt/data/POGO_META_v5_3_쉬운판정서_미리보기.png')
        details.locator('summary').click()
        print('details_open',details.get_attribute('open') is not None)
        browser.close()
finally:
    p.terminate();p.wait(timeout=10)
