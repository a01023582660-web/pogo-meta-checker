from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'app.js';s=p.read_text()
s=s.replace('/* POGO META v4.2 — deterministic, inspectable browser analyzer. No AI credentials required. */', '/* POGO META v5.0 — versioned snapshot + incremental meta change validation. */')
s=s.replace("busy:false};", "busy:false, metaIndex:null,metaChanges:null,metaVersion:null};")
s=s.replace("    const names=[p.id,p.en,spec.ko];", """    const names=[p.id,p.en,spec.ko,String(p.dex),'#'+p.dex];
    // Derived aliases for selected named battle forms. Never collapse a
    // decorated form into an ordinary form during rating lookup.
    const formNames={origin:'오리진',altered:'어나더',attack:'어택',defense:'디펜스',speed:'스피드',
      galarian:'가라르',alolan:'알로라',hisuian:'히스이',paldean:'팔데아',
      therian:'영물',incarnate:'화신',crowned_sword:'검왕',crowned_shield:'방패왕',
      hero:'역전의용사',sky:'스카이',land:'랜드',sunshine:'선샤인',midnight:'한밤중',
      dusk:'황혼',dawn_wings:'새벽의날개',dusk_mane:'황혼의갈기'};
    const suffix=p.id.split('_').slice(1).join('_').replace(/_shadow$/,'');
    if(spec.ko&&suffix){
      names.push(spec.ko+suffix);
      if(formNames[suffix])names.push(spec.ko+' '+formNames[suffix]);
    }""")
s=s.replace("  return found.find(x=>!x.id.includes('_shadow')&&!x.id.includes('_mega')&&!x.id.includes('_primal')&&!x.id.includes('_crowned'))||found[0]||null;",
"  return found.find(x=>!x.catalog_only&&!x.id.includes('_shadow')&&!x.id.includes('_mega')&&!x.id.includes('_primal')&&!x.id.includes('_crowned'))||found[0]||null;")
# Add string dex match uses numeric case stable already via byName
old="""function rocketSection(p,kind,ivs){
  const text=kind==='shadow'"""
new="""function rocketSection(p,kind,ivs){
  // The current Rocket leader / Giovanni roster is NOT part of the verified
  // sources. Grade only a clearly marked generic grunt charge-cycle proxy.
  const proxy=S.db?.valuation?.[p.id]?.rocket;
  if(S.full && Number.isInteger(proxy?.grade) && proxy.confidence==='low_no_roster'){
    const explain=`${moveLabel(proxy.fast)} / ${moveLabel(proxy.charged)} · 약 ${proxy.turns}턴 기준. 빠른 차징 잠재력만 반영하며 실제 상대·실드·내구·상성 미반영.`;
    return {html:rating('조무래기 · 범용 기술 운용 (참고 추정)',proxy.grade,explain)+
      rating('리더 · 알로 / 시에라 / 클리프','최신 검증 필요','현재 상대 편성·실드·상성 데이터 미연동')+
      rating('보스 · 비주기','최신 검증 필요','현재 상대 편성 데이터 미연동'),
      note:'이 별점은 로켓단 승률 또는 특정 리더 공략 등급이 아니야. 실제 대진 메타 검증이 필요해.'};
  }
  const text=kind==='shadow'"""
assert old in s;s=s.replace(old,new)
# snippet before render() meta context
anchor="function render(name,form,ivs){"
add="""
function metaContext(p){
  if(!S.full||!S.db?.valuation)return '';
  const item=S.db.valuation[p.id];
  const m=S.metaIndex;
  const checked=m?.monitor_status==='verified'&&m.version===S.db.meta_version;
  const history=S.metaChanges?.affected?.filter(x=>x.id===p.id)||[];
  let label='첫 기준선 · 과거 비교 없음',symbol='◉',tone='neutral';
  if(m?.monitor_status==='incomplete'){
    label='최신 확인 실패 · 이전 검증 가치 보존';symbol='!';tone='muted';
  }else if(checked){
    label='최근 확인 기준 기존 가치 유지';symbol='✓';tone='same';
    if(m.assessment==='initial_baseline')label='최초 검증 기준선 · 이후 변동 비교 예정';
    if(m.assessment==='unaffected')label='게임 데이터 변경 감지 · 육성 가치 변화 없음';
    if(m.assessment==='comparison'&&history.length){
      const ups=history.filter(x=>x.trend==='up').length,downs=history.filter(x=>x.trend==='down').length;
      if(ups&&downs)label='항목별 가치 상승·하락 발생';
      else if(ups)label='일부 분야 가치 상승';
      else if(downs)label='일부 분야 가치 하락';
      else label='메타 분석값 수정 · 별점 유지';
      tone='changed';symbol='↻';
    }
  }else{
    label='저장된 기준선 · 최신 점검 미확인';symbol='◷';tone='muted';
  }
  const updated=checked?String(m.last_checked_at||'').slice(0,16).replace('T',' ')+' UTC':'검증 시각 확인 필요';
  const adjustments=history.map(x=>{
    const dom={raid:'레이드',rocket:'로켓단 범용',1500:'슈퍼리그',2500:'하이퍼리그',10000:'마스터리그'}[x.domain]||x.domain;
    const arrow=x.trend==='up'?'↑':x.trend==='down'?'↓':'↔';
    const b=v=>Number.isInteger(v)?['☆☆☆','★☆☆','★★☆','★★★'][v]:'미확인';
    return `<li>${esc(dom)} ${esc(b(x.old))} → ${esc(b(x.new))} ${esc(arrow)} · ${esc(x.detail)}</li>`;
  }).join('');
  return `<section class="panel meta-card ${tone}"><div class="meta-heading"><b>${esc(symbol)} ${esc(label)}</b><small>최근 점검: ${esc(updated)}</small></div>`+
    `<p class="smallnote">${esc(item?'현재 기준선과 비교한 종족·형태별 평가':'해당 종족 평가 미계산')} · 게임 버전 직접 검증 자료가 아닌 공개 데이터 변경 감지 결과야.</p>`+
    (adjustments?`<ul class="meta-history">${adjustments}</ul>`:'')+`</section>`;
}

function applyMetaPatch(catalog,patch){
  if(!catalog||patch?.schema!==1||patch.from_version!==catalog.meta_version)return null;
  const next=JSON.parse(JSON.stringify(catalog));
  Object.assign(next,patch.top||{});
  const changes=patch.maps||{};
  for(const k of ['species','pvp_moves','valuation']){
    const ch=changes[k];if(!ch)continue;
    const current=next[k]||{};
    for(const del of ch.delete||[])delete current[del];
    Object.assign(current,ch.set||{});next[k]=current;
  }
  for(const k of ['ranks','raid']){
    const ch=changes[k];if(!ch)continue;
    const current=next[k]||{};
    for(const [field,detail] of Object.entries(ch)){
      if(detail.kind==='value')current[field]=detail.value;
      else if(detail.kind==='map'){
        const target=current[field]||{};
        for(const del of detail.delete||[])delete target[del];
        Object.assign(target,detail.set||{});current[field]=target;
      }else return null;
    }
    next[k]=current;
  }
  if(patch.pokemon){
    const pokes=new Map((next.pokemon||[]).map(x=>[x.id,x]));
    for(const del of patch.pokemon.delete||[])pokes.delete(del);
    for(const [id,p] of Object.entries(patch.pokemon.set||{}))pokes.set(id,p);
    next.pokemon=Array.from(pokes.values());
  }
  return next.meta_version===patch.to_version&&validCatalog(next)?next:null;
}
"""
assert anchor in s;s=s.replace(anchor,add+anchor)
# Avoid showing placeholders as confirmed game species
s=s.replace("  const pvp=pvpAnalysis(p,form,stages,ivs), raid=raidSection(p,form,stages,ivs), rocket=rocketSection(f,form,ivs);",
"  const pvp=pvpAnalysis(p,form,stages,ivs), raid=raidSection(p,form,stages,ivs), rocket=rocketSection(f,form,ivs);")
s=s.replace("  $('result').innerHTML=hero+\n", "  $('result').innerHTML=hero+metaContext(p)+\n")
s=s.replace("  if(S.full){const age=Date.now()-Date.parse(db.generated_at||'');const old=Number.isFinite(age)&&age>8*86400000;const source=String(db.pvpoke_timestamp||'원본 일자 미확인');setSync(old?'저장된 데이터 · 최신성 재확인 필요':'검증된 게임 데이터 사용 중',`DB 생성 ${String(db.generated_at||'시각 정보 없음').slice(0,16).replace('T',' ')} UTC · PvPoke 원본 ${source} · ${db.pokemon.length}개 형태`,old?'wait':'ok');}",
"  if(S.full){const age=Date.now()-Date.parse(db.generated_at||'');const old=Number.isFinite(age)&&age>8*86400000;const source=String(db.pvpoke_timestamp||'원본 일자 미확인');if(db.meta_schema===5)setSync('검증된 가치 기준선 사용 중 · 변경 확인 대기',`기준선 ${String(db.generated_at||'').slice(0,16).replace('T',' ')} UTC · ${db.pokemon.length}개 형태`, 'wait');else setSync(old?'저장된 데이터 · 최신성 재확인 필요':'검증된 게임 데이터 사용 중',`DB 생성 ${String(db.generated_at||'시각 정보 없음').slice(0,16).replace('T',' ')} UTC · PvPoke 원본 ${source} · ${db.pokemon.length}개 형태`,old?'wait':'ok');}")
start=s.index('async function checkUpdates(manual=false){')
end=s.index('function init(){',start)
repl="""async function fetchValidated(url,timeoutMs=17000){
  const ctrl=new AbortController();const t=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{const r=await fetch(url,{cache:'no-store',signal:ctrl.signal});
    if(!r.ok)throw Error(`HTTP ${r.status}`);return await r.json();
  }finally{clearTimeout(t)}
}
async function checkUpdates(manual=false){
  if(location.protocol==='file:'||location.protocol==='content:'){
    setSync('로컬 시연 모드','원격 증분 갱신은 HTTPS 배포 환경에서 작동해.','wait');return;}
  if(manual){$('refreshBtn').disabled=true;setSync('게임 데이터 변경 확인 중…','먼저 작은 변경 감지 파일만 확인해.');}
  try{
    const manifest=await fetchValidated('./data/meta-index.json',15000);
    if(manifest.schema!==1||!manifest.version||!manifest.catalog)throw Error('변경 감지 정보 오류');
    S.metaIndex=manifest;
    if(manifest.monitor_status==='incomplete'){
      setSync('최신 확인 실패 · 이전 가치 보존',`마지막 정상 점검 ${String(manifest.last_checked_at||'미확인').slice(0,16)} · 검증 실패가 가치 유지의 증거는 아니야.`,'wait');
      return;
    }
    if(manifest.monitor_status!=='verified')throw Error('검증 상태 미확정');
    if(!S.full||S.db.meta_version!==manifest.version){
      let payload=null;
      const delta=manifest.patch;
      if(S.full&&S.db.meta_version&&delta?.from_version===S.db.meta_version&&delta.to_version===manifest.version){
        try{payload=applyMetaPatch(S.db,await fetchValidated(delta.path+'?v='+encodeURIComponent(manifest.version),18000));
          if(payload)console.info('POGO v5 delta patch applied');
        }catch(e){console.warn('Patch failed, falling back to full snapshot',e)}
      }
      if(!payload)payload=await fetchValidated(manifest.catalog+'?v='+encodeURIComponent(manifest.version),22000);
      if(!validCatalog(payload)||payload.sample||payload.pokemon.length<700||payload.meta_version!==manifest.version)throw Error('v5 전체 데이터 무결성 검증 실패');
      activate(payload);
      try{localStorage.setItem('pogo.meta.catalog.v5',JSON.stringify(payload));}catch(e){console.warn('v5 cache unavailable',e)}
      try{S.metaChanges=await fetchValidated(manifest.changes+'?v='+encodeURIComponent(manifest.version),13000);}catch{S.metaChanges=null;}
    }
    S.metaVersion=manifest.version;
    const checked=String(manifest.last_checked_at||'미표기').slice(0,16).replace('T',' ');
    const label=manifest.assessment==='initial_baseline'?'v5.0 첫 검증 기준선 생성':
      manifest.assessment==='unaffected'?'메타 변화 확인 · 가치 유지':
      manifest.assessment==='unchanged'?'최근 확인 기준 가치 유지':
      '실질적 메타 변경 반영 완료';
    setSync(label,`확인 ${checked} UTC · 데이터 버전 ${manifest.version.slice(0,10)} · 변경 항목 ${manifest.latest_change_count??0}개 · 모바일은 버전 확인 후 선택적 다운로드`, 'ok');
  }catch(e){
    // Compatibility fallback during v4 -> v5 GitHub Pages migration.
    try{
      if(!S.full||S.db.meta_schema!==5){
        const payload=await fetchValidated('./data/catalog.json?v='+Math.floor(Date.now()/3600000));
        if(validCatalog(payload)&&!payload.sample&&payload.pokemon.length>=700){activate(payload);
          try{localStorage.setItem(payload.meta_schema===5?'pogo.meta.catalog.v5':'pogo.meta.catalog.v4',JSON.stringify(payload));}catch{}
        }
      }
    }catch{}
    setSync(S.full?'이전 검증 데이터 사용 중':'정식 데이터 연결 필요',
      `최신 변경 감지 확인 실패 (${e.message}). 기존 평가를 보존하며 최신 가치 유지는 주장하지 않아.`,'wait');
  }finally{$('refreshBtn').disabled=false;}
}
"""
s=s[:start]+repl+s[end:]
# replace init cache load both v4 / v5 with migration
s=s.replace("  try{const previous=JSON.parse(localStorage.getItem('pogo.meta.catalog.v4')||'null');if(validCatalog(previous)&&!previous.sample&&previous.pokemon.length>=700)activate(previous);}catch{}",
"  for(const cacheKey of ['pogo.meta.catalog.v5','pogo.meta.catalog.v4']){try{const previous=JSON.parse(localStorage.getItem(cacheKey)||'null');if(validCatalog(previous)&&!previous.sample&&previous.pokemon.length>=700){activate(previous);break;}}catch{}}")
p.write_text(s)
# UI and css
p=root/'index.html';html=p.read_text()
html=html.replace('POGO META CHECKER · Installable','POGO META CHECKER v5.0')
html=html.replace('V4.2 · FORM FIX','V5.0 · META CHANGE DETECTOR')
html=html.replace('이름과 형태, 공격·방어·체력만 입력해. 최신으로 확인된 데이터와 자체 계산을 구분해서 보여줄게.',
 '이름과 형태, 공격·방어·체력을 입력해. 검증된 가치 기준선을 보존하고, 게임 데이터의 실질적인 변동만 비교해.')
html=html.replace('  <section id="result"', '''  <section class="meta-guide" aria-label="메타 변경 감지 설명"><strong>🔍 변경이 없으면 기존 평가 유지</strong><span>작은 버전 정보부터 확인하고, 실제 가치 변화가 있을 때만 변경분을 받아. 검증 실패는 ‘가치 유지’로 표시하지 않아.</span></section>
  <section id="result"''')
html=html.replace('정식 데이터 동기화가 완료되지 않았다면 앱의 별점은 확정 평가가 아니야.',
 '별점은 출처에 따라 PvP 순위 또는 레이드·로켓단의 참고 추정이야. 최신 데이터 확인과 실제 게임 메타 검증은 서로 달라.')
p.write_text(html)
p=root/'style.css';css=p.read_text()+'''
/* v5.0 meta verification display */
.meta-guide{display:flex;flex-direction:column;gap:6px;margin:12px 0 16px;padding:14px 16px;border:1px solid var(--line, #29435b);border-radius:14px;background:rgba(60,116,155,.07)}
.meta-guide strong{font-size:13px}.meta-guide span{font-size:12px;line-height:1.6;color:var(--muted, #aebaca)}
.meta-card{border-left:3px solid #4d6f8a}.meta-card.same{border-left-color:#42b883}.meta-card.changed{border-left-color:#f5b64c}.meta-card.muted{border-left-color:#8994a6}
.meta-heading{display:flex;flex-direction:column;gap:6px}.meta-heading b{font-size:15px}.meta-heading small{color:var(--muted, #9eb0bb);font-size:11px}
.meta-history{margin:12px 0 0;padding-left:18px;font-size:12px;line-height:1.8}
'''
p.write_text(css)
p=root/'sw.js';sw=p.read_text().replace("pogo-meta-v4.2-shell-20261114","pogo-meta-v5.0-shell-20261114").replace("pogo-meta-v4-data","pogo-meta-v5-data")
sw=sw.replace("if(url.pathname.endsWith('/data/catalog.json')){", "if(url.pathname.includes('/data/') && (url.pathname.endsWith('catalog.json')||url.pathname.endsWith('meta-index.json')||url.pathname.endsWith('changes.json')||url.pathname.endsWith('patch.json'))){")
sw=sw.replace("const canonical=new URL('./data/catalog.json',self.registration.scope);", "const canonical=new URL(url.pathname.split('/').pop(),new URL('./data/',self.registration.scope));")
sw=sw.replace("const payload=await network.clone().json();\n        // Fail closed if the data file is truncated or non-JSON. Do not cache broken snapshots.\n        if(payload.schema!==3||!Array.isArray(payload.pokemon)||payload.pokemon.length<700)throw Error('Invalid snapshot');",
"const payload=await network.clone().json();\n        if(url.pathname.endsWith('catalog.json') && (payload.schema!==3||!Array.isArray(payload.pokemon)||payload.pokemon.length<700))throw Error('Invalid snapshot');\n        if(url.pathname.endsWith('meta-index.json') && (payload.schema!==1||!payload.version))throw Error('Invalid meta-index');")
# cache fallback on meta index with offline must not claim success -> offline status best when fetch fails, client status verified stale; solve via app update data age? leave metadata cached and add offline warning
p.write_text(sw)
