# POGO META CHECKER v5.0 — 변경 감지형 육성 가치 분석

한국어 이름·특수 형태·IV를 입력해 Pokémon GO 관련 공개 자료를 분석하는 비공식 PWA.

## v5.0 핵심 기능

1. **기존 검증 기준선 보존**: 최신 출처를 확인할 수 없으면 직전 기준선을 유지하되 ‘가치 유지 확인’으로 표시하지 않음.
2. **비용 절감**: GitHub raw ETag(없으면 해시)와 PoGoAPI `/api/v1/api_hashes.json`만 먼저 확인. 원천 변경 신호가 없는 한 대용량 원천 데이터 재수집과 평가 재계산을 건너뜀.
3. **의미 있는 가치 변경 감지**: 레이드(자체 상대 화력 참고 추정), 슈퍼/하이퍼/마스터 PvPoke 순위, 로켓단 범용 차징 기술 평가를 종족·형태 기준으로 비교. 상승/하락/별점 유지·세부수치 변경을 기록.
4. **모바일 최소 전송**: 앱은 작은 `data/meta-index.json` 파일을 우선 확인. 동일한 `version`이라면 대형 `catalog.json`을 내려받지 않음. 정확한 이전 버전을 보유한 경우, 변경분 `patch.json`이 전체 DB보다 20% 이상 작을 때 우선 적용.
5. **검색 보완**: PvPoke에 없는 PokeAPI 종도 도감 이름으로 검색 가능. 이 경우 출시·GO 전투 데이터 확인 전까지 수치와 별점을 생성하지 않음. 자시안/자마젠타 등의 폼은 별도로 구분.
6. **운영 방식**: 전체 데이터 변경 확인은 하루 1회 자동 예약(UTC 04:17). 게임 메타에 영향을 미치는 실제 원천 변경이 확인된 경우에만 가치 재계산. 수동 실행도 가능.

## 분명한 한계

- **실시간 게임 공식 서버 API에 연결된 시스템이 아님.** 공개 출처 갱신 속도에 영향을 받으며 공식 공지나 일시적 이벤트만으로는 별점을 자동 바꾸지 않음.
- **레이드 점수는 보스별 DPS/TDO 시뮬레이션이 아닌 상대 화력 근사치**. 레이드 보스 회전, 날씨, 메가 버프, 생존력은 평가에 포함되지 않음.
- **로켓단 별점은 검증된 로스터 없는 일반 조무래기용 기술 충전 추정**. 리더와 비주기의 실제 편성·상성별 등급은 여전히 ‘최신 검증 필요’로 처리.
- **포켓몬의 최초 가치 기준선에는 상승/하락을 표시하지 않음.** 두 번 이상의 성공한 버전 비교가 있어야 이력 생성.
- 공개 데이터가 변경되어도 게임 메타의 실질적 가치가 그대로라면 전체 데이터의 `meta_version`은 불변.
- GitHub Pages 배포 작업은 메타-index를 갱신하기 위해 주기적으로 실행됨. **휴대폰**의 대형 JSON 전송과 계산을 줄이는 것이 주요 목표. GitHub Pages 아티팩트 업로드가 완전히 0이 되는 것은 아님.

## 배포

**현재 저장소의 ZIP 배포 방식 기준**:

1. 저장소 루트에 `POGO_META_CHECKER_v5_mobile.zip` 업로드
2. 저장소의 `.github/workflows/mobile-deploy.yml` **내용 전체**를 함께 제공하는 `POGO_META_v5_자동배포설정.yml` 내용으로 교체
3. Settings → Pages → Source: GitHub Actions
4. Actions → `POGO META v5 Change-Aware Deploy` 초록색 체크 확인
5. `https://a01023582660-web.github.io/pogo-meta-checker/`에서 기존 설치 앱 새로고침

ZIP 내부의 `.github` 경로는 GitHub Actions 설정으로 자동 설치되지 않으므로 반드시 저장소 루트에 워크플로를 별도로 만들어야 함.

## 코드와 테스트

```bash
python -m unittest discover -s tests -v
node tests/test_app.js
node tests/test_v5_delta.js
python scripts/update_data.py
```

검증 결과는 `data/catalog.json`(전체 기준선), `data/meta-index.json`(소형 점검 상태), `data/changes.json`(최근 버전별 가치 변동), `data/patch.json`(이전 버전에서의 변경분)으로 관리됨.

### 공개 데이터 참조

- PvPoke: https://github.com/pvpoke/pvpoke (라이선스 파일 포함)
- PokeAPI: https://pokeapi.co/ (한국어 도감 이름/진화 계열)
- PoGoAPI: https://pogoapi.net/documentation/ (공개 기술 데이터와 변경 해시)
- 공식 Pokémon GO 소식: https://pokemongo.com/ko/news (이벤트 맥락 확인용, 자동 반영 데이터라고 보장하지 않음)

애플리케이션은 Pokémon GO 공식 앱이 아님.
