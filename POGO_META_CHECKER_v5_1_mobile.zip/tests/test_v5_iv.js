const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const base=path.resolve(__dirname,'..');
const elements=new Map();
function el(id){
  if(!elements.has(id)) elements.set(id,{value:'',checked:false,innerHTML:'',textContent:'',hidden:false,disabled:false,
    addEventListener(t,fn){this[t]=fn},scrollIntoView(){},requestSubmit(){this.submit?.({preventDefault(){}})}});
  return elements.get(id);
}
const radios=['normal','shadow','purified','dynamax','gigantamax','mega','primal'].map(value=>({value,checked:value==='normal',addEventListener(){}}));
const doc={getElementById:el,querySelector(q){return q==='input[name="form"]:checked'?radios.find(x=>x.checked):null},querySelectorAll(q){return q==='input[name="form"]'?radios:[]}};
const ctx={window:{__POGO_TEST_MODE__:true,addEventListener(){}},document:doc,navigator:{},console,
  Date,Math,Number,String,Object,Array,Set,Map,JSON,Promise,setTimeout,clearTimeout,location:{protocol:'file:',hostname:'',pathname:'/index.html'},
  alert(t){throw Error('Unexpected alert '+t)},fetch:async()=>{throw Error('offline')},localStorage:{getItem(){return null},setItem(){}}};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(base,'data/starter.js'),'utf8'),ctx);
const snap=JSON.parse(JSON.stringify(ctx.window.POGO_STARTER));
snap.sample=false;snap.generated_at='2026-11-14T00:00:00Z';
for(let i=0;i<710;i++)snap.pokemon.push({id:'fixture_'+i,dex:2500+i,en:'Fixture',base:{atk:100,def:100,hp:100},types:['normal'],released:true,quick:[],charge:[]});
const good={id:'iv_test',dex:2001,en:'Testmon',base:{atk:208,def:175,hp:225},types:['water'],released:true,quick:[],charge:[]};
snap.pokemon.push(good);snap.species['2001']={dex:2001,ko:'테스트몬',chain:2001,legendary:false,mythical:false};
snap.species['888']={dex:888,ko:'자시안',chain:888,legendary:true,mythical:false};
snap.ranks['1500'].iv_test={rank:15,moves:[]};
snap.ranks['2500'].iv_test={rank:45,moves:[]};
snap.ranks['10000'].iv_test={rank:25,moves:[]};
ctx.localStorage.getItem=()=>JSON.stringify(snap);
vm.runInContext(fs.readFileSync(path.join(base,'app.js'),'utf8'),ctx);
const v=ctx.window.__POGO_V5_TESTS;
assert(v,'v5.1 test API enabled');
const gl=v.leagueIvCompare(good,[0,15,15],1500),glHundo=v.leagueIvCompare(good,[15,15,15],1500);
assert(gl&&glHundo&&gl.count===4096,'Enumerates all 4096 Great League spreads');
assert(gl.rank<glHundo.rank,'Good Great League IV outranks hundo for selected capped species');
assert(gl.preferred.length===3&&gl.bestIV.match(/^\d+\/\d+\/\d+$/),'Top 3 preferred spread printed');
assert(gl.percent<=100&&gl.percent>0,'Percentage is ratio, not win rate');
const ml=v.leagueIvCompare(good,[15,15,15],10000);
assert(ml.bestIV==='15/15/15'&&ml.rank===1,'Master League hundo rank 1');
const rankLow=v.leagueIvCompare(good,[15,0,0],1500);
assert(v.leagueIvStatus(3,rankLow,1500).level==='reject','Unfavored GL IV rejected despite good species meta');
assert(v.leagueIvStatus(3,ml,10000).level==='recommend','Hundo in meta ML recommended');
const r15=v.raidIvAssess(good,'normal',[15,15,15],3),r12=v.raidIvAssess(good,'normal',[12,10,10],3),rBad=v.raidIvAssess(good,'normal',[1,0,1],3);
assert(r15.level==='recommend'&&r15.percent===100,'Raid 15 Attack reference');
assert(r12.level==='maybe','Raid non-hundo practical backup');
assert(rBad.level==='reject','Terrible raid IV rejected');
const rejectAll={all:[{decision:{level:'reject'}}]},raidNo={grade:1,ivDecision:{level:'reject'}};
assert(v.verdict(rejectAll,raidNo,'normal',good,[1,1,1],false).txt.includes('박사에게 보내기'),'Transfer recommendation for truly low-priority ordinary');
assert(!v.verdict(rejectAll,raidNo,'normal',good,[1,1,1],true).txt.includes('🗑️'),'Special keep blocks recommendation');
assert(!v.verdict(rejectAll,raidNo,'normal',{...good,dex:888},[1,1,1],false).txt.includes('🗑️'),'Legendary protected');
assert(!v.verdict(rejectAll,raidNo,'normal',good,[15,15,15],false).txt.includes('🗑️'),'Hundo protected');
assert(!v.verdict(rejectAll,{grade:null},'normal',good,[1,1,1],false).txt.includes('🗑️'),'Unverified raid data blocks irreversible recommendation');
function run(name,iv,protectedFlag=false){el('pkname').value=name;['atk','def','hp'].forEach((k,i)=>el(k).value=String(iv[i]));el('specialKeep').checked=protectedFlag;el('form').submit({preventDefault(){}});return el('result').innerHTML;}
const rendered=run('테스트몬',[0,15,15]);
assert(rendered.includes('선호 IV 상위 3개'),'UI shows preferred IV');
assert(rendered.includes('현재 IV'),'UI shows current spread');
assert(rendered.includes('스탯곱 최고 대비'),'UI differentiates stat product percentage');
assert(rendered.includes('기준 박사에게 보내기'),'Per-league clear negative IV recommendation');
assert(rendered.includes('최종 육성·보관 판정'),'Explicit IV-based final verdict');
console.log('PASS v5.1 PvP 4096 IV ranking, best IVs, Master League, raid IV, professor/relic protection, UI');
