import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import v5_sync as v5


class MetaSyncTests(unittest.TestCase):
    def test_baseline_has_no_imaginary_up_or_down(self):
        new={'valuation':{'p':{'dex':25,'raid':{'grade':3}}}}
        changes=v5.assess_changes(None,new)
        self.assertEqual(changes['type'],'initial_baseline')
        self.assertFalse(changes['affected'])

    def test_unchanged_and_changed_grades_distinct(self):
        old={'valuation':{'p':{'dex':25,'raid':{'grade':2},'rocket':{'grade':2}}}}
        new={'valuation':{'p':{'dex':25,'raid':{'grade':3},'rocket':{'grade':2}}}}
        c=v5.assess_changes(old,new)
        self.assertEqual(len(c['affected']),1)
        self.assertEqual(c['affected'][0]['trend'],'up')
        self.assertEqual(c['counts']['unchanged'],4)

    def test_same_grade_with_move_change_not_called_upgrade(self):
        old={'valuation':{'p':{'dex':25,'raid':{'grade':2,'fast':'OLD'}}}}
        new={'valuation':{'p':{'dex':25,'raid':{'grade':2,'fast':'NEW'}}}}
        c=v5.assess_changes(old,new)
        self.assertEqual(c['affected'][0]['trend'],'changed')
        self.assertEqual(c['affected'][0]['old'],c['affected'][0]['new'])

    def test_zacian_forme_no_cross_contamination(self):
        raid={'available':True,'learnsets':{
          '888:hero_of_many_battles':{'fast':['Snarl'],'charge':['Play Rough']},
          '888:crowned_sword':{'fast':['Metal Claw'],'charge':['Behemoth Blade']}}}
        hero=v5.raid_learnset({'dex':888,'id':'zacian_hero'},raid)
        crowned=v5.raid_learnset({'dex':888,'id':'zacian_crowned_sword'},raid)
        self.assertNotEqual(hero,crowned)
        self.assertIn('Behemoth Blade',crowned['charge'])
        self.assertNotIn('Behemoth Blade',hero['charge'])

    def test_search_catalog_only_is_not_fabricated_game_pokemon(self):
        # Full-mode only. A PokeAPI entry not present in PvPoke stays searchable
        # without getting invented move data or an invented release date.
        from update_data import build_catalog
        from test_update import SnapshotTests
        fixture=SnapshotTests('test_catalog_links');fixture.setUp()
        newrow='233,porygon2,2,137,200,0,0\n'
        fixture.raws['species']+=newrow.encode()
        fixture.raws['names']+='233,3,폴리곤2,\n'.encode()
        out=build_catalog(fixture.raws,strict=False)
        self.assertFalse(any(p['dex']==233 for p in out['pokemon']))
        # Strict builder uses the same added index logic after input validation.
        # Check the invariant via source check rather than forging 700 fixtures.
        text=Path(__file__).resolve().parents[1].joinpath('scripts/update_data.py').read_text('utf-8')
        self.assertIn("'catalog_only':True",text)

    def test_underscore_in_base_species_name_not_misread_as_form(self):
        raid={'available':True,'learnsets':{
           '122:normal':{'fast':['Zen Headbutt'],'charge':['Psychic']},
           '122:galarian':{'fast':['Confusion'],'charge':['Ice Punch']}}}
        normal=v5.raid_learnset({'dex':122,'id':'mr_mime','species_identifier':'mr-mime'},raid)
        galar=v5.raid_learnset({'dex':122,'id':'mr_mime_galarian','species_identifier':'mr-mime'},raid)
        self.assertEqual(normal['fast'],['Zen Headbutt'])
        self.assertEqual(galar['fast'],['Confusion'])

    def test_delta_map_and_pokemon_changes(self):
        old={'meta_version':'aaa','pokemon':[{'id':'a','dex':1},{'id':'b','dex':2}],
             'species':{'1':{'ko':'이상해씨'}},'ranks':{'1500':{'a':{'rank':3}}},
             'pvp_moves':{},'valuation':{'a':{'raid':{'grade':1}}},
             'raid':{'available':True,'fast':{'tackle':{'power':2}}}}
        new=copy.deepcopy(old)
        new['meta_version']='bbb'
        new['pokemon'][0]['base']={'atk':1}
        new['pokemon'].append({'id':'c','dex':3})
        new['species']['3']={'ko':'이상해풀'}
        new['valuation']['a']={'raid':{'grade':2}}
        new['ranks']['1500']['a']['rank']=2
        new['raid']['fast']['tackle']['power']=3
        patchdata=v5.make_patch(old,new)
        self.assertEqual(patchdata['pokemon']['set']['a']['base']['atk'],1)
        self.assertIn('c',patchdata['pokemon']['set'])
        self.assertEqual(patchdata['maps']['raid']['fast']['set']['tackle']['power'],3)
        self.assertEqual(patchdata['from_version'],'aaa')

    def test_unchanged_probe_does_not_modify_catalog(self):
        with tempfile.TemporaryDirectory() as td:
            data=Path(td)/'data';data.mkdir()
            old={'schema':3,'meta_schema':5,'meta_version':'stable','valuation':{},'pokemon':[]}
            catalog=data/'catalog.json';catalog.write_text(json.dumps(old,ensure_ascii=False),encoding='utf-8')
            fingerprints={key:'sha256:same' for key in v5.SOURCES}
            (data/'meta-index.json').write_text(json.dumps({'schema':1,'version':'stable',
              'source_signatures':fingerprints}),encoding='utf-8')
            original=catalog.read_bytes()
            with patch.object(v5,'CATALOG',catalog),patch.object(v5,'INDEX',data/'meta-index.json'),patch.object(v5,'DATA',data),\
              patch.object(v5,'signature_probe',return_value=(fingerprints,{})),\
              patch.object(v5,'fetch_changed_sources',side_effect=AssertionError('unnecessary download')):
                v5.run()
            self.assertEqual(catalog.read_bytes(),original)
            status=json.loads((data/'meta-index.json').read_text('utf-8'))
            self.assertEqual(status['assessment'],'unchanged')
            self.assertEqual(status['monitor_status'],'verified')

    def test_failed_probe_preserves_old_but_never_verified(self):
        with tempfile.TemporaryDirectory() as td:
            data=Path(td)/'data';data.mkdir()
            old={'meta_schema':5,'meta_version':'old'}
            catalog=data/'catalog.json';catalog.write_text(json.dumps(old),encoding='utf-8')
            (data/'meta-index.json').write_text(json.dumps({'schema':1,'version':'old',
              'monitor_status':'verified','last_checked_at':'2026-11-13T01:00:00Z'}),encoding='utf-8')
            original=catalog.read_bytes()
            with patch.object(v5,'CATALOG',catalog),patch.object(v5,'INDEX',data/'meta-index.json'),patch.object(v5,'DATA',data),\
              patch.object(v5,'signature_probe',return_value=({}, {'gm':'timeout'})):
                v5.run()
            self.assertEqual(catalog.read_bytes(),original)
            status=json.loads((data/'meta-index.json').read_text('utf-8'))
            self.assertEqual(status['monitor_status'],'incomplete')
            self.assertEqual(status['last_checked_at'],'2026-11-13T01:00:00Z')

if __name__=='__main__':unittest.main()

# Match the canonical species identifier, not the first underscore in a name.
# Mr. Mime / Ho-Oh / Tapu Koko are common counterexamples to naive splitting.
