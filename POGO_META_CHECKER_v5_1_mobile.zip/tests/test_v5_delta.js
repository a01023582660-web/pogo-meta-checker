const fs = require('fs'), vm = require('vm'), path=require('path'), assert=require('assert');
const root=path.resolve(__dirname,'..');
const els=new Map();
function el(id){if(!els.has(id))els.set(id,{value:'',textContent:'',innerHTML:'',disabled:false,
  addEventListener(t,fn){this[t]=fn},scrollIntoView(){}});return els.get(id)}
const context={window:{__POGO_TEST_MODE__:true,addEventListener(){}},document:{getElementById:el,
  querySelector(){return {value:'normal'}},querySelectorAll(){return []}},
  localStorage:{getItem(){return null}},navigator:{},location:{protocol:'file:',hostname:''},
  console,Math,Date,Number,String,Object,Array,JSON,Map,Set,Promise,fetch:async()=>{throw Error('offline')},setTimeout,clearTimeout};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'data/starter.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),context);
const patcher=context.window.__POGO_V5_TESTS.applyMetaPatch;
const src={schema:3,meta_schema:5,meta_version:'aaa',pokemon:[{id:'one',dex:1},{id:'two',dex:2}],
 species:{1:{ko:'이상해씨'}},ranks:{1500:{one:{rank:1}},2500:{},10000:{}},
 pvp_moves:{},valuation:{one:{raid:{grade:2}}},
 raid:{available:true,fast:{old:{power:1}},learnsets:{}}};
for(let i=0;i<32;i++)src.pokemon.push({id:'extra'+i,dex:100+i});
const patch={schema:1,from_version:'aaa',to_version:'bbb',top:{meta_version:'bbb'},
 maps:{species:{set:{'3':{ko:'이상해꽃'}},delete:[]},
    valuation:{set:{one:{raid:{grade:3}}},delete:[]},
    ranks:{1500:{kind:'map',set:{two:{rank:11}},delete:['one']}},
    raid:{fast:{kind:'map',set:{old:{power:3},new:{power:2}},delete:[]}}},
 pokemon:{set:{one:{id:'one',dex:1,base:{atk:1}},three:{id:'three',dex:3}},delete:['two']}};
const out=patcher(src,patch);
assert(out && out.meta_version==='bbb');
assert(out.pokemon.length===34 && out.pokemon.find(p=>p.id==='one').base.atk===1);
assert(!out.pokemon.find(p=>p.id==='two'));
assert(out.raid.fast.old.power===3 && out.raid.fast.new.power===2);
assert(!out.ranks['1500'].one && out.ranks['1500'].two.rank===11);
assert(out.valuation.one.raid.grade===3);
assert.equal(patcher(src,{...patch,from_version:'wrong'}),null);
console.log('PASS v5 patch applies only changed fields and rejects wrong base version');
