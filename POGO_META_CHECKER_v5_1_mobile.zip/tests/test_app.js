const fs=require('fs');const vm=require('vm');const assert=require('assert');const path=require('path');
const root=path.resolve(__dirname,'..');
const nodes=new Map();
function el(id){
  if(!nodes.has(id)){
    let handlers={};
    nodes.set(id,{
      value:'',textContent:'',innerHTML:'',checked:false,hidden:false,disabled:false,className:'',
      classList:{add(){},remove(){}},
      addEventListener(type,fn){handlers[type]=fn},
      dispatch(type){if(handlers[type])handlers[type]({preventDefault(){}})},
      scrollIntoView(){},requestSubmit(){el('form').dispatch('submit')}
    });
  }
  return nodes.get(id);
}
const radios=['normal','shadow','purified','dynamax','gigantamax','mega','primal'].map(value=>({value,checked:value==='normal',addEventListener(){}}));
const doc={getElementById:el,querySelector(selector){if(selector==='input[name="form"]:checked')return radios.find(r=>r.checked);return null;},querySelectorAll(q){return q==='input[name="form"]'?radios:[];}};
const context={window:{addEventListener(){}},document:doc,navigator:{},console,Date,Math,Number,String,Object,Array,Set,Map,JSON,Promise,
  localStorage:{getItem(){return null},setItem(){}},
  location:{protocol:'file:',hostname:'',pathname:'/index.html'},
  alert(msg){throw new Error('UNEXPECTED ALERT: '+msg)},
  fetch:async()=>{throw new Error('offline')},
  setTimeout,clearTimeout};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'data/starter.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),context);
function run(name,arr){
  el('pkname').value=name;['atk','def','hp'].forEach((k,i)=>el(k).value=String(arr[i]));
  el('form').dispatch('submit');
  return el('result').innerHTML;
}
let html=run('코코리',[15,14,12]);
assert(html.includes('코리갑'),'Evolution picture sequence');
assert(html.includes('91%'),'IV sum');
assert(html.includes('정식 데이터 갱신 필요'),'No fabricated up-to-date ranking');
html=run('이브이',[1,15,10]);
assert(html.includes('샤미드')&&html.includes('님피아'),'Branching evolution');
assert((html.match(/class="evo-card/g)||[]).length===9,'Nine images in Eevee family');
html=run('메타몽',[12,10,10]);
assert(html.includes('참가 불가'),'Ditto bans');
radios.forEach(r=>r.checked=r.value==='shadow');
html=run('코코리',[15,14,12]);
assert(html.includes('그림자')&&html.includes('검증'),'Shadow not represented as normal');
console.log('PASS app IV, evolution, Eevee branching, PvP restrictions, shadow isolation');
const mock=JSON.parse(JSON.stringify(context.window.POGO_STARTER));
mock.sample=false;mock.generated_at='2026-11-13T00:00:00Z';mock.ranks['1500'].donphan={rank:15,score:90,moves:['MUD_SLAP','EARTHQUAKE']};
for(let i=0;i<710;i++)mock.pokemon.push({id:'fixture_mon_'+i,dex:2000+i,en:'Fixture',base:{atk:150,def:150,hp:150},types:['normal'],tags:[],quick:[],charge:[],elite:[],evos:[],released:true});
context.localStorage.getItem=()=>JSON.stringify(mock);
// independent app context to simulate previously validated downloaded snapshot
const nodes2=new Map();
const el2=id=>{if(!nodes2.has(id))nodes2.set(id,{value:'',innerHTML:'',textContent:'',hidden:false,disabled:false,addEventListener(type,fn){this[type]=fn},requestSubmit(){this.submit({preventDefault(){}})},scrollIntoView(){}});return nodes2.get(id)};
const radios2=radios.map(x=>({...x,checked:x.value==='normal'}));
const c2={...context,window:{...context.window}, document:{getElementById:el2,querySelector(q){return q==='input[name="form"]:checked'?radios2.find(x=>x.checked):null},querySelectorAll(q){return q==='input[name="form"]'?radios2:[]}},location:{protocol:'file:',hostname:'',pathname:'/index.html'}};
vm.createContext(c2);vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),c2);
el2('pkname').value='코코리';['atk','def','hp'].forEach((k,i)=>el2(k).value=String([15,14,12][i]));
el2('form').submit({preventDefault(){}});
assert(el2('result').innerHTML.includes('PvPoke 15위'),'Validated live rank mapped in app');
console.log('PASS validated snapshot read and PvP rank mapping');
// Simulate an available-but-upstream-date-unverified PoGoAPI PvE provider.
mock.pokemon.find(p=>p.id==='donphan').base={atk:214,def:185,hp:207};
mock.pokemon.find(p=>p.id==='donphan').types=['ground'];
mock.raid={available:true, freshness:'upstream_date_unavailable',
 fast:{'mud slap':{power:19,ms:1500,energy:13,type:'ground'}},
 charged:{'earthquake':{power:140,ms:3600,energy:-100,type:'ground'}},
 learnsets:{'232:normal':{fast:['Mud Slap'],charge:['Earthquake'],elite_fast:[],elite_charge:[]}}};
const c3={...context,window:{...context.window},document:{getElementById:el2,querySelector(q){return q==='input[name=\"form\"]:checked'?radios2.find(x=>x.checked):null},querySelectorAll(q){return q==='input[name=\"form\"]'?radios2:[]}},location:{protocol:'file:',hostname:'',pathname:'/index.html'}};
vm.createContext(c3);vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),c3);
el2('form').submit({preventDefault(){}});
assert(el2('result').innerHTML.includes('레이드 상대 화력 (참고 추정)'), 'Raid simulation shown when valid PvE data loaded');
assert(el2('result').innerHTML.includes('갱신일 미확인/오래됨'), 'No claim of live verified raid meta');
console.log('PASS available but upstream-date-unverified raid data shown as reference only');
// Regression: named formes must not be conflated or require a fictitious :normal learnset.
const forms=JSON.parse(JSON.stringify(mock));
forms.species['888']={dex:888,ko:'자시안',chain:888,legendary:true,mythical:false};
forms.species['889']={dex:889,ko:'자마젠타',chain:889,legendary:true,mythical:false};
forms.pokemon.push(
  {id:'zacian_hero',dex:888,en:'Zacian (Hero)',base:{atk:254,def:236,hp:192},types:['fairy'],tags:[],quick:[],charge:[],elite:[],evos:[],released:true},
  {id:'zacian_crowned_sword',dex:888,en:'Zacian (Crowned Sword)',base:{atk:332,def:240,hp:192},types:['fairy','steel'],tags:[],quick:[],charge:[],elite:[],evos:[],released:true},
  {id:'zamazenta_hero',dex:889,en:'Zamazenta (Hero)',base:{atk:254,def:236,hp:192},types:['fighting'],tags:[],quick:[],charge:[],elite:[],evos:[],released:true},
  {id:'zamazenta_crowned_shield',dex:889,en:'Zamazenta (Crowned Shield)',base:{atk:250,def:292,hp:192},types:['fighting','steel'],tags:[],quick:[],charge:[],elite:[],evos:[],released:true}
);
forms.raid={available:true,freshness:'upstream_date_old_unconfirmed_game',
 fast:{'metal claw':{power:6,ms:500,energy:5,type:'steel'},'snarl':{power:11,ms:1000,energy:13,type:'dark'}},
 charged:{'play rough':{power:90,ms:3000,energy:-50,type:'fairy'},'behemoth blade':{power:200,ms:3500,energy:-100,type:'steel'},'close combat':{power:105,ms:2500,energy:-100,type:'fighting'},'behemoth bash':{power:200,ms:3500,energy:-100,type:'steel'}},
 learnsets:{'888:hero_of_many_battles':{fast:['Snarl'],charge:['Play Rough'],elite_fast:[],elite_charge:[]},
 '888:crowned_sword':{fast:['Metal Claw'],charge:['Behemoth Blade'],elite_fast:[],elite_charge:[]},
 '889:hero':{fast:['Snarl'],charge:['Close Combat'],elite_fast:[],elite_charge:[]},
 '889:crowned_shield':{fast:['Metal Claw'],charge:['Behemoth Bash'],elite_fast:[],elite_charge:[]}}
};
const formsNodes=new Map();
function formsEl(id){if(!formsNodes.has(id))formsNodes.set(id,{value:'',innerHTML:'',textContent:'',hidden:false,disabled:false,checked:false,
 addEventListener(type,fn){this[type]=fn},requestSubmit(){this.submit({preventDefault(){}})},scrollIntoView(){}});return formsNodes.get(id);}
const radios4=radios.map(r=>({...r,checked:r.value==='normal'}));
const c4={...context,window:{...context.window},localStorage:{getItem(){return JSON.stringify(forms)},setItem(){}},
 document:{getElementById:formsEl,querySelector(q){return q==='input[name="form"]:checked'?radios4.find(x=>x.checked):null},querySelectorAll(q){return q==='input[name="form"]'?radios4:[]}},
 location:{protocol:'file:',hostname:'',pathname:'/index.html'}};
vm.createContext(c4);vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),c4);
function run4(name){formsEl('pkname').value=name;['atk','def','hp'].forEach(k=>formsEl(k).value='15');formsEl('form').submit({preventDefault(){}});return formsEl('result').innerHTML;}
let hero=run4('자시안');
assert(hero.includes('레이드 상대 화력 (참고 추정)'),'Hero Zacian must have PvE output');
assert(hero.includes('역전의 용사'),'Unqualified Korean Zacian means Hero');
assert(hero.includes('Play Rough'),'Hero must use its own charged move');
assert(!hero.includes('Behemoth Blade'),'Hero must never inherit Crowned moves');
let crown=run4('자시안 검왕');
assert(crown.includes('레이드 상대 화력 (참고 추정)'),'Crowned Zacian must have PvE output');
assert(crown.includes('Behemoth Blade'),'Crowned must use its own signature move');
assert(!crown.includes('Play Rough'),'Crowned must not borrow Hero moves');
let zam=run4('자마젠타 방패왕');
assert(zam.includes('Behemoth Bash'),'Crowned Zamazenta must use its own signature move');
console.log('PASS Zacian Hero/Crowned Sword and Zamazenta Crowned Shield form-specific PvE');
