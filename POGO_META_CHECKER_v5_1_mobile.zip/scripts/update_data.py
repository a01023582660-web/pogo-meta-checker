#!/usr/bin/env python3
"""Validate and atomically publish a deterministic Pokemon GO data snapshot.

Sources: PvPoke (MIT), PokeAPI species CSV and PoGoAPI move data.
Never silently replace a valid catalog with a partial download.
A failed provider leaves previous published data untouched.
"""
from __future__ import annotations
import csv
import datetime as dt
import email.utils
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "data" / "catalog.json"
BASE = 'https://raw.githubusercontent.com'
SOURCES = {
    'gm': f'{BASE}/pvpoke/pvpoke/master/src/data/gamemaster.json',
    'great': f'{BASE}/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-1500.json',
    'ultra': f'{BASE}/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-2500.json',
    'master': f'{BASE}/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-10000.json',
    'species': f'{BASE}/PokeAPI/pokeapi/master/data/v2/csv/pokemon_species.csv',
    'names': f'{BASE}/PokeAPI/pokeapi/master/data/v2/csv/pokemon_species_names.csv',
    'raid_fast': 'https://pogoapi.net/api/v1/fast_moves.json',
    'raid_charged': 'https://pogoapi.net/api/v1/charged_moves.json',
    'raid_learnsets': 'https://pogoapi.net/api/v1/current_pokemon_moves.json',
}
REQUIRED = ('gm','great','ultra','master','species','names')
USER_AGENT = 'POGO-Meta-Checker/5.0 (personal open-source noncommercial snapshot updater)'


PROVIDER_HEADERS = {}

def download(url: str) -> bytes:
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT, 'Accept': 'application/json,text/csv,*/*'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=35) as r:
                raw = r.read(18_000_001)
                PROVIDER_HEADERS[url] = {'last_modified':r.headers.get('Last-Modified'), 'etag':r.headers.get('ETag')}
            if len(raw) > 18_000_000 or len(raw) < 100:
                raise ValueError(f'Unexpected response size {len(raw)}')
            return raw
        except Exception:
            if attempt == 2: raise
            time.sleep((attempt+1)*2)
    raise AssertionError('unreachable')


def parse_csv(raw: bytes):
    return list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))


def safe_int(value, default=None):
    try: return int(value)
    except (TypeError, ValueError): return default


def _normalize_move_map(moves):
    if not isinstance(moves, list): return {}
    output = {}
    for move in moves:
        if not isinstance(move, dict): continue
        name = str(move.get('name') or '').strip().lower()
        power = move.get('power')
        duration = move.get('duration')
        energy = move.get('energy_delta')
        if not name or power is None or duration is None or energy is None: continue
        try:
            p, dur, en = float(power), float(duration), float(energy)
            if dur <= 0 or dur > 10000 or p < 0: continue
            output[name] = {'power':p,'ms':dur,'energy':en, 'type':str(move.get('type') or '').lower()}
        except (ValueError, TypeError): continue
    return output


def build_catalog(raws: dict, *, strict=True, now=None, provider_headers=None) -> dict:
    gm = json.loads(raws['gm'])
    pokemons = gm.get('pokemon')
    if not isinstance(pokemons,list) or len(pokemons)<(700 if strict else 2):
        raise ValueError('PvPoke GM species list invalid or abnormally small')
    ranks = {}
    for key,cap in (('great','1500'),('ultra','2500'),('master','10000')):
        src = json.loads(raws[key])
        if not isinstance(src,list) or len(src)<(150 if strict else 1):
            raise ValueError(f'{key} rankings missing/too short')
        unique = {}
        for i,entry in enumerate(src):
            sid = str(entry.get('speciesId') or '')
            if sid and sid not in unique:
                unique[sid] = {'rank':i+1, 'score':entry.get('score'), 'moves':entry.get('moveset') or []}
        ranks[cap] = unique
    species_csv, names_csv = parse_csv(raws['species']), parse_csv(raws['names'])
    if len(species_csv)<(700 if strict else 2) or len(names_csv)<(500 if strict else 1):
        raise ValueError('PokeAPI species CSV truncated')
    species={}
    for row in species_csv:
        dex=safe_int(row.get('id'))
        if not dex: continue
        species[str(dex)] = {'dex':dex, 'identifier':row.get('identifier') or '', 'parent':safe_int(row.get('evolves_from_species_id')),
            'chain':safe_int(row.get('evolution_chain_id')),
            'legendary':row.get('is_legendary')=='1', 'mythical':row.get('is_mythical')=='1'}
    for row in names_csv:
        if row.get('local_language_id') != '3':continue
        dex=row.get('pokemon_species_id')
        if dex in species: species[dex]['ko']=row.get('name')
    pk=[]
    for x in pokemons:
        sid=x.get('speciesId')
        dex=safe_int(x.get('dex'))
        if not sid or not dex or not isinstance(x.get('baseStats'),dict):continue
        base=x['baseStats']
        if not all(k in base for k in ('atk','def','hp')):continue
        fam=x.get('family') or {}
        pk.append({'id':sid,'dex':dex,'species_identifier':(species.get(str(dex)) or {}).get('identifier') or '', 'en':x.get('speciesName') or sid,
          'base':{a:int(base[a]) for a in ('atk','def','hp')},
          'types':x.get('types') or [],'tags':x.get('tags') or [],
          'quick':x.get('fastMoves') or [],'charge':x.get('chargedMoves') or [],
          'elite':x.get('eliteMoves') or [],'evos':fam.get('evolutions') or [],
          'released':x.get('released',True) is not False})
    if len(pk)<(700 if strict else 2):raise ValueError('Too few valid PvPoke Pokemon entries')
    # A complete name index is not equivalent to PvPoke's battle-eligible list.
    # Keep absent species searchable but NEVER synthesize GO stats, moves or release status.
    if strict:
        represented={p['dex'] for p in pk}
        for raw_dex, s in species.items():
            dex=int(raw_dex)
            if dex in represented: continue
            pk.append({'id':f'dex_{dex}_catalog_only','dex':dex,'species_identifier':s.get('identifier') or '', 'en':s.get('ko') or f'Pokedex #{dex}',
              'base':None,'types':[],'tags':[],'quick':[],'charge':[],
              'elite':[],'evos':[],'released':None,'catalog_only':True})

    pvp_moves = {}
    for m in gm.get('moves') or []:
        if isinstance(m,dict) and m.get('moveId'):
            pvp_moves[m['moveId']] = {k:m[k] for k in ('power','energy','energyGain','cooldown','type') if k in m}
    raid={'available':False, 'fast':{}, 'charged':{},'learnsets':{}, 'freshness':'source not verified'}
    optional_keys=('raid_fast','raid_charged','raid_learnsets')
    if all(k in raws for k in optional_keys):
        try:
            rfast = _normalize_move_map(json.loads(raws['raid_fast']))
            rcharged = _normalize_move_map(json.loads(raws['raid_charged']))
            sets = json.loads(raws['raid_learnsets'])
            learnsets={}
            for p in sets if isinstance(sets,list) else []:
                dex=safe_int(p.get('pokemon_id'))
                if not dex:continue
                form=str(p.get('form') or 'Normal').lower()
                learnsets[f'{dex}:{form}']={
                    'fast':p.get('fast_moves') or [], 'charge':p.get('charged_moves') or [],
                    'elite_fast':p.get('elite_fast_moves') or [],'elite_charge':p.get('elite_charged_moves') or []}
            # Require nonempty usable move pools and actual joins across the three files.
            linked = sum(bool(set(m.lower() for m in v['fast']) & rfast.keys()) and
                         bool(set(m.lower() for m in v['charge']) & rcharged.keys())
                         for v in learnsets.values())
            if len(rfast)>25 and len(rcharged)>40 and len(learnsets)>100 and linked>=20:
                raid={'available':True,'fast':rfast, 'charged':rcharged,'learnsets':learnsets,
                      'freshness':'source_version_unverified', 'linked_species':linked}
            else:
                print(f'Raid provider rejected: fast={len(rfast)}, charged={len(rcharged)}, '
                      f'learnsets={len(learnsets)}, joined={linked}', file=sys.stderr)
        except (ValueError,TypeError,KeyError):pass
    now = now or dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
    # An absent/old Last-Modified HTTP header does not make otherwise valid
    # PvE move data structurally invalid. Keep the numbers available for a
    # *labelled reference-only estimate*, never claim that they describe the
    # live battle meta. SHA256 provenance and content validation are separate
    # from upstream game-version freshness.
    if raid['available']:
        provider_headers = provider_headers or {}
        modified = []
        missing_date = False
        for k in optional_keys:
            value = provider_headers.get(SOURCES[k], {}).get('last_modified')
            try:
                d = email.utils.parsedate_to_datetime(value).astimezone(dt.timezone.utc)
                modified.append(d)
            except (TypeError, ValueError, IndexError, AttributeError):
                missing_date = True
        now_dt = dt.datetime.fromisoformat(now.replace('Z', '+00:00')).astimezone(dt.timezone.utc)
        ages = [(now_dt - d).days for d in modified]
        if missing_date or len(modified) < len(optional_keys):
            raid['freshness'] = 'upstream_date_unavailable'
        elif all(0 <= age <= 90 for age in ages):
            raid['freshness'] = 'http_modified_recent_unconfirmed_game'
        else:
            raid['freshness'] = 'upstream_date_old_unconfirmed_game'
        raid['upstream_last_modified'] = [d.isoformat() for d in modified]
        raid['counts'] = {'fast':len(raid['fast']), 'charged':len(raid['charged']), 'learnsets':len(raid['learnsets'])}
    else:
        raid['counts'] = {'fast':0, 'charged':0, 'learnsets':0}
    source_info={k:{'url':SOURCES[k], 'sha256':hashlib.sha256(v).hexdigest()} for k,v in raws.items() if k in SOURCES}
    return {'schema':3,'generated_at':now,'pvpoke_timestamp':gm.get('timestamp') or None,
        'sources':source_info, 'pokemon':pk,'species':species,'ranks':ranks,'pvp_moves':pvp_moves,'raid':raid}


def main():
    downloaded={}
    for k,u in SOURCES.items():
        try:
            print(f'Retrieving {k} ...', flush=True)
            downloaded[k]=download(u)
        except Exception as e:
            if k in REQUIRED: raise RuntimeError(f'Mandatory source {k} unavailable; retained previous snapshot') from e
            print(f'Optional provider {k} failed ({e}); raid data not refreshed',file=sys.stderr)
    if any(k not in downloaded for k in REQUIRED):raise RuntimeError('Mandatory sources missing')
    if any(k not in downloaded for k in ('raid_fast','raid_charged','raid_learnsets')) and TARGET.exists():
        print('Optional raid provider partially unavailable. Retaining last validated raid data if possible.')
    out=build_catalog(downloaded,provider_headers=PROVIDER_HEADERS)
    if not out['raid']['available'] and TARGET.exists():
        try:
            old=json.loads(TARGET.read_text(encoding='utf-8'))
            if old.get('schema')==3 and old.get('raid',{}).get('available'):
                out['raid']=old['raid']
                for k in ('raid_fast','raid_charged','raid_learnsets'):
                    if k in old.get('sources',{}):out['sources'][k]=old['sources'][k]
                out['raid_source_stale']=True
        except (OSError,ValueError): pass
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    blob=json.dumps(out,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    with tempfile.NamedTemporaryFile('wb',dir=TARGET.parent,prefix='.snapshot-',delete=False) as fd:
        fd.write(blob)
        name=fd.name
    os.replace(name,TARGET)
    print(f'Published {len(out["pokemon"])} forms, {len(out["species"])} species, {len(blob):,} bytes; '
          f'raid provider={out["raid"]["available"]}, freshness={out["raid"]["freshness"]}, '
          f'counts={out["raid"].get("counts")}, joined={out["raid"].get("linked_species", 0)}')

if __name__=='__main__':
    from v5_sync import run
    run()
