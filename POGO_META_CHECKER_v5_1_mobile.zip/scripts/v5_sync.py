#!/usr/bin/env python3
"""Event-sensitive PvP/PvE snapshot updater for POGO META CHECKER v5.

Poll *small* change signals (GitHub raw ETag / PoGoAPI hashes). No
meaningful change -> keep the existing catalog byte-identical. On changes,
validate source data, re-evaluate the affected domains, and emit an optional
small incremental patch. A failed poll never implies that value is stable.
"""
from __future__ import annotations
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import urllib.error
import urllib.request

import update_data as base

ROOT=base.ROOT
DATA=ROOT/'data'
CATALOG=DATA/'catalog.json'
INDEX=DATA/'meta-index.json'
CHANGES=DATA/'changes.json'
PATCH=DATA/'patch.json'
CACHE=ROOT/'.source-cache'
HASH_ENDPOINT='https://pogoapi.net/api/v1/api_hashes.json'
SOURCES=base.SOURCES
RAID_KEYS=('raid_fast','raid_charged','raid_learnsets')
SIGNAL_REQUIRED=tuple(SOURCES)
SCHEMA=1


def timestamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def stable_json(value) -> bytes:
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')


def digest(value) -> str:
    return hashlib.sha256(stable_json(value)).hexdigest()


def atomic_json(path:Path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    b=stable_json(value)
    with tempfile.NamedTemporaryFile('wb',dir=path.parent,prefix='.v5-',delete=False) as f:
        f.write(b); name=f.name
    os.replace(name,path)
    return len(b)


def json_file(path:Path):
    try:return json.loads(path.read_text('utf-8'))
    except (OSError,ValueError):return None


def request(url, *,method='GET',headers=None,limit=18_000_000):
    hdr={'User-Agent':base.USER_AGENT,'Accept':'application/json,text/csv,*/*'}
    hdr.update(headers or {})
    req=urllib.request.Request(url,method=method,headers=hdr)
    with urllib.request.urlopen(req,timeout=35) as r:
        raw=r.read(limit+1) if method!='HEAD' else b''
        if len(raw)>limit:raise ValueError('Oversized upstream payload')
        return raw,r.headers


def signature_probe(old_signatures, raw_prefetch=None):
    """Probes, never trusting freshness if any provider cannot be checked.

    For non-PoGoAPI sources ETag is preferred; if absent, GET + SHA-256.
    If a server reports 304, it is comparable only to an existing signature.
    PoGoAPI's verified-published hashes are a cheap change signal.
    """
    if raw_prefetch is None:raw_prefetch={}
    hashed={}
    old_signatures=old_signatures or {}
    signals={}
    probe_errors={}
    try:
        raw,_=request(HASH_ENDPOINT,limit=300_000)
        obj=json.loads(raw)
        if not isinstance(obj,dict):raise ValueError('PoGoAPI hash index invalid')
        for k in RAID_KEYS:
            name=SOURCES[k].rsplit('/',1)[-1]
            val=obj.get(name,{}).get('hash_sha256')
            if not isinstance(val,str) or not re.fullmatch(r'[a-f0-9]{64}',val):
                raise ValueError(f'PoGoAPI hash for {name} unavailable')
            hashed[k]='sha256:'+val
    except Exception as e:
        for k in RAID_KEYS:probe_errors[k]=f'Hash endpoint: {type(e).__name__}: {e}'
    for k,url in SOURCES.items():
        if k in hashed:
            signals[k]=hashed[k]
            continue
        if k in RAID_KEYS:
            # Optional provider polling failure must not claim a positive verification.
            continue
        try:
            _,heads=request(url,method='HEAD')
            tag=heads.get('ETag')
            if tag:
                signals[k]='etag:'+tag
            else:
                raw,_=request(url)
                if len(raw)<100:raise ValueError('Unexpected small upstream data')
                raw_prefetch[k]=raw
                signals[k]='sha256:'+hashlib.sha256(raw).hexdigest()
        except Exception as e:
            # Some CDNs don't support HEAD: safely fall back to a GET.
            try:
                raw,_=request(url)
                if len(raw)<100:raise ValueError('Unexpected small upstream data')
                raw_prefetch[k]=raw
                signals[k]='sha256:'+hashlib.sha256(raw).hexdigest()
            except Exception as sub:
                probe_errors[k]=f'{type(sub).__name__}: {sub}'
    return signals,probe_errors


def fetch_changed_sources(signals, downloaded):
    CACHE.mkdir(exist_ok=True)
    for k,url in SOURCES.items():
        if k in downloaded:continue
        # Cached inputs only count when their contents exactly match the saved
        # signature. ETag is an HTTP header, not a digest; cache proof stored in
        # the cache manifest (recorded when the download succeeded).
        p=CACHE/f'{k}.bin'
        manifest=json_file(CACHE/'manifest.json') or {}
        if p.is_file() and manifest.get(k,{}).get('signal')==signals.get(k):
            raw=p.read_bytes()
            if hashlib.sha256(raw).hexdigest()==manifest[k].get('sha256'):
                downloaded[k]=raw
                continue
        try:
            raw=base.download(url)
            # A signal checked shortly before downloading can race a provider
            # update. Validate PoGoAPI bytes against the advertised digest.
            signal=signals.get(k,'')
            if signal.startswith('sha256:') and hashlib.sha256(raw).hexdigest()!=signal[7:]:
                raise ValueError(f'{k} changed during check; retry later')
            downloaded[k]=raw
            p.write_bytes(raw)
            manifest[k]={'signal':signal,'sha256':hashlib.sha256(raw).hexdigest()}
            atomic_json(CACHE/'manifest.json',manifest)
        except Exception as e:
            if k in base.REQUIRED:raise RuntimeError(f'Required provider {k} failed: {e}') from e
            print(f'Optional raid provider {k} unavailable: {e}',file=sys.stderr)
    return downloaded


def form_token(v):
    return re.sub(r'[^a-z0-9]','',str(v or '').lower())


def raid_learnset(p,raid):
    sets=raid.get('learnsets') or {}
    dex=p.get('dex'); sid=str(p.get('id','')).lower()
    forms={k.split(':',1)[1]:v for k,v in sets.items() if k.startswith(f'{dex}:')}
    if not forms:return None
    if dex==888: wanted=['crownedsword','crowned'] if 'crowned' in sid else ['hero','heroofmanybattles']
    elif dex==889: wanted=['crownedshield','crowned'] if 'crowned' in sid else ['hero','heroofmanybattles']
    else:
        cleaned=re.sub(r'_shadow$|_mega(?:_[xy])?$|_primal$','',sid)
        base_id=form_token(p.get('species_identifier'))
        entire=form_token(cleaned)
        if base_id and entire==base_id:
            wanted=['normal']
        elif base_id and entire.startswith(base_id):
            wanted=[entire[len(base_id):]]
        else:
            # If the base species identifier is not provided (older data),
            # defer to an explicitly named form or a unique Normal learnset.
            wanted=[form_token(cleaned.split('_',1)[1])] if '_' in cleaned else ['normal']
            if 'normal' in forms and wanted!=['normal'] and not base_id:
                wanted.append('normal')
    for want in wanted:
        for k,v in forms.items():
            if form_token(k)==want:return v
    if wanted==['normal'] and len(forms)==1 and 'crowned' not in next(iter(forms)):
        return next(iter(forms.values()))
    return None


def raid_strength(p,raid):
    if not raid.get('available') or not isinstance(p.get('base'),dict):return None
    learn=raid_learnset(p,raid)
    if not learn:return None
    options=[]
    fast=raid.get('fast') or {}; charged=raid.get('charged') or {}
    for name in set((learn.get('fast') or [])+(learn.get('elite_fast') or [])):
        f=fast.get(str(name).lower())
        if not f or f.get('energy',0)<=0 or f.get('ms',0)<=0:continue
        for cn in set((learn.get('charge') or [])+(learn.get('elite_charge') or [])):
            c=charged.get(str(cn).lower())
            if not c or c.get('energy',0)>=0 or c.get('ms',0)<=0:continue
            hits=max(1,__import__('math').ceil(-c['energy']/f['energy']))
            typ=c.get('type')
            stabf=1.2 if f.get('type') in p.get('types',[]) else 1.0
            stabc=1.2 if typ in p.get('types',[]) else 1.0
            dps=(hits*f['power']*stabf+c['power']*stabc)/(hits*f['ms']+c['ms'])*1000
            shadow=1.2 if sid_shadow(p) else 1.0
            strength=dps*(p['base']['atk']+15)*shadow/100.0
            options.append((strength,typ,str(name),str(cn)))
    return max(options) if options else None


def sid_shadow(p):return str(p.get('id','')).endswith('_shadow')


def rocket_heuristic(p,move_map):
    """Roster-free generic grunt heuristic. NOT leader/Giovanni simulation."""
    if not isinstance(p.get('base'),dict):return None
    pairs=[]
    for f in p.get('quick',[]):
        fm=move_map.get(f) or {}
        if not isinstance(fm.get('energyGain'),(int,float)) or fm['energyGain']<=0:continue
        for c in p.get('charge',[]):
            cm=move_map.get(c) or {}
            cost=cm.get('energy'); turns=fm.get('cooldown')
            if not isinstance(cost,(int,float)) or cost<=0 or not isinstance(turns,(int,float)) or turns<=0:continue
            import math
            pairs.append((math.ceil(cost/fm['energyGain'])*turns, f,c))
    if not pairs:return None
    turns,f,c=min(pairs)
    # Strictly illustrative: faster charged attacks help shield consumption.
    # NOT a current-rotation-specific counter recommendation.
    grade=3 if turns<=9 else 2 if turns<=15 else 1
    return {'grade':grade,'turns':round(turns,1),'fast':f,'charged':c,
            'kind':'grunt_generic_heuristic','confidence':'low_no_roster'}


def league_grade(rank):
    if rank is None:return None
    return 3 if rank<=60 else 2 if rank<=200 else 1 if rank<=450 else 0


def compute_valuations(catalog):
    pokemon=catalog.get('pokemon') or []
    raid=catalog.get('raid') or {}
    moves=catalog.get('pvp_moves') or {}
    scores={p['id']:raid_strength(p,raid) for p in pokemon if p.get('id')}
    maxima={}
    for p in pokemon:
        score=scores.get(p['id'])
        if not score or sid_shadow(p) or any(t in p['id'] for t in ('_mega','_primal')) or p.get('released') is False:continue
        typ=score[1]
        if typ in p.get('types',[]):maxima[typ]=max(maxima.get(typ,0),score[0])
    output={}
    for p in pokemon:
        sid=p.get('id')
        if not sid:continue
        record={'dex':p['dex']}
        for cap in ('1500','2500','10000'):
            rank=catalog.get('ranks',{}).get(cap,{}).get(sid,{}).get('rank')
            record[cap]={'grade':league_grade(rank),'rank':rank,'confidence':'pvpoke_ranking' if rank is not None else 'not_ranked'}
        rs=scores.get(sid)
        if rs and maxima.get(rs[1],0):
            rel=rs[0]/maxima[rs[1]]
            g=3 if rel>=.84 else 2 if rel>=.67 else 1 if rel>=.45 else 0
            record['raid']={'grade':g,'ratio':round(rel,4),'type':rs[1],'fast':rs[2],'charged':rs[3],
                            'confidence':'reference_only_not_boss_simulation'}
        else:record['raid']={'grade':None,'confidence':'missing_pve_or_form_data'}
        record['rocket']=rocket_heuristic(p,moves) or {'grade':None,'confidence':'missing_pvp_move_data'}
        output[sid]=record
    return output


def content_semantics(cat):
    rd=cat.get('raid') or {}
    return {'pokemon':cat.get('pokemon'), 'species':cat.get('species'),
            'ranks':cat.get('ranks'),'pvp_moves':cat.get('pvp_moves'),
            'raid':{k:rd.get(k) for k in ('available','fast','charged','learnsets')},
            'valuation':cat.get('valuation')}


def assess_changes(old,new):
    if not old or not old.get('valuation'):
        return {'type':'initial_baseline','affected':[],'counts':{'up':0,'down':0,'changed':0,'unchanged':0},
                'note':'첫 검증 기준선 생성. 이전 등급과 비교한 상승·하락 판정 없음.'}
    oldvals=old.get('valuation') or {};newvals=new.get('valuation') or {}
    changes=[]; counts={'up':0,'down':0,'changed':0,'unchanged':0}
    domains=['raid','rocket','1500','2500','10000']
    for sid in sorted(set(oldvals)|set(newvals)):
        a=oldvals.get(sid,{}) or {}; b=newvals.get(sid,{}) or {}
        for domain in domains:
            x=a.get(domain) or {}; y=b.get(domain) or {}
            if x==y:
                counts['unchanged']+=1
                continue
            prev=x.get('grade');cur=y.get('grade')
            label='changed'
            if isinstance(prev,int) and isinstance(cur,int):
                label='up' if cur>prev else 'down' if cur<prev else 'changed'
            changes.append({'id':sid,'dex':b.get('dex') or a.get('dex'),'domain':domain,
              'old':prev,'new':cur,'trend':label,
              'detail':'별점 변경' if prev!=cur else '기술·순위·추정 수치 변경 (별점 유지)'})
            counts[label]+=1
    return {'type':'comparison' if changes else 'no_value_change','affected':changes,'counts':counts,'note':'종족·형태 기준 평가 비교. 입력 IV 및 실제 대진에 따른 결과는 별도.'}


def make_patch(old,new):
    """One-version delta for clients with a validated exact previous version."""
    if not old or not old.get('meta_version'):return None
    patch={'schema':1,'from_version':old['meta_version'],'to_version':new['meta_version'],
           'top':{},'maps':{},'pokemon':{'set':{},'delete':[]}}
    for k in ('schema','meta_schema','meta_version','generated_at','pvpoke_timestamp','sources','source_signatures','raid_source_stale'):
        if old.get(k)!=new.get(k):patch['top'][k]=new.get(k)
    for k in ('species','pvp_moves','valuation'):
        a=old.get(k) or {};b=new.get(k) or {}
        update={key:v for key,v in b.items() if key not in a or a[key]!=v}
        delete=[key for key in a if key not in b]
        if update or delete:patch['maps'][k]={'set':update,'delete':delete}
    for k in ('ranks','raid'):
        a=old.get(k) or {};b=new.get(k) or {}
        sub={}
        for sk in set(a)|set(b):
            av=a.get(sk);bv=b.get(sk)
            if isinstance(av,dict) and isinstance(bv,dict):
                update={key:v for key,v in bv.items() if key not in av or av[key]!=v}
                delete=[key for key in av if key not in bv]
                if update or delete:sub[sk]={'kind':'map','set':update,'delete':delete}
            elif av!=bv:sub[sk]={'kind':'value','value':bv}
        if sub:patch['maps'][k]=sub
    a={p['id']:p for p in old.get('pokemon',[]) if p.get('id')}
    b={p['id']:p for p in new.get('pokemon',[]) if p.get('id')}
    patch['pokemon']['set']={key:v for key,v in b.items() if key not in a or a[key]!=v}
    patch['pokemon']['delete']=[key for key in a if key not in b]
    return patch


def run():
    DATA.mkdir(parents=True,exist_ok=True)
    previous=json_file(CATALOG)
    old_index=json_file(INDEX) or {}
    now=timestamp()
    cached_files={}
    previous_sig=old_index.get('source_signatures') if old_index.get('schema')==1 else None
    signals,errors=signature_probe(previous_sig,cached_files)
    verified_all=not errors and len(signals)==len(SOURCES)
    if errors:
        # Fail-closed: keep the last validated rating snapshot. No claim that
        # all provider data was checked. A previous usable catalog stays usable.
        print('Provider signal check incomplete: '+str(errors),file=sys.stderr)
        if not previous:raise RuntimeError('No baseline and upstream check unavailable')
        updated=dict(old_index)
        updated.update({'schema':1,'monitor_status':'incomplete','last_attempt_at':now,
                        'provider_errors':errors,'note':'일부 데이터 공급원을 확인하지 못함. 이전 검증 결과 보존.'})
        atomic_json(INDEX,updated)
        print('INCOMPLETE: retained last validated catalog without claiming value stability.')
        return
    changed_sources=[k for k in SOURCES if (previous_sig or {}).get(k)!=signals.get(k)]
    if previous and previous.get('meta_schema')==5 and not changed_sources:
        latest=dict(old_index)
        latest.update({'schema':1,'version':previous['meta_version'],'monitor_status':'verified',
                       'last_checked_at':now,'last_attempt_at':now,'provider_errors':{},
                       'source_signatures':signals,'changed_sources':[],'latest_change_count':0,
                       'assessment':'unchanged','note':'원천 자료 변경 신호 없음; 종족별 가치 재평가 생략.'})
        atomic_json(INDEX,latest)
        print('UNCHANGED: verified provider signatures; catalog not rebuilt, no new download for app.')
        return
    print('Changed provider signals: '+', '.join(changed_sources or ['migration to v5']))
    try:
        raw=fetch_changed_sources(signals,cached_files)
        if any(k not in raw for k in SOURCES):
            raise RuntimeError('Required or optional input missing; cannot verify PvP/PvE together')
        new=base.build_catalog(raw,strict=True,provider_headers=base.PROVIDER_HEADERS,now=now)
        if not new.get('raid',{}).get('available'):
            raise RuntimeError('Raid data sources did not form a valid linked dataset')
    except (RuntimeError,ValueError,TypeError,KeyError) as exc:
        if not previous:raise
        updated=dict(old_index)
        updated.update({'schema':1,'monitor_status':'incomplete','last_attempt_at':now,
            'provider_errors':{'rebuild':str(exc)},
            'note':'데이터 연결 검증 실패로 이전 검증 결과 유지. 최신 상태 확인 불가.'})
        atomic_json(INDEX,updated)
        print('INCOMPLETE: updated inputs failed full validation; preserved old catalog.',file=sys.stderr)
        return
    new['meta_schema']=5
    new['valuation']=compute_valuations(new)
    new['meta_version']=digest(content_semantics(new))[:24]
    new['source_signatures']=signals
    if previous and previous.get('meta_schema')==5 and previous.get('meta_version')==new['meta_version']:
        # An upstream data file changed but its content did not affect actual
        # indexed values; do not rewrite the semantic snapshot.
        latest=dict(old_index)
        latest.update({'schema':1,'version':previous['meta_version'],
            'monitor_status':'verified','last_checked_at':now,'last_attempt_at':now,
            'provider_errors':{},'source_signatures':signals,'changed_sources':changed_sources,
            'latest_change_count':0,'assessment':'unaffected','note':'원천 업데이트 확인; 분석 값 변화 없음.'})
        atomic_json(INDEX,latest)
        print('UNAFFECTED: upstream changed but value-bearing data unchanged; preserved catalog.')
        return
    changes=assess_changes(previous,new)
    changes['version']=new['meta_version']
    changes['checked_at']=now
    full_bytes=stable_json(new)
    patch=make_patch(previous,new)
    if patch and len(stable_json(patch))<len(full_bytes)*.80:
        atomic_json(PATCH,patch)
        patch_meta={'path':'./data/patch.json','from_version':patch['from_version'],
                    'to_version':patch['to_version']}
        print(f'Incremental patch: {PATCH.stat().st_size:,} bytes vs full {len(full_bytes):,} bytes')
    else:
        PATCH.unlink(missing_ok=True)
        patch_meta=None
    atomic_json(CATALOG,new)
    atomic_json(CHANGES,changes)
    status={'schema':1,'version':new['meta_version'],'monitor_status':'verified',
      'last_checked_at':now,'last_attempt_at':now,'baseline_at':old_index.get('baseline_at') or now,
      'changed_at':now,'source_signatures':signals,'changed_sources':changed_sources,
      'latest_change_count':len(changes['affected']),
      'assessment':changes['type'],'note':changes['note'],
      'patch':patch_meta,'catalog':'./data/catalog.json','changes':'./data/changes.json',
      'sources':{'provider':'PvPoke/PokeAPI/PoGoAPI','game_version_confirmed':False},
      'provider_errors':{}}
    atomic_json(INDEX,status)
    print(f'UPDATED: {len(new["pokemon"])} forms / {len(new["species"])} species, '
          f'snapshot {len(full_bytes):,} bytes, version={new["meta_version"]}, '
          f'changes={len(changes["affected"])}, raid={new["raid"]["available"]}')

if __name__=='__main__':run()
