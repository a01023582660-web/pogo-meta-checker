"""Minimal *non-authoritative* starter set, for offline IV and image evolution demo only."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
lines=[
[(231,'코코리','phanpy'),(232,'코리갑','donphan')],
[(859,'메롱꿍','impidimp'),(860,'쏘겨모','morgrem'),(861,'오롱털','grimmsnarl')],
[(653,'푸호꼬','fennekin'),(654,'테르나','braixen'),(655,'마폭시','delphox')],
[(161,'꼬리선','sentret'),(162,'다꼬리','furret')],
[(957,'어리짱','tinkatink'),(958,'벼리짱','tinkatuff'),(959,'두드리짱','tinkaton')],
[(25,'피카츄','pikachu'),(26,'라이츄','raichu')],
[(133,'이브이','eevee'),(134,'샤미드','vaporeon'),(135,'쥬피썬더','jolteon'),(136,'부스터','flareon'),(196,'에브이','espeon'),(197,'블래키','umbreon'),(470,'리피아','leafeon'),(471,'글레이시아','glaceon'),(700,'님피아','sylveon')],
[(1,'이상해씨','bulbasaur'),(2,'이상해풀','ivysaur'),(3,'이상해꽃','venusaur')],
[(4,'파이리','charmander'),(5,'리자드','charmeleon'),(6,'리자몽','charizard')],
[(359,'앱솔','absol')],[(777,'토게데마루','togedemaru')],[(132,'메타몽','ditto')],[(382,'가이오가','kyogre')],[(383,'그란돈','groudon')],[(150,'뮤츠','mewtwo')],
]
pokemon=[];species={}
for chain,ln in enumerate(lines,1):
    for pos,(dex,ko,en) in enumerate(ln):
        parent=ln[pos-1][0] if pos and ln[0][0]!=133 else (ln[0][0] if pos else None)
        species[str(dex)]={'dex':dex,'parent':parent,'chain':chain,'ko':ko,'legendary':dex in (150,382,383),'mythical':False}
        pokemon.append({'id':en,'dex':dex,'en':en.title(),'base':None,'types':[],'tags':[], 'quick':[],'charge':[],'elite':[], 'evos':[],'released':True})
obj={'schema':3,'generated_at':None,'pvpoke_timestamp':None,'sample':True,
     'sources':{},'pokemon':pokemon,'species':species,'ranks':{'1500':{},'2500':{},'10000':{}},
     'pvp_moves':{},'raid':{'available':False,'fast':{},'charged':{},'learnsets':{}}}
(ROOT/'data'/'starter.js').write_text('window.POGO_STARTER = '+json.dumps(obj,ensure_ascii=False,separators=(',',':'))+';\n', encoding='utf-8')
print('seed entries:',len(pokemon))
