/* PWA shell cached offline; data snapshots are always network-first. */
const SHELL='pogo-meta-v5.1-shell-20261114';
const DATA='pogo-meta-v5-data';
const OFFLINE=['./','./index.html','./style.css','./app.js','./data/starter.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(SHELL).then(cache=>cache.addAll(OFFLINE)));
  self.skipWaiting();
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('pogo-meta-')&&![SHELL,DATA].includes(k)).map(k=>caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin || url.pathname.includes('/api/'))return;
  if(url.pathname.includes('/data/') && (url.pathname.endsWith('catalog.json')||url.pathname.endsWith('meta-index.json')||url.pathname.endsWith('changes.json')||url.pathname.endsWith('patch.json'))){
    event.respondWith((async()=>{
      const cache=await caches.open(DATA);
      const canonical=new URL(url.pathname.split('/').pop(),new URL('./data/',self.registration.scope));
      try{
        const network=await fetch(event.request);
        if(!network.ok)throw Error('No validated snapshot');
        const payload=await network.clone().json();
        if(url.pathname.endsWith('catalog.json') && (payload.schema!==3||!Array.isArray(payload.pokemon)||payload.pokemon.length<700))throw Error('Invalid snapshot');
        if(url.pathname.endsWith('meta-index.json') && (payload.schema!==1||!payload.version))throw Error('Invalid meta-index');
        await cache.put(canonical.href,network.clone());
        return network;
      }catch{return (await cache.match(canonical.href))||new Response('No valid snapshot',{status:503});}
    })());return;
  }
  if(event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).catch(async()=>((await caches.open(SHELL)).match('./index.html'))));return;
  }
  event.respondWith((async()=>{
    const cache=await caches.open(SHELL);
    const cached=await cache.match(event.request,{ignoreSearch:true});
    if(cached)return cached;
    try{return await fetch(event.request)}catch{return Response.error()}
  })());
});
