# External sources and trademark notices

PvPoke (game data / rankings): https://github.com/pvpoke/pvpoke — MIT license. Include its original license in derivative distributions if source code/files are redistributed.
PokeAPI (Pokédex localization and evolution relationships): https://github.com/PokeAPI/pokeapi — observe upstream license and attribution notes.
Pokémon sprites/artwork (remote images): https://github.com/PokeAPI/sprites — individual character images may be separately copyrighted and are not automatically licensed as PokeAPI repository code.
PoGoAPI (GO-specific raid move data): https://pogoapi.net/documentation/ — check API usage requirements before publication and cache data responsibly.
Pokébattler (research for next version): https://beta.pokebattler.com/developers — not ingested or simulated in v3; requires attribution and respect for site fair use.

Not endorsed by or affiliated with Niantic, Scopely, The Pokémon Company, Game Freak, or Nintendo. Pokémon character names and images belong to their owners. No paid/large-scale publication rights are asserted here.
