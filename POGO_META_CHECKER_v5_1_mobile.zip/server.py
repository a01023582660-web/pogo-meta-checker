"""POKÉMON GO META ESSENTIAL CHECKER - local server + optional live AI analyzer.

Run: OPENAI_API_KEY=... python server.py
No key: offline/basic mode via publicly fetched PvPoke files in the browser.
"""
import json
import os
import urllib.request
import urllib.error
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8765"))
OPENAI_URL = "https://api.openai.com/v1/responses"

SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "pokemon": {"type":"string"},
        "evaluated_form": {"type":"string"},
        "classification": {"type":"string"},
        "raid": {"type":"string"},
        "raid_detail": {"type":"string"},
        "pvp_great": {"type":"string"},
        "pvp_ultra": {"type":"string"},
        "pvp_master": {"type":"string"},
        "rocket_grunt": {"type":"string"},
        "rocket_leader": {"type":"string"},
        "rocket_giovanni": {"type":"string"},
        "rocket_detail": {"type":"string"},
        "max_battle": {"type":"string"},
        "max_detail": {"type":"string"},
        "form_comparison": {"type":"string"},
        "form_eligibility": {"type":"string"},
        "moves": {"type":"string"},
        "elite_move_warning": {"type":"string"},
        "verdict": {"type":"string"},
        "investment": {"type":"string"},
        "reason": {"type":"string"},
        "verified_as_of": {"type":"string"},
        "sources": {"type":"array", "items": {"type":"string"}},
        "caveat": {"type":"string"}
    },
    "required": [
        "pokemon", "evaluated_form", "classification", "raid", "raid_detail",
        "pvp_great", "pvp_ultra", "pvp_master", "rocket_grunt",
        "rocket_leader", "rocket_giovanni", "rocket_detail", "max_battle", "max_detail",
        "form_comparison", "form_eligibility", "moves",
        "elite_move_warning", "verdict", "investment", "reason", "verified_as_of", "sources", "caveat"
    ]
}

INSTRUCTION = """너는 POKÉMON GO META ESSENTIAL CHECKER다. 한국어로만 간결하고 정확하게 답해라.
사용자가 제공한 포켓몬의 이름, 현재 개체값(공격/방어/체력), 정확히 선택한 보유/활용 형태를 분석한다.
1. 질문 시점 공식 게임 공지, PvPoke 일반/그림자 리그별 랭킹, Pokebattler 또는 검증된 레이드, GO로켓단 로테이션을 검색하고 교차검증한다. 검증하지 못한 출처·순위·날짜·현재 등장 여부는 지어내지 말고 '최신 검증 필요'라고 표시한다.
2. 분류는 일반/전설/환상/울트라비스트, 평가에는 실제 게임에 구현된 최종 진화체를 포함한다. 선택된 form은 절대 무시하지 말고 동일 종족이라도 별도 평가한다.
3. form=shadow: 피해량 +20%, 받는 피해 +20%, 더 높은 강화 비용, 화풀이 기술 해제 제한을 반영하고 일반형 PvP 순위를 그림자 순위로 복사하지 마라. 그림자 구현이 확인되지 않으면 확인 불가로 표시. 그림자는 메가진화할 수 없다.
4. form=purified: 현재 입력한 IV는 정화 후 수치이므로 +2를 재적용하지 않는다. 그림자 보너스는 없음. 은혜갚기와 강화비용 절감을 고려해라. 정화 가능성은 현재 종족의 그림자 존재 여부와 다르다.
5. form=dynamax/gigantamax: 일반 포켓몬은 자동으로 맥스 개체가 되지 않는다. 맥스배틀 성능과 전용 맥스기술, 구현 여부를 별도 평가한다. 해당 형태가 게임에 없다면 '검증 필요/사용 불가'라고 정직하게 표시. 배틀리그에서는 맥스 변신 불가하지만 보통 모습으로 참여 가능하다.
6. form=mega/primal: 보유 형태가 아니라 배틀 중 일시 변신 능력/활용 의도를 가리킨다. 종족별 구현 가능 여부 확인. 메가/원시 변신 상태는 통상의 GO배틀리그 참가 불가(특별 규칙 예외), 일반형과 별도로 레이드 평가. 맥스 포켓몬도 메가진화 자격이 있지만 동시에 맥스 변신을 할 수는 없다.
7. 레이드/PvP/로켓단/맥스배틀 평가는 ★★★/★★☆/★☆☆/☆☆☆ 또는 '최신 검증 필요' / '참가 불가'. 로켓단은 상대 기술·실드와 현 로테이션을 고려하며 근거 없는 개별 승리를 보장하지 않는다. 맥스배틀 평가는 해당 모드 중심으로 작성하라.
8. 현재 IV %는 (공+방+체)/45×100 반올림한 수치. 고IV가 PvP 최적인 것은 아니고 레벨·현재 CP·실제 기술·개체의 맥스 여부를 IV만으로 추정하지 않는다.
9. 이벤트/대단한 기술머신 사용이 필요하면 경고. 투자 판단은 🔥 필수 확보·육성 / ✅ 육성 추천 / ⚖️ 조건부 육성 / ⏸️ 육성 보류 / ❌ 육성 비추천 중 정확히 한 개.
10. form_eligibility에는 선택한 형태를 실제 게임에 사용할 수 있는지 및 다른 형태와의 전환·중첩 제한을 간단히 기록하라. form_comparison에는 현재 일반형과 그림자, 정화, 메가, 다이맥스 중 의미 있는 다른 형태와의 차이를 적되 데이터 없으면 검증 필요 표시. sources에는 실제 확인한 출처의 이름·정확한 URL만 넣어라.
정해진 JSON 스키마만 출력하라."""

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, fmt, *args):
        print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), fmt % args))

    def do_GET(self):
        if self.path == "/api/status":
            return self.send_json(200, {"ai_enabled":bool(os.getenv("OPENAI_API_KEY")),"model":os.getenv("OPENAI_MODEL", "gpt-5")})
        return super().do_GET()

    def send_json(self, code, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        if self.path != '/api/analyze':
            return self.send_json(404, {"error":"경로를 찾을 수 없음"})
        key = os.getenv('OPENAI_API_KEY','')
        if not key:
            return self.send_json(503, {"error":"AI 분석용 서버 키가 설정되지 않았습니다. 기본 모드로 분석할 수 있습니다."})
        try:
            n = int(self.headers.get('Content-Length','0'))
            if n > 4096 or n <= 0: return self.send_json(400, {"error":"잘못된 입력"})
            data=json.loads(self.rfile.read(n))
            name=str(data['name']).strip()[:80]
            ivs=[int(data[k]) for k in ['atk','def','hp']]
            form=str(data.get('form','normal')).strip().lower()
            form_labels={'normal':'일반','shadow':'그림자','purified':'정화','dynamax':'다이맥스','gigantamax':'거다이맥스','mega':'메가진화 활용','primal':'원시회귀 활용'}
            if form not in form_labels: raise ValueError('지원하지 않는 형태 선택')
            if not name or any(v<0 or v>15 for v in ivs): raise ValueError('포켓몬 이름/개체값 확인')
            query = (f"현재 날짜 {datetime.now().astimezone().date().isoformat()}. 포켓몬 {name}. "
                     f"사용자가 직접 선택한 형태는 {form_labels[form]}(코드 {form})이며 추측하지 말 것. "
                     f"현재 개체값 공격 {ivs[0]} 방어 {ivs[1]} 체력 {ivs[2]} (총 {sum(ivs)}/45). "
                     f"선택 형태 구현 가능성, 일반/그림자 대비 차이, 레이드/PvP/GO로켓단/맥스배틀 투자 판정.")
            payload={
                'model':os.getenv('OPENAI_MODEL','gpt-5'),
                'instructions':INSTRUCTION,
                'input':query,
                'tools':[{'type':'web_search','search_context_size':'medium'}],
                'text':{'format':{'type':'json_schema','name':'pokemon_meta_evaluation','strict':True,'schema':SCHEMA}}
            }
            req=urllib.request.Request(OPENAI_URL, data=json.dumps(payload, ensure_ascii=False).encode('utf-8'),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
            with urllib.request.urlopen(req, timeout=130) as r:
                resp=json.loads(r.read())
            output=''.join(part.get('text','') for entry in resp.get('output',[]) if entry.get('type')=='message' for part in entry.get('content',[]) if part.get('type')=='output_text')
            if not output: raise ValueError('모델 결과를 해석할 수 없습니다')
            return self.send_json(200, {'analysis':json.loads(output)})
        except (KeyError, ValueError, TypeError) as e:
            return self.send_json(400, {'error':str(e)})
        except urllib.error.HTTPError as e:
            detail=e.read(1500).decode('utf-8', 'replace')
            return self.send_json(502, {'error':f'AI 서비스 HTTP {e.code}: {detail[:400]}'})
        except Exception as e:
            return self.send_json(502, {'error':f'AI 분석 연결 실패: {str(e)[:250]}'})

if __name__ == '__main__':
    print(f'POKÉMON GO META ESSENTIAL CHECKER: http://{HOST}:{PORT}')
    print('AI live:', '사용' if os.getenv('OPENAI_API_KEY') else '미설정 (PvPoke 데이터 기반 모드)')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
