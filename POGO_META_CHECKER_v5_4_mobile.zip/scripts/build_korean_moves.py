#!/usr/bin/env python3
"""Generate a small, stand-alone Korean move-name lookup for the PWA.

PvPoke/PoGoAPI use English move identifiers, while PokeAPI's move_names.csv
provides localized names (language id 3, Korean). The UI never displays an
unmapped English move identifier as if it were a verified name.
This file is presentation-only: move power, learned moves and battle scores
are never modified.
"""
from __future__ import annotations
import csv
import io
import json
import re
import sys
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'data' / 'move-ko.js'
BASE = 'https://raw.githubusercontent.com/PokeAPI/pokeapi/master/data/v2/csv/'
# Explicit GO-facing names and well-known special moves. These take precedence
# over the main-series Korean lookup whenever their translation differs.
OVERRIDES = {
    'THUNDER_SHOCK':'전기쇼크','WILD_CHARGE':'와일드볼트','BULLDOZE':'땅고르기',
    'FAIRY_WIND':'요정의바람','GIGATON_HAMMER':'거대해머','BODY_SLAM':'누르기',
    'POWER_UP_PUNCH':'그로우펀치','SNARL':'바크아웃','DARK_PULSE':'악의파동',
    'BRUTAL_SWING':'세차게휘두르기','FLAME_SPIN':'회오리불꽃',
    'FIRE_SPIN':'회오리불꽃','BLAST_BURN':'블라스트번',
    'PSYSHOCK':'사이코쇼크','SWIFT':'스피드스타','TRAILBLAZE':'개척하기',
    'MUD_SLAP':'진흙뿌리기','EARTHQUAKE':'지진','CHARM':'애교부리기',
    'SHADOW_CLAW':'섀도클로','COUNTER':'카운터','DRAGON_BREATH':'용의숨결',
    'SHADOW_BALL':'섀도볼','SURF':'파도타기','HYDRO_CANNON':'하이드로캐논',
    'ICICLE_SPEAR':'고드름침','PRECIPICE_BLADES':'단애의칼',
    'ORIGIN_PULSE':'근원의파동','SPACIAL_REND':'공간절단',
    'PSYSTRIKE':'사이코브레이크','METAL_CLAW':'메탈클로',
    'CLOSE_COMBAT':'인파이트','AQUA_TAIL':'아쿠아테일','ICE_BEAM':'냉동빔',
    'ROCK_SLIDE':'스톤샤워','FEINT_ATTACK':'속여때리기',
    'THUNDERBOLT':'10만볼트','THUNDER':'번개','SPARK':'스파크',
    'VOLT_SWITCH':'볼트체인지','THUNDER_PUNCH':'번개펀치',
    'ICE_PUNCH':'냉동펀치','FIRE_PUNCH':'불꽃펀치',
    'DRAGON_CLAW':'드래곤클로','DRAGON_PULSE':'용의파동',
    'OUTRAGE':'역린','DRACO_METEOR':'용성군','DRAGON_TAIL':'드래곤테일',
    'BITE':'물기','CRUNCH':'깨물어부수기','TACKLE':'몸통박치기',
    'QUICK_ATTACK':'전광석화','SCRATCH':'할퀴기',
    'WATER_GUN':'물대포','WATERFALL':'폭포오르기','HYDRO_PUMP':'하이드로펌프',
    'BUBBLE':'거품','BUBBLE_BEAM':'거품광선',
    'VINE_WHIP':'덩굴채찍','RAZOR_LEAF':'잎날가르기','LEAF_BLADE':'리프블레이드',
    'FRENZY_PLANT':'하드플랜트','ENERGY_BALL':'에너지볼',
    'SOLAR_BEAM':'솔라빔','PETAL_BLIZZARD':'꽃보라',
    'CONFUSION':'염동력','PSYCHIC':'사이코키네시스',
    'ZEN_HEADBUTT':'사념의박치기','PSYCHO_CUT':'사이코커터',
    'MOONBLAST':'문포스','DAZZLING_GLEAM':'매지컬샤인',
    'PLAY_ROUGH':'치근거리기','DRAINING_KISS':'드레인키스',
    'MACH_PUNCH':'마하펀치','LOW_KICK':'안다리걸기',
    'FOCUS_BLAST':'기합구슬','DYNAMIC_PUNCH':'폭발펀치',
    'CROSS_CHOP':'크로스촙','SUPERPOWER':'엄청난힘',
    'MUD_SHOT':'머드샷','EARTH_POWER':'대지의힘',
    'POISON_JAB':'독찌르기','SLUDGE_BOMB':'오물폭탄','ACID':'용해액',
    'POISON_FANG':'독엄니','SLUDGE_WAVE':'오물웨이브',
    'POWDER_SNOW':'눈싸라기','AVALANCHE':'눈사태',
    'BLIZZARD':'눈보라','ICY_WIND':'얼어붙은바람',
    'FROST_BREATH':'얼음숨결',
    'LICK':'핥기','HEX':'병상첨병','ASTONISH':'놀래키기',
    'OMINOUS_WIND':'괴상한바람','NIGHT_SHADE':'나이트헤드',
    'ROCK_THROW':'돌떨구기','SMACK_DOWN':'떨어뜨리기',
    'STONE_EDGE':'스톤에지','ROCK_TOMB':'암석봉인',
    'AIR_SLASH':'에어슬래시','WING_ATTACK':'날개치기',
    'AIR_CUTTER':'에어커터','AERIAL_ACE':'제비반환',
    'SKY_ATTACK':'불새','HURRICANE':'폭풍',
    'X_SCISSOR':'시저크로스','BUG_BITE':'벌레먹기',
    'BUG_BUZZ':'벌레의야단법석','INFESTATION':'엉겨붙기',
    'IRON_HEAD':'아이언헤드','FLASH_CANNON':'러스터캐논',
    'BULLET_PUNCH':'불릿펀치','METEOR_MASH':'코멧펀치',
    'GYRO_BALL':'자이로볼','IRON_TAIL':'아이언테일',
    'FURY_CUTTER':'연속자르기','SACRED_SWORD':'성스러운칼',
    'RETURN':'은혜갚기','FRUSTRATION':'화풀이',
    'HIDDEN_POWER':'잠재파워','STRUGGLE':'발버둥',
    'LOCK_ON':'록온','YAWN':'하품',
    'WEATHER_BALL':'웨더볼','TECHNO_BLAST':'테크노버스터',
    'SCORCHING_SANDS':'열사의대지','BREAKING_SWIPE':'와이드브레이커',
    'TRIPLE_AXEL':'트리플악셀','HIGH_HORSEPOWER':'10만마력',
    'RAPID_SPIN':'고속스핀','DREAM_EATER':'꿈먹기',
    'DYNAMAX_CANNON':'다이맥스포', 'BEHEMOTH_BLADE':'거수참',
    'BEHEMOTH_BASH':'거수탄',
}


def normalize_key(name: str) -> str:
    x = re.sub(r'[^A-Z0-9]+', '_', str(name).strip().upper()).strip('_')
    if x.endswith('_FAST'):
        x=x[:-5]
    return x


def parse_csv(raw: bytes):
    return list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))


def mapping_from_csv(moves_raw: bytes, names_raw: bytes, selected: set[str] | None = None) -> dict[str,str]:
    ids={r['id']:normalize_key(r['identifier']) for r in parse_csv(moves_raw) if r.get('id') and r.get('identifier')}
    out={}
    for r in parse_csv(names_raw):
        if r.get('local_language_id') != '3':
            continue
        key=ids.get(r.get('move_id'))
        name=str(r.get('name','')).strip()
        if key and name and re.search(r'[가-힣]',name) and (selected is None or key in selected):
            out[key]=name
    out.update(OVERRIDES)  # GO labels with established names take precedence
    return out


def fetch_bytes(url):
    req=urllib.request.Request(url,headers={'User-Agent':'POGO-Meta-Checker/5.4 Korean localization','Accept':'text/csv,*/*'})
    with urllib.request.urlopen(req,timeout=28) as r:
        raw=r.read(450_000)
    if len(raw)<500: raise ValueError(f'Incomplete localization data ({len(raw)})')
    return raw


def current_move_keys():
    """Only include names needed by current locally validated GO snapshot."""
    p=ROOT/'data'/'catalog.json'
    if not p.exists():return set()
    try:
        data=json.loads(p.read_text(encoding='utf-8'))
        keys=set(map(normalize_key,(data.get('pvp_moves') or {}).keys()))
        for mons in (data.get('pokemon') or []):
            for field in ('quick','charge','elite'):
                keys.update(map(normalize_key,mons.get(field) or []))
        for pool in ((data.get('raid') or {}).get('fast') or {},(data.get('raid') or {}).get('charged') or {}):
            keys.update(map(normalize_key,pool.keys()))
        return keys
    except (OSError,ValueError,TypeError):return set()


def write_js(names:dict[str,str], path=DEST):
    # Data-only JavaScript can be cached by the service worker and works offline.
    names={k:v for k,v in names.items() if k and v and re.search(r'[가-힣]',v)}
    path.parent.mkdir(parents=True,exist_ok=True)
    js='/* Korean move labels: PokeAPI Korean game names + curated GO exceptions. */\nwindow.POGO_KO_MOVES = Object.freeze('+json.dumps(dict(sorted(names.items())),ensure_ascii=False,separators=(',',':'))+');\n'
    path.write_text(js,encoding='utf-8')
    return len(names)


def main(argv):
    offline='--offline' in argv
    out=dict(OVERRIDES)
    if not offline:
        try:
            mr=fetch_bytes(BASE+'moves.csv')
            nr=fetch_bytes(BASE+'move_names.csv')
            selected=current_move_keys()
            out=mapping_from_csv(mr,nr,selected or None)
            extended=sum(1 for k in out if k not in OVERRIDES)
            if extended<25:raise ValueError(f'Insufficient new PokeAPI Korean move labels: {extended}')
            print(f'KO move labels fetched: {len(out)} (snapshot keys: {len(selected)}).')
        except Exception as e:
            print(f'KO move translation fetch unavailable: {type(e).__name__}: {e}',file=sys.stderr)
            # Preserve earlier verified localization on temporary source outage.
            if DEST.exists() and DEST.stat().st_size>4000:
                print('KEEP previous Korean move bundle; no downgrade.')
                return 0
            print('Using bundled GO-specific Korean labels only. Unknown moves show verification-needed Korean text.')
    count=write_js(out)
    print(f'Korean moves ready: {count} -> {DEST}')
    return 0

if __name__=='__main__':sys.exit(main(sys.argv[1:]))
