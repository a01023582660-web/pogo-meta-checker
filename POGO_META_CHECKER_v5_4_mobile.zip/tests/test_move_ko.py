import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from build_korean_moves import mapping_from_csv,normalize_key,OVERRIDES

class KoreanMoveTests(unittest.TestCase):
    def test_go_aliases(self):
        self.assertEqual(normalize_key('Mud Slap'),'MUD_SLAP')
        self.assertEqual(normalize_key('MUD_SLAP_FAST'),'MUD_SLAP')
        self.assertEqual(normalize_key('Shadow Ball'),'SHADOW_BALL')

    def test_pokeapi_language_id_three(self):
        ids=b'id,identifier\n1,pound\n2,solar-beam\n3,odd-move\n'
        names='move_id,local_language_id,name\n1,9,Pound\n1,3,막치기\n2,3,솔라빔\n3,3,기술명\n'.encode('utf-8')
        got=mapping_from_csv(ids,names,{'POUND','SOLAR_BEAM'})
        self.assertEqual(got['POUND'],'막치기')
        self.assertEqual(got['SOLAR_BEAM'],'솔라빔')
        self.assertEqual(got['MUD_SLAP'],'진흙뿌리기')
        self.assertNotIn('ODD_MOVE',got)

    def test_go_verified_precedence(self):
        ids=b'id,identifier\n1,body-slam\n'
        names='move_id,local_language_id,name\n1,3,가짜번역\n'.encode('utf-8')
        got=mapping_from_csv(ids,names)
        self.assertEqual(got['BODY_SLAM'],OVERRIDES['BODY_SLAM'])

if __name__=='__main__':unittest.main()
