const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');
const els=new Map();
function element(id){
  if(!els.has(id))els.set(id,{value:'',checked:false,innerHTML:'',textContent:'',hidden:false,disabled:false,
    addEventListener(type,fn){this[type]=fn},scrollIntoView(){},requestSubmit(){element('form').submit({preventDefault(){}})}});
  return els.get(id);
}
const radios=['normal','shadow','purified','dynamax','gigantamax','mega','primal'].map(value=>({value,checked:value==='normal',addEventListener(){}}));
const doc={getElementById:element,querySelector(q){return q==='input[name="form"]:checked'?radios.find(x=>x.checked):null},querySelectorAll(q){return q==='input[name="form"]'?radios:[]}};
const ctx={window:{__POGO_TEST_MODE__:true,addEventListener(){}},document:doc,navigator:{},console,
  Date,Math,Number,String,Object,Array,Set,Map,JSON,Promise,setTimeout,clearTimeout,
  location:{protocol:'file:',hostname:'',pathname:'/index.html'},
  alert(t){throw Error('Unexpected alert '+t)},fetch:async()=>{throw Error('offline')},localStorage:{getItem(){return null},setItem(){}}};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root,'data/starter.js'),'utf8'),ctx);
ctx.window.POGO_STARTER.species['241']={dex:241,ko:'밀탱크',chain:241,legendary:false,mythical:false};
ctx.window.POGO_STARTER.pokemon.push({id:'miltank',dex:241,en:'Miltank',base:{atk:157,def:193,hp:216},types:['normal'],tags:[],quick:['TACKLE'],charge:['BODY_SLAM'],elite:[],evos:[],released:true});
vm.runInContext(fs.readFileSync(path.join(root,'data/move-ko.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),ctx);
const t=ctx.window.__POGO_V5_TESTS;
assert(t,'Test API');
assert.strictEqual(t.moveLabel('BODY_SLAM'),'누르기');
assert.strictEqual(t.moveLabel('Behemoth Blade'),'거수참');
assert.strictEqual(t.moveLabel('MUD_SLAP_FAST'),'진흙뿌리기');
assert.strictEqual(t.moveLabel('fire spin'),'회오리불꽃');
assert.strictEqual(t.moveLabel('INVENTED_MOVE_999'),'한국어 기술명 확인 필요');
assert.strictEqual(t.moveLabel(''),'기술명 확인 필요');
assert.strictEqual(t.koreanToKeys('밀탱크'),'alfxodzm');
assert.strictEqual(t.koreanToKeys('이브이'),'dlqmdl');
assert.strictEqual(t.resolveSearchName('alfxodzm'),'밀탱크');
assert.strictEqual(t.resolveSearchName('dlqmdl'),'이브이');
assert.strictEqual(t.resolveSearchName('Miltank'),'Miltank','real English names still accepted');
assert.strictEqual(t.resolveSearchName('al'), 'al','incomplete qwerty never guessed');
assert.strictEqual(t.findPokemon('alfxodzm').dex,241,'QWERTY keyboard resolves Korean species');
assert.strictEqual(t.findPokemon('밀탱크').dex,241);
assert.strictEqual(t.findPokemon('Miltank').dex,241);
const hint=element('koKeyboardHint');
element('pkname').value='alfxo';
element('pkname').input();
assert(hint.textContent.includes('밀탱크'), 'Korean suggestion shown for Latin keyboard prefix');
const input=element('pkname');input.value='alfxodzm';
['atk','def','hp'].forEach((k,i)=>element(k).value=String([12,14,14][i]));
element('form').submit({preventDefault(){}});
assert.strictEqual(input.value,'밀탱크','QWERTY search input normalized before report');
assert(element('result').innerHTML.includes('밀탱크'));
assert(!element('result').innerHTML.includes('Body Slam'),'Move names must not leak English into report');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
assert(html.includes('lang="ko" inputmode="text"'),'Korean input hint present');
assert(html.includes('data/move-ko.js'),'Korean move dictionary included before app');
console.log('PASS Korean GO move display, unknown-name safety, Hangul keyboard-layout search, English aliases, on-screen hint');
