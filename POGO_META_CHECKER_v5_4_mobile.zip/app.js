/* POGO META v5.4 — Korean move names and no-toggle Korean keyboard fallback. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KINDS={normal:'일반',shadow:'그림자',purified:'정화',dynamax:'다이맥스',gigantamax:'거다이맥스',mega:'메가 활용',primal:'원시 활용'};
const HINTS={normal:'일반 상태를 기준으로 분석해. 그림자·다이맥스 여부는 자동으로 추정하지 않아.',shadow:'선택한 개체가 실제 그림자 포켓몬일 때만 사용해. 일반 종족의 순위로 대체하지 않아.',purified:'정화가 완료된 현재 개체값을 입력해. +2를 다시 적용하지 않아.',dynamax:'실제로 맥스배틀에서 얻은 다이맥스 개체만 선택해.',gigantamax:'거다이맥스 가능 개체를 별도로 확보한 경우에만 선택해.',mega:'메가진화는 일반·정화 개체의 일시적 변신이야. 그림자 포켓몬은 메가진화할 수 없어.',primal:'원시회귀 가능 종족만 선택해. 그림자 상태에서는 원시회귀할 수 없어.'};
const TYPES={normal:'노말',fire:'불꽃',water:'물',electric:'전기',grass:'풀',ice:'얼음',fighting:'격투',poison:'독',ground:'땅',flying:'비행',psychic:'에스퍼',bug:'벌레',rock:'바위',ghost:'고스트',dragon:'드래곤',dark:'악',steel:'강철',fairy:'페어리'};
const LABELS={THUNDER_SHOCK:'전기쇼크',WILD_CHARGE:'와일드볼트',BULLDOZE:'땅고르기',FAIRY_WIND:'요정의바람',GIGATON_HAMMER:'거대해머',BODY_SLAM:'누르기',POWER_UP_PUNCH:'그로우펀치',SNARL:'바크아웃',DARK_PULSE:'악의파동',BRUTAL_SWING:'세차게휘두르기',FLAME_SPIN:'회오리불꽃',FIRE_SPIN:'회오리불꽃',BLAST_BURN:'블라스트번',PSYSHOCK:'사이코쇼크',SWIFT:'스피드스타',TRAILBLAZE:'개척하기',MUD_SLAP:'진흙뿌리기',EARTHQUAKE:'지진',CHARM:'애교부리기',SHADOW_CLAW:'섀도클로',COUNTER:'카운터',DRAGON_BREATH:'용의숨결',SHADOW_BALL:'섀도볼',SURF:'파도타기',HYDRO_CANNON:'하이드로캐논',ICICLE_SPEAR:'고드름침',PRECIPICE_BLADES:'단애의칼',ORIGIN_PULSE:'근원의파동',SPACIAL_REND:'공간절단',PSYSTRIKE:'사이코브레이크',METAL_CLAW:'메탈클로',CLOSE_COMBAT:'인파이트',AQUA_TAIL:'아쿠아테일',ICE_BEAM:'냉동빔',ROCK_SLIDE:'스톤샤워',FEINT_ATTACK:'속여때리기'};
// CP multipliers, levels 1.0–50.0 in half-level increments; no buddy level 51 assumed.
const CPM = [0.0939999967813491,0.135137430784308,0.166397869586944,0.192650914456886,0.215732470154762,0.236572655026622,0.255720049142837,0.273530381100769,0.290249884128570,0.306057381335773,0.321087598800659,0.335445032295077,0.349212676286697,0.362457748778790,0.375235587358474,0.387592411085168,0.399567276239395,0.411193549517250,0.422500014305114,0.432926413410414,0.443107545375824,0.453059953871985,0.462798386812210,0.472336077786704,0.481684952974319,0.490855810259008,0.499858438968658,0.508701756943992,0.517393946647644,0.525942508771329,0.534354329109191,0.542635762230353,0.550792694091796,0.558830599438087,0.566754519939422,0.574569148039264,0.582278907299041,0.589887911977272,0.597400009632110,0.604823657502073,0.612157285213470,0.619404110566050,0.626567125320434,0.633649181622743,0.640652954578399,0.647580963301656,0.654435634613037,0.661219263506722,0.667934000492096,0.674581899290818,0.681164920330047,0.687684905887771,0.694143652915954,0.700542893277978,0.706884205341339,0.713169102333341,0.719399094581604,0.725575616972598,0.731700003147125,0.734741011137376,0.737769484519958,0.740785574597326,0.743789434432983,0.746781208702482,0.749761044979095,0.752729105305821,0.755685508251190,0.758630366519684,0.761563837528228,0.764486065255226,0.767397165298461,0.770297273971590,0.773186504840850,0.776064945942412,0.778932750225067,0.781790064808426,0.784636974334716,0.787473583646825,0.790300011634826,0.792803950958807,0.795300006866455,0.797803921486970,0.800300002098083,0.802803892322847,0.805299997329711,0.807803863460723,0.810299992561340,0.812803834895026,0.815299987792968,0.817803806620319,0.820299983024597,0.822803778631297,0.825299978256225,0.827803750922782,0.830299973487854,0.832803753381377,0.835300028324127,0.837803755931569,0.840300023555755];
const S = {db:window.POGO_STARTER||null, full:false, byId:new Map(), byDex:new Map(), byName:new Map(), voiceText:'', aiAvailable:false, installedPrompt:null, busy:false, metaIndex:null,metaChanges:null,metaVersion:null};
function validCatalog(v){return !!(v&&v.schema===3&&Array.isArray(v.pokemon)&&v.pokemon.length>=30&&v.species&&v.ranks&&v.ranks['1500']&&v.ranks['2500']&&v.ranks['10000']);}
function indexCatalog(){
  S.byId=new Map();S.byDex=new Map();S.byName=new Map();
  for(const p of (S.db?.pokemon||[])){
    S.byId.set(p.id,p);
    if(!S.byDex.has(p.dex))S.byDex.set(p.dex,[]);
    S.byDex.get(p.dex).push(p);
    const spec=S.db.species[String(p.dex)]||{};
    const names=[p.id,p.en,spec.ko,String(p.dex),'#'+p.dex];
    // Derived aliases for selected named battle forms. Never collapse a
    // decorated form into an ordinary form during rating lookup.
    const formNames={origin:'오리진',altered:'어나더',attack:'어택',defense:'디펜스',speed:'스피드',
      galarian:'가라르',alolan:'알로라',hisuian:'히스이',paldean:'팔데아',
      therian:'영물',incarnate:'화신',crowned_sword:'검왕',crowned_shield:'방패왕',
      hero:'역전의용사',sky:'스카이',land:'랜드',sunshine:'선샤인',midnight:'한밤중',
      dusk:'황혼',dawn_wings:'새벽의날개',dusk_mane:'황혼의갈기'};
    const cleaned=p.id.replace(/_shadow$/,'').replace(/_mega(?:_[xy])?$/,'').replace(/_primal$/,'');
    const rootId=formToken(spec.identifier||'');
    const suffix=rootId&&formToken(cleaned).startsWith(rootId)?
      formToken(cleaned).slice(rootId.length):cleaned.split('_').slice(1).join('_');
    if(spec.ko&&suffix){
      names.push(spec.ko+suffix);
      if(formNames[suffix])names.push(spec.ko+' '+formNames[suffix]);
    }
    for(let str of names){if(!str)continue;str=norm(str);if(!S.byName.has(str))S.byName.set(str,[]);S.byName.get(str).push(p)}
  }
  S.koreanNames=[...S.byName.keys()].filter(x=>/[가-힣]/.test(x)&&/^[가-힣]+$/.test(x));
}
function norm(v){return String(v||'').trim().toLowerCase().replace(/[\s_()·\-]/g,'');}
// A PWA cannot switch the OS's Korean/English IME. Instead, an English-layout
// two-set Korean key sequence can resolve to its Korean Pokémon name.
const DUBEOL={
  first:['r','R','s','e','E','f','a','q','Q','t','T','d','w','W','c','z','x','v','g'],
  middle:['k','o','i','O','j','p','u','P','h','hk','ho','hl','y','n','nj','np','nl','b','m','ml','l'],
  last:['','r','R','rt','s','sw','sg','e','f','fr','fa','fq','ft','fx','fv','fg','a','q','qt','t','T','d','w','c','z','x','v','g']
};
function koreanToKeys(text){
  let out='';
  for(const char of String(text||'')){
    const cp=char.charCodeAt(0);
    if(cp>=0xAC00&&cp<=0xD7A3){
      const n=cp-0xAC00;
      out+=DUBEOL.first[Math.floor(n/588)]+DUBEOL.middle[Math.floor((n%588)/28)]+DUBEOL.last[n%28];
    }else if(char===' '||char==='·'||char==='-'||char==='_')out+=' ';
    else out+=char;
  }
  return out.trim();
}
function koreanKeyCandidates(raw,limit=5){
  const q=String(raw||'').trim();
  // Avoid hijacking valid English names, IDs and abbreviations.
  if(!q||!/^[a-zA-Z ]{2,}$/.test(q)||S.byName.has(norm(q)))return [];
  const normalized=q.replace(/\s+/g,'').toLowerCase();
  const matches=[];let seen=new Set();
  for(const ko of S.koreanNames||[]){
    const keys=koreanToKeys(ko).replace(/\s+/g,'').toLowerCase();
    if(!keys.startsWith(normalized)||seen.has(norm(ko)))continue;
    seen.add(norm(ko));matches.push({ko,exact:keys===normalized});
  }
  // Exact matches first. Prefer shorter familiar species names on prefixes.
  return matches.sort((a,b)=>Number(b.exact)-Number(a.exact)||a.ko.length-b.ko.length||a.ko.localeCompare(b.ko,'ko')).slice(0,limit);
}
function resolveSearchName(raw){
  // Exact Korean keyboard mapping only. Incomplete qwerty input is never guessed.
  const candidate=koreanKeyCandidates(raw,6).find(x=>x.exact);
  return candidate?.ko||raw;
}
function showKoreanKeyboardHint(){
  const input=$('pkname'),hint=$('koKeyboardHint');if(!input||!hint)return;
  const raw=input.value.trim();
  if(!raw){hint.textContent='한글 입력 권장 · 영어 자판 상태라면 한글 키 위치대로 입력해도 찾아줘.';hint.hidden=false;return;}
  const choices=koreanKeyCandidates(raw,3);
  if(choices.length){
    const exact=choices.find(x=>x.exact);
    hint.textContent=exact?`영어 자판 입력 인식 → ${exact.ko} (분석 버튼을 누르면 한글로 검색해요)`:
      `한글 검색 후보: ${choices.map(x=>x.ko).join(' · ')}`;
    hint.hidden=false;
  }else{hint.hidden=!/^[a-zA-Z ]+$/.test(raw);hint.textContent=hint.hidden?'':'한글 포켓몬 이름이나 영어 이름을 입력할 수 있어요.';}
}

function speciesName(dex){let d=S.db.species[String(dex)];return d?.ko||S.byDex.get(dex)?.[0]?.en||`#${dex}`}
function findPokemon(raw){
  raw=resolveSearchName(raw);
  const v=norm(raw);
  // Keep named in-game forms separate. Plain "자시안" and "자마젠타"
  // default to Hero; Crowned forms require an explicit user choice.
  const special=[
    {dex:888,crowned:/^(자시안검왕|자시안왕관|자시안크라운드|zaciancrowned(?:sword)?)$/,hero:/^(자시안|자시안역전의용사|zacian(?:hero)?)$/},
    {dex:889,crowned:/^(자마젠타방패왕|자마젠타왕관|자마젠타크라운드|zamazentacrowned(?:shield)?)$/,hero:/^(자마젠타|자마젠타역전의용사|zamazenta(?:hero)?)$/}
  ];
  for(const spec of special){
    if(spec.crowned.test(v)||spec.hero.test(v)){
      const crowned=spec.crowned.test(v);
      const all=(S.byDex.get(spec.dex)||[]).filter(x=>!x.id.includes('_shadow')&&!x.id.includes('_mega'));
      const match=all.find(x=>crowned?x.id.includes('crowned'):!x.id.includes('crowned'));
      if(match)return match;
    }
  }
  let found=S.byName.get(v)||[];
  if(!found.length){const parsed=String(raw).replace(/^그림자\s*|^정화\s*|^메가\s*/,'');found=S.byName.get(norm(parsed))||[];}
  return found.find(x=>!x.catalog_only&&!x.id.includes('_shadow')&&!x.id.includes('_mega')&&!x.id.includes('_primal')&&!x.id.includes('_crowned'))||found[0]||null;
}
function getLine(current){
  if(!current)return [];
  const origin=S.db.species[String(current.dex)];
  if(!origin?.chain)return [{depth:0,pokemons:[current.dex]}];
  const family=Object.values(S.db.species).filter(p=>p.chain===origin.chain&&S.byDex.has(p.dex)&&S.byDex.get(p.dex).some(x=>x.released!==false));
  const children=new Map();for(const p of family){let id=Number(p.parent||0);if(!children.has(id))children.set(id,[]);children.get(id).push(p.dex)}
  let roots=family.filter(p=>!p.parent||!family.some(x=>x.dex===p.parent)).map(p=>p.dex);
  if(!roots.length)roots=[current.dex];
  const stages=[],seen=new Set();let group=roots,depth=0;
  while(group.length&&depth<14){group=group.filter(d=>!seen.has(d));if(!group.length)break;stages.push({depth,pokemons:group});group.forEach(d=>seen.add(d));group=group.flatMap(d=>children.get(d)||[]);depth++}
  return stages;
}
function img(dex,ko,clazz=''){
  const url=`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${Number(dex)}.png`;
  return `<img class="${clazz}" src="${url}" loading="lazy" alt="${esc(ko)} 포켓몬 이미지" onerror="this.onerror=null;this.style.opacity='.12';this.alt='이미지 연결 실패';">`;
}
function evoView(stages,currentDex,form){
  if(!stages.length)return `<p class="smallnote">진화 정보 없음 · 최신 검증 필요</p>`;
  let out='<div class="evo-grid">';
  for(let i=0;i<stages.length;i++){
    const s=stages[i];if(i>0)out+='<div class="evo-arr" aria-label="진화">→</div>';
    out+='<div class="evo-stage"><div class="'+(s.pokemons.length>1?'evo-branched':'evo-cluster')+'">';
    for(const dex of s.pokemons){const name=speciesName(dex);out+=`<div class="evo-card ${dex===currentDex?'current':''}">${img(dex,name)}<strong>${esc(name)}</strong><small>도감 #${dex}${dex===currentDex?' · 선택':''}</small>${form==='shadow'?'<small>🌑 그림자 계열 참고</small>':''}</div>`;}
    out+='</div></div>';
  }
  return out+'</div><p class="smallnote">이미지: PokeAPI 스프라이트(온라인). 진화 순서: 포켓몬 도감 진화 계열 기준. Pokémon GO의 사탕·아이템·시간·미구현 여부 등 구체적인 진화 조건은 별도로 확인해야 해. 분기 진화도 표시해. 그림자 선택 시 이미지는 일반형 자료를 사용할 수 있어.</p>';
}
function scoreClass(v){return v===3?'':v===2?'mid':v===1?'low':v===0?'low':String(v).includes('불가')?'off':'unknown'}
function grade(v){const text=Number.isInteger(v)?['☆☆☆','★☆☆','★★☆','★★★'][v]:v||'검증 필요';return `<span class="score ${scoreClass(v)}">${esc(text)}</span>`}
function rating(label,val,detail){return `<div class="rating"><div><b>${esc(label)}</b>${detail?`<small>${esc(detail)}</small>`:''}</div>${grade(val)}</div>`}
function panel(n,title,content,cls=''){return `<section class="panel ${cls}"><h3 class="sec-title"><b>${n}</b> ${esc(title)}</h3>${content}</section>`}
function percent(v){return Math.round(v.reduce((a,b)=>a+b,0)/45*100)}
function classification(p){const x=S.db.species[String(p.dex)]||{};const t=p.tags||[];if(t.includes('ultrabeast'))return '울트라비스트';if(x.mythical||t.includes('mythical'))return '환상의 포켓몬';if(x.legendary||t.includes('legendary'))return '전설의 포켓몬';return '일반 포켓몬'}
function mainForm(p,kind){
  if(kind==='shadow')return S.byId.get(p.id.endsWith('_shadow')?p.id:p.id+'_shadow')||null;
  if(kind==='mega'||kind==='primal'){
    let variants=(S.byDex.get(p.dex)||[]).filter(x=>x.id.includes(kind==='mega'?'_mega':'_primal'));
    // Mega/Primal on a final evolution often belongs to a different Dex than the input.
    return variants[0]||null;
  }
  return p;
}
function familyMembers(stages,kind){const fam=stages.flatMap(s=>s.pokemons.flatMap(d=>S.byDex.get(d)||[]));
  return fam.filter(p=>p.released!==false&&p.catalog_only!==true&& !p.id.includes('_mega')&&!p.id.includes('_primal')&&!p.id.includes('_gigantamax')&&(kind==='shadow'?p.id.includes('_shadow'):!p.id.includes('_shadow')));
}
function findTransformation(stages,kind){const test=kind==='mega'?'_mega':'_primal';return stages.flatMap(s=>s.pokemons.flatMap(d=>S.byDex.get(d)||[])).filter(p=>p.id.includes(test));}
function leaguePokemon(fam,cap){const map=S.db.ranks[String(cap)]||{};return fam.map(p=>({p,r:map[p.id]})).filter(x=>x.r&&Number.isInteger(x.r.rank)).sort((a,b)=>a.r.rank-b.r.rank)[0]||null;}
function cp(base,iv,k){return Math.max(10,Math.floor((base.atk+iv[0])*Math.sqrt(base.def+iv[1])*Math.sqrt(base.hp+iv[2])*k*k/10));}
function sp(base,iv,cap){let left=0,right=CPM.length-1,found=-1;while(left<=right){const mid=(left+right)>>1;if(cp(base,iv,CPM[mid])<=cap){found=mid;left=mid+1}else right=mid-1;}if(found<0)return 0;const k=CPM[found];return (base.atk+iv[0])*k*(base.def+iv[1])*k*Math.floor((base.hp+iv[2])*k)}
function ivPlace(p,ivs,cap){if(!p.base)return null;const yours=sp(p.base,ivs,cap);if(!yours)return null;let better=0;for(let a=0;a<=15;a++)for(let d=0;d<=15;d++)for(let h=0;h<=15;h++){if(sp(p.base,[a,d,h],cap)>yours+1e-9)better++}return 1+better;}
function rankGrade(rank){if(rank<=60)return 3;if(rank<=200)return 2;if(rank<=450)return 1;return 0}
// v5.1: rank actual attack/defense/HP IVs within the selected species/form.
// 4096 hypothetical spreads. Catch/trade IV floors and level 51 buddy boosts excluded.
const pvpIvCache=new Map();
function leagueFit(base, ivs, cap){
  if(!base||![base.atk,base.def,base.hp].every(x=>Number.isFinite(x)&&x>0))return null;
  let low=0,high=CPM.length-1,found=-1;
  while(low<=high){const mid=(low+high)>>1;
    if(cp(base,ivs,CPM[mid])<=cap){found=mid;low=mid+1}else high=mid-1;
  }
  if(found<0)return null;
  const k=CPM[found];
  return {level:1+found*.5,cp:cp(base,ivs,k),stat:(base.atk+ivs[0])*k*(base.def+ivs[1])*k*Math.max(10,Math.floor((base.hp+ivs[2])*k))};
}
function leagueIvCompare(p,ivs,cap){
  if(!p?.base)return null;
  const key=`${p.id}/${cap}/${p.base.atk}/${p.base.def}/${p.base.hp}`;
  let table=pvpIvCache.get(key);
  if(!table){
    const spreads=[];
    for(let a=0;a<=15;a++)for(let d=0;d<=15;d++)for(let h=0;h<=15;h++){
      const fit=leagueFit(p.base,[a,d,h],cap);
      if(fit)spreads.push({a,d,h,...fit});
    }
    if(!spreads.length)return null;
    spreads.sort((x,y)=>y.stat-x.stat||y.cp-x.cp||y.a-x.a||y.d-x.d||y.h-x.h);
    const lookup=new Map();let last=Infinity,tieRank=1;
    for(let i=0;i<spreads.length;i++){
      const entry=spreads[i];
      if(entry.stat<last-1e-6){tieRank=i+1;last=entry.stat;}
      entry.rank=tieRank;lookup.set(`${entry.a}/${entry.d}/${entry.h}`,entry);
    }
    table={best:spreads[0],top3:spreads.slice(0,3),lookup,size:spreads.length};
    if(pvpIvCache.size>10)pvpIvCache.clear();
    pvpIvCache.set(key,table);
  }
  const current=table.lookup.get(ivs.join('/'));
  return current?{...current,preferred:table.top3.map(x=>[x.a,x.d,x.h].join('/')),
    bestIV:[table.best.a,table.best.d,table.best.h].join('/'),
    percent:100*current.stat/table.best.stat,count:table.size}:null;
}
function leagueIvStatus(metaGrade,iv,cap){
  if(!iv)return {level:'unknown',text:'개체값 계산 불가'};
  if(metaGrade<1)return {level:'reject',text:'이 리그 기준 박사에게 보내기 후보 · 종족 메타 비주류'};
  if(cap===10000){
    if(iv.a===15 && iv.d>=14 && iv.h>=14){
      return {level:metaGrade>=2?'recommend':'maybe',text:metaGrade>=2?'이 개체 육성 추천':'고개체 보관 후보'};
    }
    if(iv.a===15&&iv.d>=12&&iv.h>=12)return {level:'maybe',text:'조건부 보관 · 15공격, 실전 브레이크포인트 확인'};
    return {level:'reject',text:'이 리그 기준 박사에게 보내기 후보 · 고개체 부족'};
  }
  const strong=metaGrade>=2;
  if(strong&&iv.rank<=150&&iv.percent>=98.5)return {level:'recommend',text:'이 개체 육성 추천 · 선호 IV권'};
  if(strong&&iv.rank<=600&&iv.percent>=97.0)return {level:'maybe',text:'조건부 보관 · 더 좋은 IV 확보 시 교체'};
  if(metaGrade===1&&iv.rank<=150&&iv.percent>=98.5)return {level:'maybe',text:'비주류지만 IV 상위권 · 취향·특수컵용 보관'};
  return {level:'reject',text:'이 리그 기준 박사에게 보내기 후보 · IV 비선호'};
}
function ivStatusMarkup(status,body){
  return `<div class="iv-assess ${esc(status.level)}"><b>${esc(status.text)}</b><small>${esc(body)}</small></div>`;
}

function pvpAnalysis(p,kind,stages,ivs){
  if(p.dex===132)return {html:['슈퍼리그','하이퍼리그','마스터리그'].map(x=>rating(x,'참가 불가','메타몽은 GO배틀리그에 참여할 수 없어.')).join(''),best:null,all:[]};
  if(['mega','primal'].includes(kind))return {html:['슈퍼리그','하이퍼리그','마스터리그'].map(x=>rating(x,'참가 불가','메가·원시 변신 상태로 일반 GO배틀리그는 참가할 수 없어. 특별 규칙 예외.')).join(''),best:null,all:[]};
  let fam=familyMembers(stages,kind),all=[],html='';
  if((p.dex===888||p.dex===889) && !['shadow','mega','primal'].includes(kind))fam=fam.filter(x=>x.id===p.id);
  for(const [label,cap] of [['슈퍼리그',1500],['하이퍼리그',2500],['마스터리그',10000]]){
    const leagueMap=S.db.ranks[String(cap)]||{},match=leaguePokemon(fam,cap);
    if(!S.full||!Object.keys(leagueMap).length){html+=rating(label,'최신 검증 필요','검증된 PvPoke 순위 데이터가 아직 없어.');continue;}
    if(!fam.length){html+=rating(label,'최신 검증 필요','현재 선택한 형태의 게임 데이터가 확인되지 않아.');continue;}
    if(!match){html+=rating(label,0,'공개 종합랭킹에 해당 진화체·형태가 없어. IV가 좋아도 종족의 리그 성능은 검증되지 않았어.');continue;}
    const g=rankGrade(match.r.rank);
    const iv=leagueIvCompare(match.p,ivs,cap);
    const decision=leagueIvStatus(g,iv,cap);
    const familyName=speciesName(match.p.dex)+(match.p.id.includes('_shadow')?' · 그림자':'');
    html+=rating(label,g,`${familyName} 기준 · PvPoke ${match.r.rank}위 (종족 순위) · 현재 IV ${ivs.join('/')}`);
    if(iv){
      const preferred=cap===10000?'15/15/15 (최적) · 15공격 우선':iv.preferred.join(' · ');
      html+=ivStatusMarkup(decision,
        `선호 IV 상위 3개: ${preferred} | 현재 IV ${iv.rank}/${iv.count}위 · 스탯곱 최고 대비 ${iv.percent.toFixed(2)}% · CP ${iv.cp} / Lv.${iv.level}`);
    }else html+=ivStatusMarkup(decision,'종족값 또는 CP 범위 자료 부족 · 폐기 판정 보류');
    all.push({label,cap,grade:g,rank:match.r.rank,p:match.p,
      ivPlace:iv?.rank??null,iv,decision,moves:match.r.moves});
  }
  return {html,best:[...all].sort((a,b)=>b.grade-a.grade||a.rank-b.rank)[0]||null,all};
}
function normalizeMove(s){return String(s||'').trim().toLowerCase();}
function moveKey(move){
  let id=String(move||'').trim().toUpperCase().replace(/[^A-Z0-9]+/g,'_').replace(/^_+|_+$/g,'');
  if(id.endsWith('_FAST'))id=id.slice(0,-5);
  return id;
}
function moveLabel(move){
  const id=moveKey(move);
  if(!id)return '기술명 확인 필요';
  // Localized names are display-only. Never change raw PvE/PvP move IDs used for calculations.
  const ko=LABELS[id]||window.POGO_KO_MOVES?.[id];
  return typeof ko==='string'&&/[가-힣]/.test(ko)?ko:'한국어 기술명 확인 필요';
}

function formToken(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]/g,'');}
function raidLearnsetFor(p){
  const sets=S.db.raid?.learnsets||{};
  const prefix=p.dex+':';
  const forms=Object.entries(sets).filter(([k])=>k.startsWith(prefix));
  if(!forms.length)return null;
  const id=String(p.id||'').toLowerCase();
  // Zacian/Zamazenta have no ordinary "Normal" battle forme.
  // Crowned must NEVER silently borrow Hero's moves, or vice versa.
  let wanted=[];
  if(p.dex===888){wanted=id.includes('crowned')?['crownedsword','crowned']:['hero','heroofmanybattles'];}
  else if(p.dex===889){wanted=id.includes('crowned')?['crownedshield','crowned']:['hero','heroofmanybattles'];}
  else {
    const normalized=id.replace(/_shadow$/,'').replace(/_mega(?:_[xy])?$/,'').replace(/_primal$/,'');
    const origin=formToken(p.species_identifier||'');const all=formToken(normalized);
    if(origin&&all===origin)wanted=['normal'];
    else if(origin&&all.startsWith(origin))wanted=[all.slice(origin.length)];
    else{
      const sid=normalized.split('_');
      wanted=sid.length>1?[formToken(sid.slice(1).join('_'))]:['normal'];
      if(sets[`${p.dex}:normal`]&&!origin)wanted.push('normal');
    }
  }
  for(const w of wanted){const hit=forms.find(([k])=>formToken(k.slice(prefix.length))===w);if(hit)return hit[1];}
  // If the source supplies just one form but no standard-form entry,
  // do not assume it represents a *different* named form.
  if(wanted.includes('normal') && forms.length===1 && !forms[0][0].toLowerCase().includes('crowned'))return forms[0][1];
  return null;
}
function raidPotential(p,kind,ivs){
  const raid=S.db.raid;
  if(!S.full||!raid?.available)return null;
  const learn=raidLearnsetFor(p);
  if(!learn||!p.base)return null;
  let best=null;
  const moves1=[...new Set([...(learn.fast||[]),...(learn.elite_fast||[])])];
  const moves2=[...new Set([...(learn.charge||[]),...(learn.elite_charge||[])])];
  for(const fastName of moves1){const f=raid.fast[normalizeMove(fastName)];if(!f||f.energy<=0||f.ms<=0)continue;
    for(const chName of moves2){const c=raid.charged[normalizeMove(chName)];if(!c||c.energy>=0||c.ms<=0)continue;
      const num=Math.max(1,Math.ceil(Math.abs(c.energy)/f.energy));
      const stab1=(p.types||[]).includes(f.type)?1.2:1;
      const stab2=(p.types||[]).includes(c.type)?1.2:1;
      const dps=((num*f.power*stab1)+(c.power*stab2))/(num*f.ms+c.ms)*1000;
      const atkFactor=((p.base?.atk||0)+ivs[0])*(kind==='shadow'?1.2:1);
      const score=dps*atkFactor/100;
      if(!best||best.score<score)best={score,fast:fastName,charged:chName,skillType:c.type,elite:(learn.elite_fast||[]).includes(fastName)||(learn.elite_charge||[]).includes(chName)};
    }
  }
  return best;
}
let cachedRaidMax=null;
function raidMaxForType(type){if(!S.full||!S.db.raid.available)return 0;if(!cachedRaidMax)cachedRaidMax=new Map();if(cachedRaidMax.has(type))return cachedRaidMax.get(type);
 let top=0;
 for(const p of S.db.pokemon){if(!p.base||p.released===false||p.id.includes('_shadow')||p.id.includes('_mega')||p.id.includes('_primal'))continue;
   if(!(p.types||[]).includes(type))continue;
   const r=raidPotential(p,'normal',[15,15,15]);if(r&&r.skillType===type)top=Math.max(top,r.score);
 }
 cachedRaidMax.set(type,top);return top;
}
function raidIvAssess(p,kind,ivs,metaGrade){
  if(!p?.base?.atk)return {level:'unknown',text:'개체값 화력 비교 불가',percent:null};
  const pct=100*(p.base.atk+ivs[0])/(p.base.atk+15);
  if(metaGrade<2)return {level:'reject',text:'이 타입 레이드 기준 우선 육성 비추천 · 메타 경쟁력 낮음',percent:pct};
  // The relative damage proxy depends on Attack IV only; Defense/HP thresholds
  // are a practical resource investment policy, NOT a simulated boss-specific DPS/TDO.
  if(ivs[0]>=13&&ivs[1]>=10&&ivs[2]>=10&&pct>=98.7)
    return {level:'recommend',text:'이 개체 레이드 육성 추천',percent:pct};
  if(ivs[0]>=10&&ivs[1]>=8&&ivs[2]>=8&&pct>=97)
    return {level:'maybe',text:'조건부 보관 · 대체 전력용',percent:pct};
  return {level:'reject',text:'이 레이드 기준 박사에게 보내기 후보 · IV 효율 부족',percent:pct};
}
function raidSection(p,kind,stages,ivs){
  const family=stages.flatMap(s=>s.pokemons.flatMap(d=>S.byDex.get(d)||[]));
  let candidates=[];
  if(kind==='mega'||kind==='primal'){
    candidates=findTransformation(stages,kind).filter(x=>x.released!==false);
    if(!candidates.length)return {html:rating('레이드','최신 검증 필요','선택한 진화 계열에서 메가·원시 형태를 확인하지 못함. 해당 형태를 실제로 사용할 수 있는지 먼저 확인해.'),grade:null};
  }else if(kind==='shadow'){
    candidates=family.filter(x=>x.released!==false&&x.id.endsWith('_shadow'));
    if(!candidates.length)return {html:rating('레이드','최신 검증 필요','해당 계열에서 확인된 그림자 형태가 없어. 일반형 성능을 그대로 적용하지 않아.'),grade:null};
  }else{
    candidates=family.filter(x=>x.released!==false&&!x.id.includes('_shadow')&&!x.id.includes('_mega')&&!x.id.includes('_primal')&&!x.id.includes('_gigantamax'));
  }
  // Distinct named forms of a single species cannot be pooled together.
  if((p.dex===888||p.dex===889) && !['mega','primal','shadow'].includes(kind)){
    candidates=candidates.filter(x=>x.id===p.id);
  }
  const found=candidates.map(p=>({p,score:raidPotential(p,kind,ivs)})).filter(x=>x.score).sort((a,b)=>b.score.score-a.score.score)[0];
  if(!found)return {html:rating('레이드','최신 검증 필요','사용 가능한 최신 PvE 기술 데이터가 없거나 해당 형태의 기술·시간 데이터가 부족해.'),grade:null};
  const assess=found.p,score=found.score;
  const max=raidMaxForType(score.skillType);const rel=max?score.score/max:null;
  if(!rel||!Number.isFinite(rel))return {html:rating('레이드','최신 검증 필요','동일 타입 비교군 자료 부족.'),grade:null};
  // Heuristic normalized to strongest ordinary-form attacker; NOT raid DPS/TDO simulation.
  const g=rel>=.84?3:rel>=.67?2:rel>=.45?1:0;
  const caution=score.elite?' · 이벤트/대단한 기술머신 확인 필요':'';
  const freshness=S.db.raid?.freshness||'source_version_unverified';
  const uncertain=freshness!=='http_modified_recent_unconfirmed_game';
  const sourceWarning=uncertain?' · 출처 자료 갱신일 미확인/오래됨':' · 기술 자료 HTTP 변경 시각 최근';
  const ivDecision=raidIvAssess(assess,kind,ivs,g);
  const ivText=`동일 레벨·기술의 공격 15 대비 화력 근사 ${ivDecision.percent.toFixed(2)}% (공격 IV ${ivs[0]}/15) · 방어/체력 ${ivs[1]}/${ivs[2]}`;
  return {assess, score, html:rating('레이드 상대 화력 (참고 추정)',g,`${speciesName(assess.dex)}${kind==='shadow'?' (그림자)':''} · ${TYPES[score.skillType]||score.skillType} 타입 비교 기준 화력 ${Math.round(rel*100)}%${caution}${sourceWarning}`)+ivStatusMarkup(ivDecision,ivText),grade:g,ivDecision,
    note:'개체별 화력 비율은 같은 종족·기술·레벨에서 공격 IV만 변화시키는 근사치야. 실제 레이드 보스별 DPS, TDO, 기절 횟수, 브레이크포인트, 날씨·팀 버프는 계산하지 않아. IV 육성 문턱값은 앱 자체 권고 기준이야.',move:[score.fast,score.charged].map(moveLabel).join(' / ')};
}
function rocketSection(p,kind,ivs){
  // The current Rocket leader / Giovanni roster is NOT part of the verified
  // sources. Grade only a clearly marked generic grunt charge-cycle proxy.
  const proxy=S.db?.valuation?.[p.id]?.rocket;
  if(S.full && Number.isInteger(proxy?.grade) && proxy.confidence==='low_no_roster'){
    const explain=`${moveLabel(proxy.fast)} / ${moveLabel(proxy.charged)} · 약 ${proxy.turns}턴 기준. 빠른 차징 잠재력만 반영하며 실제 상대·실드·내구·상성 미반영.`;
    return {html:rating('조무래기 · 범용 기술 운용 (참고 추정)',proxy.grade,explain)+
      rating('리더 · 알로 / 시에라 / 클리프','최신 검증 필요','현재 상대 편성·실드·상성 데이터 미연동')+
      rating('보스 · 비주기','최신 검증 필요','현재 상대 편성 데이터 미연동'),
      note:'이 별점은 로켓단 승률 또는 특정 리더 공략 등급이 아니야. 실제 대진 메타 검증이 필요해.'};
  }
  const text=kind==='shadow'?'그림자 화력 보너스는 적용되지만 내구력이 낮아지고 화풀이 기술 제한이 있어.':'상대 포켓몬 타입·기술·실드와 편성에 따라 효율이 달라져.';
  const moves=S.db.pvp_moves||{};let spam='';
  if(S.full&&p.quick?.length&&p.charge?.length&&Object.keys(moves).length){
    const speed=p.quick.flatMap(f=>p.charge.map(c=>({f,c,quick:moves[f],charge:moves[c]})))
      .filter(x=>x.quick?.energyGain>0&&x.charge?.energy>0&&x.quick?.cooldown>0)
      .map(x=>({...x,turns:Math.ceil(x.charge.energy/x.quick.energyGain)*x.quick.cooldown})).sort((a,b)=>a.turns-b.turns)[0];
    if(speed)spam=`차징 기술 준비 시간 참고: ${moveLabel(speed.f)} / ${moveLabel(speed.c)} 약 ${speed.turns}턴(기술·실드·교체 상황에 따라 달라짐).`;
  }
  let target='';
  const advantages={normal:[],fire:['풀','얼음','벌레','강철'],water:['불꽃','땅','바위'],electric:['물','비행'],grass:['물','땅','바위'],ice:['풀','땅','비행','드래곤'],fighting:['노말','얼음','바위','악','강철'],poison:['풀','페어리'],ground:['불꽃','전기','독','바위','강철'],flying:['풀','격투','벌레'],psychic:['격투','독'],bug:['풀','에스퍼','악'],rock:['불꽃','얼음','비행','벌레'],ghost:['에스퍼','고스트'],dragon:['드래곤'],dark:['에스퍼','고스트'],steel:['얼음','바위','페어리'],fairy:['격투','드래곤','악']};
  if(S.full&&p.quick?.length&&Object.keys(moves).length){
    const options=p.quick.map(id=>({id,info:moves[id]})).filter(x=>x.info?.type&&x.info?.power);
    const candidate=options.sort((a,b)=>(b.info.power/(b.info.cooldown||1000))-(a.info.power/(a.info.cooldown||1000)))[0];
    if(candidate?.info?.type){const against=advantages[candidate.info.type]||[];if(against.length)target=`${moveLabel(candidate.id)} 기준 타입 상성상 ${against.join('·')} 상대에게 유리할 수 있어. 단, 개별 적 기술·내구·실드는 미반영.`;}
  }
  return {html:rating('조무래기','최신 검증 필요',target||text)+rating('리더 · 알로 / 시에라 / 클리프','최신 검증 필요','현재 편성·실드 제거 속도 및 상성 확인 전 확정 불가.')+rating('보스 · 비주기','최신 검증 필요','현재 보스 편성 및 대진 기술 확인 필요.'),note:[spam,target].filter(Boolean).join(' ')||'상대의 실제 기술·타입·편성 검증 전 판정 유보.'};
}
function maxSection(kind){if(kind==='dynamax'||kind==='gigantamax')return rating('맥스배틀','최신 검증 필요','기입한 개체가 해당 맥스 형태인지 확인해야 해. 맥스기술 위력·회복·방어 역할 및 종족 출시 여부의 검증 자료가 없어.');return rating('맥스배틀','참가 불가','선택한 개체가 별도의 맥스 능력을 갖지 않았다면 참가할 수 없어. 메가·원시는 맥스배틀에 적용되지 않아.');}
function verdict(pvp,raid,form,p,ivs,specialKeep=false,auxRaid=null){
  const all=pvp.all||[];
  const auxDecision=auxRaid?.grade>=2?auxRaid?.ivDecision:null;
  if(!S.full)return {txt:'⏸️ 정식 데이터 갱신 필요',note:'현재는 시연용 도감만 있어. 종족·개체별 전투 투자가치를 확정하지 않아.'};
  const ivPerfect=ivs.every(v=>v===15),ivNundo=ivs.every(v=>v===0);
  const specialSpecies=['전설의 포켓몬','환상의 포켓몬','울트라비스트'].includes(classification(p));
  const protectedForm=['shadow','mega','primal','gigantamax','dynamax'].includes(form);
  const uncertain=!S.full||p.catalog_only||(!all.length&&raid.grade===null)||p.released===false;
  if(specialKeep||specialSpecies||protectedForm||ivPerfect||ivNundo){
    const reasons=[];
    if(specialKeep)reasons.push('직접 선택한 특별 보존 개체');
    if(specialSpecies)reasons.push(classification(p)+'은 획득·교환 가치가 있을 수 있음');
    if(protectedForm)reasons.push('특수 형태 보유 가치는 전투 IV와 별개');
    if(ivPerfect)reasons.push('100% 개체');
    if(ivNundo)reasons.push('0/0/0 희귀 수집 개체');
    const rec=all.some(x=>x.decision?.level==='recommend')||raid.ivDecision?.level==='recommend'||auxDecision?.level==='recommend';
    return {txt:rec?'✅ 육성 추천 · 특별 개체 보존':'🔒 박사에게 보내지 말기 · 특별 개체 보존',
      note:reasons.join(' / ')+'. 해당 개체를 버리기 전에 한정 기술, 색이 다른 여부, 교환·수집 가치를 확인해.'};
  }
  const recommended=all.filter(x=>x.decision?.level==='recommend');
  const maybe=all.filter(x=>x.decision?.level==='maybe');
  if(recommended.length||raid.ivDecision?.level==='recommend'||auxDecision?.level==='recommend'){
    const areas=[...recommended.map(x=>x.label),...(raid.ivDecision?.level==='recommend'?['레이드']:[]),...(auxDecision?.level==='recommend'?['메가진화 활용 후보']:[])];
    return {txt:'✅ 이 개체 육성 추천',note:`입력 IV ${ivs.join('/')} 기준 ${areas.join('·')}에서 자체 투자 기준 충족. 별의모래·XL사탕 투자 전 기술·배틀 팀·보스 상성을 확인해.`};
  }
  if(maybe.length||raid.ivDecision?.level==='maybe'||auxDecision?.level==='maybe'){
    const areas=[...maybe.map(x=>x.label),...(raid.ivDecision?.level==='maybe'?['레이드']:[]),...(auxDecision?.level==='maybe'?['메가진화 활용 후보']:[])];
    return {txt:'⚖️ 조건부 보관 · 더 좋은 IV 확보 시 교체',note:`${areas.join('·')}에서 보조 전력 또는 임시 육성 후보야. 대량 강화는 비추천.`};
  }
  if(uncertain||raid.grade===null){
    return {txt:'⏸️ 박사에게 보내기 판정 보류',note:'현재 형태·기술·종족 데이터가 부족해 낮은 가치라고 확정할 수 없어. 먼저 최신 데이터 확인이 필요해.'};
  }
  // The species' PvP ranking and estimated raid grade must both be weak or
  // the current IV must fail all published league and raid investment criteria.
  return {txt:'🗑️ 박사에게 보내기',note:`IV ${ivs.join('/')} 기준: 레이드·슈퍼·하이퍼·마스터리그에서 투자 권장 조건 미충족. 단, 색이 다른/이벤트/한정 기술/럭키/교환용·도감 최초 보유 개체라면 보내지 말고 상단 '특별 보존 개체'를 선택해 재평가해.`};
}
function metaContext(p){
  if(!S.full||!S.db?.valuation)return '';
  const item=S.db.valuation[p.id];
  const m=S.metaIndex;
  const age=Date.now()-Date.parse(m?.last_checked_at||'');
  const checked=m?.monitor_status==='verified'&&m.version===S.db.meta_version&&Number.isFinite(age)&&age>=0&&age<3*86400000;
  const history=S.metaChanges?.affected?.filter(x=>x.id===p.id)||[];
  let label='첫 기준선 · 과거 비교 없음',symbol='◉',tone='neutral';
  if(m?.monitor_status==='incomplete'){
    label='최신 확인 실패 · 이전 검증 가치 보존';symbol='!';tone='muted';
  }else if(checked){
    label='최근 확인 기준 기존 가치 유지';symbol='✓';tone='same';
    if(m.assessment==='initial_baseline')label='최초 검증 기준선 · 이후 변동 비교 예정';
    if(m.assessment==='unaffected'||m.assessment==='no_value_change')label='게임 데이터 변경 감지 · 육성 가치 변화 없음';
    if(m.assessment==='comparison'&&history.length){
      const ups=history.filter(x=>x.trend==='up').length,downs=history.filter(x=>x.trend==='down').length;
      if(ups&&downs)label='항목별 가치 상승·하락 발생';
      else if(ups)label='일부 분야 가치 상승';
      else if(downs)label='일부 분야 가치 하락';
      else label='메타 분석값 수정 · 별점 유지';
      tone='changed';symbol='↻';
    }
  }else{
    label='저장된 기준선 · 최신 점검 미확인';symbol='◷';tone='muted';
  }
  const updated=checked?String(m.last_checked_at||'').slice(0,16).replace('T',' ')+' UTC':'검증 시각 확인 필요';
  const adjustments=history.map(x=>{
    const dom={raid:'레이드',rocket:'로켓단 범용',1500:'슈퍼리그',2500:'하이퍼리그',10000:'마스터리그'}[x.domain]||x.domain;
    const arrow=x.trend==='up'?'↑':x.trend==='down'?'↓':'↔';
    const b=v=>Number.isInteger(v)?['☆☆☆','★☆☆','★★☆','★★★'][v]:'미확인';
    return `<li>${esc(dom)} ${esc(b(x.old))} → ${esc(b(x.new))} ${esc(arrow)} · ${esc(x.detail)}</li>`;
  }).join('');
  return `<section class="panel meta-card ${tone}"><div class="meta-heading"><b>${esc(symbol)} ${esc(label)}</b><small>최근 점검: ${esc(updated)}</small></div>`+
    `<p class="smallnote">${esc(item?'현재 기준선과 비교한 종족·형태별 평가':'해당 종족 평가 미계산')} · 게임 버전 직접 검증 자료가 아닌 공개 데이터 변경 감지 결과야.</p>`+
    (adjustments?`<ul class="meta-history">${adjustments}</ul>`:'')+`</section>`;
}

function applyMetaPatch(catalog,patch){
  if(!catalog||patch?.schema!==1||patch.from_version!==catalog.meta_version)return null;
  const next=JSON.parse(JSON.stringify(catalog));
  Object.assign(next,patch.top||{});
  const changes=patch.maps||{};
  for(const k of ['species','pvp_moves','valuation']){
    const ch=changes[k];if(!ch)continue;
    const current=next[k]||{};
    for(const del of ch.delete||[])delete current[del];
    Object.assign(current,ch.set||{});next[k]=current;
  }
  for(const k of ['ranks','raid']){
    const ch=changes[k];if(!ch)continue;
    const current=next[k]||{};
    for(const [field,detail] of Object.entries(ch)){
      if(detail.kind==='value')current[field]=detail.value;
      else if(detail.kind==='map'){
        const target=current[field]||{};
        for(const del of detail.delete||[])delete target[del];
        Object.assign(target,detail.set||{});current[field]=target;
      }else return null;
    }
    next[k]=current;
  }
  if(patch.pokemon){
    const pokes=new Map((next.pokemon||[]).map(x=>[x.id,x]));
    for(const del of patch.pokemon.delete||[])pokes.delete(del);
    for(const [id,p] of Object.entries(patch.pokemon.set||{}))pokes.set(id,p);
    next.pokemon=Array.from(pokes.values());
  }
  return next.meta_version===patch.to_version&&validCatalog(next)?next:null;
}
// v5.2: One consistent human-readable Pokémon GO evaluation sheet.
// This formats verified/estimated domain outputs; it does NOT fabricate
// Max Battle ratings, current raid bosses, or Rocket leader rosters.
function reportGrade(value){return Number.isInteger(value)?['☆☆☆','★☆☆','★★☆','★★★'][value]:'검증 필요';}
function reportValue(value){
  if(!Number.isInteger(value))return '아직 판단할 수 없어요';
  return value===3?'아주 좋아요':value===2?'쓸 만해요':value===1?'특정 상황에서만 써요':'다른 포켓몬을 추천해요';
}
function simpleIvChoice(level){
  if(level==='recommend')return '✅ 내 개체값으로 키워도 좋아요.';
  if(level==='maybe')return '📦 일단 보관해요. 더 좋은 개체와 비교해요.';
  if(level==='reject')return '❌ 이 전투를 위해 키우는 것은 추천하지 않아요.';
  return '❔ 내 개체값이 좋은지 아직 확인할 수 없어요.';
}
function simpleFinalDecision(decision){
  const s=String(decision?.txt||'');
  if(s.startsWith('🗑️'))return {head:'🗑️ 박사에게 보내기 후보',body:'지금 확인된 전투 기준으로는 키우기 어려운 개체예요. 보내기 전에 특별한 개체인지 확인해요.'};
  if(s.startsWith('🔒'))return {head:'🔒 소중히 보관해요',body:'전설·특별 형태 등은 개체값만 보고 보내면 안 돼요.'};
  if(s.startsWith('✅'))return {head:'✅ 이 개체는 키워도 좋아요',body:'잘 맞는 전투가 있어요. 별의모래를 쓰기 전에 추천 기술도 확인해요.'};
  if(s.startsWith('⚖️'))return {head:'📦 지금은 보관해요',body:'당장 많은 별의모래를 쓰기보다 더 좋은 개체가 나오는지 살펴봐요.'};
  return {head:'❔ 아직 결정하지 마세요',body:'확실한 정보가 부족해요. 버리거나 많이 강화하지 말고 잠시 보관해요.'};
}
function simpleUses(raid,pvp,mega,kind){
  const good=[];
  if(Number.isInteger(raid?.grade)&&raid.grade>=2)good.push('레이드');
  if(Number.isInteger(mega?.grade)&&mega.grade>=2)good.push('메가진화 레이드');
  for(const x of (pvp?.all||[]))if(x.grade>=2)good.push(x.label);
  if(good.length)return `잘하는 전투: ${[...new Set(good)].join(', ')}. 단, 지금 가진 개체값이 알맞은지는 따로 확인해야 해요.`;
  if(raid?.grade===null&&!(pvp?.all||[]).length)return '어느 전투에 좋은지 확인할 자료가 아직 부족해요.';
  if(kind==='dynamax'||kind==='gigantamax')return '맥스배틀 성능은 아직 확인되지 않았어요. 일반 레이드 성능과는 달라요.';
  return '지금 확인된 평가에서는 특별히 잘하는 전투가 없어요. 자세한 조건은 아래에서 확인해요.';
}
function reportLine(name,value,extra='',choice=null){
  const status=reportValue(value);
  const note=choice?`<p class="report-easy-choice">${esc(simpleIvChoice(choice))}</p>`:'';
  const detail=extra?`<details class="report-inline-detail"><summary>자세한 숫자·이유 보기</summary><p>${esc(extra)}</p></details>`:'';
  return `<li><b>${esc(name)}</b>: <strong class="report-stars">${esc(reportGrade(value))}</strong> <span class="report-term">${esc(status)}</span>${note}${detail}</li>`;
}
function reportMetaStatus(p){
  const m=S.metaIndex;
  if(!S.full)return '시연용 데이터 · 최신 평가 확인 불가';
  if(!m)return '저장된 공개 데이터 · 변경 확인 기록 없음';
  if(m.monitor_status==='incomplete')return '최신 자료 확인 실패 · 이전 평가 보존';
  const validAge=Date.now()-Date.parse(m.last_checked_at||'');
  if(m.monitor_status!=='verified'||!Number.isFinite(validAge)||validAge<0||validAge>3*86400000)return '마지막 데이터 점검이 오래됨 · 재확인 필요';
  if(m.assessment==='initial_baseline')return '첫 검증 기준선 · 가치 변화 비교 전';
  if(m.assessment==='comparison')return '원천 데이터 변경 점검 완료 · 항목별 변동 확인';
  return '최근 공개 데이터 점검 · 기존 평가 유지';
}
function reportSpeciesVerdict(raid,pvp,mega){
  const pvpTop=Math.max(-1,...(pvp.all||[]).map(x=>Number.isInteger(x.grade)?x.grade:-1));
  const raidTop=Math.max(Number.isInteger(raid?.grade)?raid.grade:-1,Number.isInteger(mega?.grade)?mega.grade:-1);
  if(pvpTop===3)return '🔥 리그 핵심 활용 후보 (종족 랭킹 기준)';
  if(raidTop===3)return '✅ 레이드 상위권 후보 (참고 화력 추정)';
  if(Math.max(pvpTop,raidTop)===2)return '✅ 실전 활용 추천 종족 (일부 분야)';
  if(Math.max(pvpTop,raidTop)===1)return '⚖️ 조건부 활용 종족';
  if(Math.max(pvpTop,raidTop)===0)return '❌ 현재 확인된 전투 분야 우선순위 낮음';
  return '⏸️ 종족 메타 가치 검증 필요';
}
function reportReason(p,raid,pvp,decision,form,ivs){
  let reasons=[];
  if(raid?.grade!==null && Number.isInteger(raid?.grade)){
    const battler=raid.assess?.dex?speciesName(raid.assess.dex):speciesName(p.dex);
    reasons.push(`${battler}의 동일 타입 공격수 대비 레이드 상대 화력 ${reportValue(raid.grade)}(참고 추정)`);
  }
  const best=(pvp.all||[]).filter(v=>Number.isInteger(v.grade)).sort((a,b)=>b.grade-a.grade||a.rank-b.rank)[0];
  if(best)reasons.push(`${best.label} ${speciesName(best.p.dex)} PvPoke 종족 ${best.rank}위`);
  if(form==='dynamax'||form==='gigantamax')reasons.push('맥스배틀 전용 평가 데이터는 아직 부족해 등급을 확정하지 않음');
  if(!reasons.length)reasons.push('형태·전투 자료가 불충분해 성능을 단정하지 않음');
  if(decision.txt.includes('박사에게 보내기'))reasons.push('선택한 개체의 투자 기준은 별도 판정; 수집·교환 가치는 미반영');
  return reasons.join(' · ')+'.';
}
function quickEvaluationReport({p,kind,ivs,cls,type,stages,pvp,raid,rocket,mega,decision,title,sourceTime}){
  const identity=kind==='normal'?title:`${KINDS[kind]} ${title}`;
  const formLabel=raid.assess?.dex?speciesName(raid.assess.dex):(pvp.best?.p?.dex?speciesName(pvp.best.p.dex):speciesName(p.dex));
  const lastStage=stages.length>1||stages.some(s=>s.pokemons.length>1);
  const target=`${kind==='dynamax'?'다이맥스 ':kind==='gigantamax'?'거다이맥스 ':kind==='shadow'?'그림자 ':''}${formLabel}${lastStage?' (진화 계열의 분석 대상)':''}`;
  const leagueItems=[['슈퍼리그',1500],['하이퍼리그',2500],['마스터리그',10000]].map(([label,cap])=>{
    const item=(pvp.all||[]).find(x=>x.cap===cap);
    if(!item){
      if(p.dex===132||['mega','primal'].includes(kind))return `<li><b>${esc(label)}</b>: <strong>참가 불가</strong><small>선택된 포켓몬·변신 형태의 일반 GO배틀리그 출전 제한</small></li>`;
      return reportLine(label,null,'종족·형태별 검증 자료 없음');
    }
    const preferred=item.iv?.preferred?.length?(cap===10000?'15/15/15 중심':item.iv.preferred.join(' · ')):'검증 필요';
    const current=item.iv?`현재 IV ${item.iv.rank}/${item.iv.count}위`:'IV 순위 미확인';
    return reportLine(label,item.grade,`${speciesName(item.p.dex)} · ${current} · 선호 IV: ${preferred} · ${item.decision?.text||'개체 평가 보류'}`,item.decision?.level||'unknown');
  }).join('');
  const normalMove=raid.move||'기술 검증 필요';
  const pvpMove=pvp.best?.moves?.length?pvp.best.moves.map(moveLabel).join(' / '):'기술 검증 필요';
  const currentIv=ivs.join('/');
  const raidIv=raid.ivDecision?.percent;
  const raidIvText=Number.isFinite(raidIv)?`공격 15 대비 화력 근사 ${raidIv.toFixed(2)}% · ${raid.ivDecision.text}`:'PvE 기술 데이터 또는 현재 폼 검증 필요';
  const rocketProxy=S.db?.valuation?.[p.id]?.rocket;
  const rocketGrade=(rocketProxy?.confidence==='low_no_roster'&&Number.isInteger(rocketProxy?.grade))?rocketProxy.grade:null;
  // Separately evaluate the Mega form, never applying its grade as an ordinary/Dynamax grade.
  // Provided by render() so it can also contribute to conservative KEEP decisions.
  const megaName=mega?.assess?.dex?`메가 ${speciesName(mega.assess.dex)}`:'메가 형태';
  const dmaxDisclaimer=(kind==='dynamax'||kind==='gigantamax')?'선택한 개체가 실제 맥스 능력을 보유했는지 확인해야 하며, 진화 후 맥스 가능 여부도 별도 검증해야 해. 레이드 화력과 맥스배틀 성능은 별개야.':'';
  const generated=String(sourceTime||'갱신 시각 확인 불가').replace('T',' ').replace(/Z$/,' UTC');
  const meta=reportMetaStatus(p);
  const lastChecked=S.metaIndex?.last_checked_at?String(S.metaIndex.last_checked_at).replace('T',' ').replace(/Z$/,' UTC'):'미확인';
  const familyNote=stages.some(s=>s.pokemons.length>1)?'분기 진화가 존재하므로 실제 진화 대상의 기술·평가를 상세 분석에서 확인해. ':'';
  const easyDecision=simpleFinalDecision(decision);
  const easyUse=simpleUses(raid,pvp,mega,kind);
  return `<article class="report-sheet" aria-labelledby="report-title">
    <div class="report-eyebrow">POGO META CHECKER · 표준 육성 판정서</div>
    <h2 id="report-title">${esc(identity)} <span>(${esc(currentIv)})</span></h2>
    <div class="report-intro">${img(p.dex,title,'report-img')}<div class="report-identity">
      <p><b>분류:</b> ${esc(cls)} · ${esc(KINDS[kind])} (${esc(type)})</p>
      <p><b>개체값:</b> ${esc(currentIv)} (${percent(ivs)}%)</p>
      <p><b>평가 기준:</b> ${esc(target)}</p>
    </div></div>
    <section class="report-snapshot" aria-label="한눈에 보는 쉬운 결론">
      <h3>🌟 한눈에 결과</h3>
      <p class="report-snapshot-label">이 포켓몬, 어디에 좋아요?</p><p>${esc(easyUse)}</p>
      <p class="report-snapshot-label">내가 가진 개체는 어떻게 할까요?</p>
      <p class="report-snapshot-decision">${esc(easyDecision.head)}</p>
      <p>${esc(easyDecision.body)}</p>
    </section>
    <p class="report-scale">별점 읽는 법: ★★★ 아주 좋아요 · ★★☆ 쓸 만해요 · ★☆☆ 특정 상황에서만 · ☆☆☆ 비추천</p>
    <h3>레이드 · 큰 보스를 함께 잡는 전투</h3><p class="report-help">레이드 점수는 같은 타입의 다른 포켓몬과 공격 능력을 비교한 참고 점수예요.</p><ul class="report-list">
      ${reportLine('일반·선택 형태',raid.grade,raid.grade===null?'형태별 기술·화력 검증 필요':`${formLabel} · 개체별 투자: ${raid.ivDecision?.text||'보류'}`,raid.ivDecision?.level||'unknown')}
      ${mega?reportLine(megaName,mega.grade,'메가진화 가능 형태의 별도 참고 화력 평가 · 맥스배틀에는 적용되지 않음'):''}
    </ul>
    <h3>맥스배틀 · 특별한 거대 전투</h3><p class="report-one-line"><strong>${kind==='dynamax'||kind==='gigantamax'?'❔ 얼마나 좋은지 아직 몰라요.':'이 형태는 맥스배틀에 참가할 수 없어요.'}</strong></p>
    <details class="report-inline-detail"><summary>왜 아직 점수를 못 매기나요?</summary><p>최신 검증 필요 · 맥스기술·실드·회복 역할과 실제 출시/획득 조건 미연동${kind==='dynamax'||kind==='gigantamax'?' (선택한 맥스 개체 기준)':' (일반 개체는 맥스배틀 참가 불가)'}</p></details>
    <h3>GO배틀리그 · 다른 사람과 겨루는 전투</h3><p class="report-help">리그마다 좋은 개체값이 달라요. 별점은 포켓몬 종류의 강함이고, 아래 문장은 네 개체값의 추천 여부예요.</p><ul class="report-list">${leagueItems}</ul>
    <h3>GO로켓단 · 악당과 싸우는 전투</h3><p class="report-help">조무래기 점수는 참고용이에요. 실제 상대가 바뀌면 결과도 달라져요.</p><ul class="report-list">${reportLine('조무래기',rocketGrade,'실제 상대 편성 미반영 · 기술을 빨리 쓰는 능력만 참고 추정')}${reportLine('리더 / 비주기',null,'실제 대진 정보 미연동')}</ul>
    <h3>추천 기술 · 이렇게 싸워요</h3><ul class="report-list">
      <li><b>레이드:</b> ${esc(normalMove)}${raid.score?.elite?' · 이벤트/대단한 기술머신 확인':''}</li>
      <li><b>GO배틀리그:</b> ${esc(pvpMove)}</li>
      <li><b>맥스배틀:</b> 검증된 맥스기술 자료 없음</li>
    </ul>
    <h3>최종 판정 · 그래서 어떻게 할까요?</h3>
    <p class="report-verdict"><span>지금 가진 개체에 대한 추천</span>${esc(easyDecision.head)}</p>
    <p class="report-easy-verdict">${esc(easyDecision.body)}</p>
    <p class="report-easy-verdict"><b>잊지 마세요:</b> 별점이 높아도 개체값이 좋지 않으면 키우지 않는 편이 나을 수 있어요.</p>
    <details class="report-explain"><summary>🔎 자세한 판단 이유와 숫자 보기</summary>
      <p class="report-genus"><b>종족·진화형 가치:</b> ${esc(reportSpeciesVerdict(raid,pvp,mega))}</p>
      <p class="report-reason"><b>입력 IV 보관·육성 판정:</b> ${esc(decision.txt)}</p>
      <p class="report-reason"><b>핵심 이유:</b> ${esc(reportReason(p,raid,pvp,decision,kind,ivs))}</p>
      <p class="report-reason"><b>개체값 평가:</b> IV ${percent(ivs)}% · ${esc(raidIvText)}. ${esc(decision.note)}</p>
      <p class="report-reason"><b>참고:</b> ${esc(familyNote+dmaxDisclaimer||'종족 자체의 별점과 현재 입력한 IV의 육성 가치는 별도로 계산해.')} ${esc('‘박사에게 보내기’는 보관·투자 제안이며 자동 전송되지 않아. 색이 다른·특별한 기술·의상·럭키·수집용 여부는 직접 확인해.')}</p>
      <p class="report-source"><b>최신 확인 상태:</b> ${esc(meta)} · 평가 데이터: ${esc(generated)} · 원천 변경 점검: ${esc(lastChecked)} · PvPoke / PokeAPI / PoGoAPI · 레이드 점수는 실제 보스 DPS/TDO가 아닌 참고 추정</p>
    </details>
    <footer class="report-source"><b>최근 데이터 확인:</b> ${esc(meta)}<span>별점은 참고용 분석이며, 특별한 포켓몬은 보내기 전에 꼭 확인해요.</span></footer>
    <div class="report-actions"><button type="button" class="listen" id="readBtn">🔊 판정 읽어주기</button><button type="button" class="listen" id="copyReportBtn">📋 판정서 복사</button></div>
  </article>`;
}

function render(name,form,ivs){
  const p=findPokemon(name),pct=percent(ivs);
  if(!p){$('result').innerHTML=`<section class="panel"><h3>포켓몬을 찾지 못했어</h3><p class="smallnote">${esc(name)} · 현재 데이터에 한국어 이름이 없거나 도감이 갱신되지 않았을 수 있어. 상단에서 업데이트를 확인하고 다시 검색해 줘. 도감 전체 자료가 없더라도 IV는 ${ivs.join('/')} = ${pct}%야.</p></section>`;return;}
  const stages=getLine(p),type=p.types?.filter(t=>t!=='none').map(t=>TYPES[t]||t).join(' · ')||'타입 자료 없음';
  const namedForm=(p.dex===888||p.dex===889)?(p.id.includes('crowned')?(p.dex===888?' · 검왕':' · 방패왕'):' · 역전의 용사'):'';
  const title=speciesName(p.dex)+namedForm,cls=classification(p);
  const current = mainForm(p,form),f= current||p;
  const pvp=pvpAnalysis(p,form,stages,ivs), raid=raidSection(p,form,stages,ivs), rocket=rocketSection(f,form,ivs);
  const auxMega=!['shadow','mega','primal'].includes(form)&&findTransformation(stages,'mega').some(x=>x.released!==false)
    ?raidSection(p,'mega',stages,ivs):null;
  const decision=verdict(pvp,raid,form,p,ivs,Boolean($('specialKeep')?.checked),auxMega);
  const moves=pvp.best?.moves?.length?pvp.best.moves.map(moveLabel).join(' / '):(raid.move||'추천 기술 검증 필요');
  const typeNote=form==='shadow'?'그림자는 공격 피해 +20% · 받는 피해 +20% (보통의 전투 조건). 화풀이 제거 이벤트 확인 필요.':form==='purified'?'정화 후 개체값을 그대로 사용해. 일반형 전투 성능 기준으로 비교하고 은혜갚기는 별도 확인.':form==='dynamax'||form==='gigantamax'?'개체가 해당 맥스 능력을 실제로 보유하는지 먼저 확인해야 해. 일반 포켓몬이 자동으로 전환되지는 않아.':form==='mega'||form==='primal'?'메가·원시는 전투 중 활용 형태이며 일반 GO배틀리그에서는 통상 사용 불가. 실제 변신 가능 종족인지 확인해야 해.':'일반 포켓몬 기준. 전투 중 맥스 변신 불가.';
  let hero=`<section class="panel"><div class="pk-hero">${img(p.dex,title)}<div><h2>${esc(title)}</h2><div class="dex">도감 #${p.dex}</div><div class="badges"><span class="tag">${esc(cls)}</span><span class="tag">${esc(type)}</span><span class="tag">${esc(KINDS[form])}</span></div></div></div><div class="ivmeter"><div><small>현재 IV · 공 / 방 / 체</small><b>${ivs.join(' / ')}</b><div class="meter"><i style="width:${pct}%"></i></div></div><div><small>합계 ${ivs.reduce((a,b)=>a+b)}/45</small><strong>${pct}%</strong></div></div><div class="info">${esc(typeNote)}</div></section>`;
  if(p.catalog_only)hero+=`<section class="panel"><p class="smallnote">⚠️ 도감 명칭만 확인된 포켓몬이야. 포켓몬GO 출시·형태·기술·전투 가치가 검증되지 않아 임의로 등급을 생성하지 않아.</p></section>`;
  let skillContent=`<p class="smallnote">${esc(moves)}</p>`+(pvp.best?`<p class="smallnote">기준: ${esc(pvp.best.label)} · ${esc(speciesName(pvp.best.p.dex))} · 이벤트/대단한 기술머신 필요 여부 별도 확인</p>`:'');
  S.voiceText=`${title}. 개체값 ${pct}퍼센트. ${decision.txt}. ${decision.note}`;
  let sourceTime=S.full?(S.db.generated_at||'갱신 시각 확인 불가'):'정식 데이터 미연결';
  const formStatus=(!current&&['shadow','mega','primal'].includes(form))?`<section class="panel meta-card muted"><p class="smallnote">⚠️ 선택한 특수 형태가 확인되지 않아 해당 형태의 가치 유지 여부를 판정하지 않아.</p></section>`:metaContext(f);
  const report=quickEvaluationReport({p,kind:form,ivs,cls,type,stages,pvp,raid,rocket,mega:auxMega,decision,title,sourceTime});
  $('result').innerHTML=report+
    `<details class="report-details"><summary>🔎 진화·IV 순위·메타 상세 분석 펼치기</summary><div class="report-detail-body">`+
    hero+formStatus+
    panel('02','진화 순서 · 이미지 계보',evoView(stages,p.dex,form),'evo-panel')+
    panel('03','레이드',raid.html+(raid.note?`<p class="smallnote">${esc(raid.note)}</p>`:''))+
    panel('04','GO배틀리그',pvp.html+'<p class="smallnote">선호 IV는 해당 진화형·폼의 4,096개 가상 조합 중 CP 제한 및 레벨 50 기준 스탯곱 상위값이야. 최소 포획 IV, 현재 보유 레벨, 베스트 파트너 Lv.51, CMP·브레이크포인트, 컵별 규칙은 제외해. 종족 메타 별점과 입력 IV 추천은 다른 지표이며 승률을 보장하지 않아.</p>')+
    panel('05','GO로켓단',rocket.html+`<p class="smallnote">${esc(rocket.note)}</p>`)+
    panel('06','맥스배틀',maxSection(form))+
    panel('07','추천 기술',skillContent)+
    `<section class="panel decision-panel"><h3 class="sec-title"><b>08</b> 입력 IV 최종 육성·보관 판정</h3><div class="decision">${esc(decision.txt)}</div><p>${esc(decision.note)}</p><p class="smallnote">주의: ‘박사에게 보내기’는 전투 투자 효율에 대한 보관 정리 제안이지 자동 전송 기능이 아니야. 보내기는 되돌릴 수 없으므로 색이 다른·이벤트·한정기술·럭키·희귀 개체와 향후 기술 변경 가능성을 반드시 별도로 확인해.</p><div class="summarylist"><span>${esc(cls)}</span><span>${esc(KINDS[form])}</span><span>IV ${pct}%</span></div><div class="sources">게임 데이터: ${esc(sourceTime)} · PvPoke GM: ${esc(S.db.pvpoke_timestamp||'시각 미표기')}<br>레이드: ${esc(S.db.raid?.available?'PoGoAPI 공개 기술값 기반 참고 추정 (최신 게임 버전 미확인)':'전용 데이터 없음')} · 로켓단 로테이션/맥스배틀: 검증 필요</div></section></div></details><div id="aiExtra"></div>`;
  $('readBtn').addEventListener('click',()=>speak(S.voiceText));
  $('copyReportBtn').addEventListener('click',async()=>{
    const content=document.querySelector('.report-sheet')?.innerText||S.voiceText;
    try{
      if(!navigator.clipboard?.writeText)throw new Error('clipboard unavailable');
      await navigator.clipboard.writeText(content);
      $('copyReportBtn').textContent='✓ 판정서 복사됨';
    }catch{
      window.prompt?.('아래 판정서를 복사해.',content);
    }
  });
  if($('voiceToggle').checked)speak(S.voiceText);
  if($('aiToggle').checked)showAIExplanation(name,form,ivs);
}
function speak(t){
  if(!('speechSynthesis'in window)){alert('이 기기/브라우저는 음성 읽기를 지원하지 않아.');return;}
  try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ko-KR';u.rate=1;u.pitch=1;speechSynthesis.speak(u);}catch(err){console.warn('TTS disabled',err)}
}
async function showAIExplanation(name,form,ivs){
  const mount=$('aiExtra');if(!mount)return;
  mount.innerHTML=panel('✦','AI 추가 설명','<p class="smallnote">선택 기능 확인 중…</p>','ai-out');
  // Optional server only; never block deterministic results or place keys in browser.
  try{
    const r=await fetch('./api/status',{cache:'no-store'});if(!r.ok)throw new Error('선택형 AI 서버 없음');
    const status=await r.json();if(!status.ai_enabled)throw new Error('AI 서버 미설정');
    const ac=new AbortController(),t=setTimeout(()=>ac.abort(),45000);let res;
    try{res=await fetch('./api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,form,atk:ivs[0],def:ivs[1],hp:ivs[2]}),signal:ac.signal})}finally{clearTimeout(t)}
    if(!res.ok)throw new Error('AI 서버 응답 실패');const data=await res.json();
    const a=data.analysis||{};mount.innerHTML=panel('✦','AI 추가 설명',`<p class="smallnote">${esc(a.reason||a.explanation||'추가 설명 없음')}</p><p class="smallnote">AI 설명은 참고용이며, 위 데이터 기반 판정을 바꾸지 않아.</p>`,'ai-out');
  }catch(e){mount.innerHTML=panel('✦','AI 추가 설명',`<p class="smallnote">선택형 AI 서버가 연결되지 않았어. 데이터 기반 분석은 정상 작동해. (${esc(e.message)})</p>`,'ai-out');}
}
function handleSubmit(e){e?.preventDefault();const name=resolveSearchName($('pkname').value.trim()),kind=document.querySelector('input[name="form"]:checked')?.value||'normal';
  $('pkname').value=name;
  const ivs=['atk','def','hp'].map(k=>Number($(k).value));
  if(!name)return alert('포켓몬 이름을 입력해.');
  if(['atk','def','hp'].some(k=>$(k).value==='')||ivs.some(v=>!Number.isInteger(v)||v<0||v>15))return alert('공격·방어·체력은 각각 0~15 정수로 입력해야 해.');
  render(name,kind,ivs);$('result').scrollIntoView({behavior:'smooth',block:'start'});
}
function setSync(msg,sub,ok='wait'){$('syncText').textContent=msg;$('syncMeta').textContent=sub||'';$('syncDot').className='live-dot '+(ok==='ok'?'ok':ok==='error'?'warn':'');}
function activate(db){S.db=db;S.full=!db.sample;indexCatalog();cachedRaidMax=null;pvpIvCache.clear();
  if(S.full){const age=Date.now()-Date.parse(db.generated_at||'');const old=Number.isFinite(age)&&age>8*86400000;const source=String(db.pvpoke_timestamp||'원본 일자 미확인');if(db.meta_schema===5)setSync('검증된 가치 기준선 사용 중 · 변경 확인 대기',`기준선 ${String(db.generated_at||'').slice(0,16).replace('T',' ')} UTC · ${db.pokemon.length}개 형태`, 'wait');else setSync(old?'저장된 데이터 · 최신성 재확인 필요':'검증된 게임 데이터 사용 중',`DB 생성 ${String(db.generated_at||'시각 정보 없음').slice(0,16).replace('T',' ')} UTC · PvPoke 원본 ${source} · ${db.pokemon.length}개 형태`,old?'wait':'ok');}
  else setSync('오프라인 시연용 도감 데이터','정식 전체 데이터가 아직 배포되지 않았어. 리그·레이드 등급은 보류해.','wait');
}
async function fetchValidated(url,timeoutMs=17000){
  const ctrl=new AbortController();const t=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{const r=await fetch(url,{cache:'no-store',signal:ctrl.signal});
    if(!r.ok)throw Error(`HTTP ${r.status}`);return await r.json();
  }finally{clearTimeout(t)}
}
async function checkUpdates(manual=false){
  if(location.protocol==='file:'||location.protocol==='content:'){
    setSync('로컬 시연 모드','원격 증분 갱신은 HTTPS 배포 환경에서 작동해.','wait');return;}
  if(manual){$('refreshBtn').disabled=true;setSync('게임 데이터 변경 확인 중…','먼저 작은 변경 감지 파일만 확인해.');}
  try{
    const manifest=await fetchValidated('./data/meta-index.json',15000);
    if(manifest.schema!==1||!manifest.version||!manifest.catalog)throw Error('변경 감지 정보 오류');
    S.metaIndex=manifest;
    if(manifest.monitor_status==='incomplete'){
      setSync('최신 확인 실패 · 이전 가치 보존',`마지막 정상 점검 ${String(manifest.last_checked_at||'미확인').slice(0,16)} · 검증 실패가 가치 유지의 증거는 아니야.`,'wait');
      return;
    }
    if(manifest.monitor_status!=='verified')throw Error('검증 상태 미확정');
    const age=Date.now()-Date.parse(manifest.last_checked_at||'');
    if(!Number.isFinite(age)||age>3*86400000||age<0){
      setSync('최근 확인 지연 · 이전 가치 보존',`마지막 정상 점검 ${String(manifest.last_checked_at||'미확인').slice(0,16)} · 메타 변화 재확인 필요`,'wait');
      return;
    }
    if(!S.full||S.db.meta_version!==manifest.version){
      let payload=null;
      const delta=manifest.patch;
      if(S.full&&S.db.meta_version&&delta?.from_version===S.db.meta_version&&delta.to_version===manifest.version){
        try{payload=applyMetaPatch(S.db,await fetchValidated(delta.path+'?v='+encodeURIComponent(manifest.version),18000));
          if(payload)console.info('POGO v5 delta patch applied');
        }catch(e){console.warn('Patch failed, falling back to full snapshot',e)}
      }
      if(!payload)payload=await fetchValidated(manifest.catalog+'?v='+encodeURIComponent(manifest.version),22000);
      if(!validCatalog(payload)||payload.sample||payload.pokemon.length<700||payload.meta_version!==manifest.version)throw Error('v5 전체 데이터 무결성 검증 실패');
      activate(payload);
      try{localStorage.setItem('pogo.meta.catalog.v5',JSON.stringify(payload));}catch(e){console.warn('v5 cache unavailable',e)}
      try{S.metaChanges=await fetchValidated(manifest.changes+'?v='+encodeURIComponent(manifest.version),13000);}catch{S.metaChanges=null;}
    }
    if(S.metaChanges===null&&manifest.changes&&manifest.latest_change_count>0&&manifest.assessment==='comparison'){
      try{S.metaChanges=await fetchValidated(manifest.changes+'?v='+encodeURIComponent(manifest.version),13000)}catch{}
    }
    S.metaVersion=manifest.version;
    const checked=String(manifest.last_checked_at||'미표기').slice(0,16).replace('T',' ');
    const label=manifest.assessment==='initial_baseline'?'첫 검증 기준선 생성':
      (manifest.assessment==='unaffected'||manifest.assessment==='no_value_change')?'메타 변화 확인 · 가치 유지':
      manifest.assessment==='unchanged'?'최근 확인 기준 가치 유지':
      '실질적 메타 변경 반영 완료';
    setSync(label,`확인 ${checked} UTC · 데이터 버전 ${manifest.version.slice(0,10)} · 변경 항목 ${manifest.latest_change_count??0}개 · 모바일은 버전 확인 후 선택적 다운로드`, 'ok');
  }catch(e){
    // Compatibility fallback during v4 -> v5 GitHub Pages migration.
    try{
      if(!S.full||S.db.meta_schema!==5){
        const payload=await fetchValidated('./data/catalog.json?v='+Math.floor(Date.now()/3600000));
        if(validCatalog(payload)&&!payload.sample&&payload.pokemon.length>=700){activate(payload);
          try{localStorage.setItem(payload.meta_schema===5?'pogo.meta.catalog.v5':'pogo.meta.catalog.v4',JSON.stringify(payload));}catch{}
        }
      }
    }catch{}
    setSync(S.full?'이전 검증 데이터 사용 중':'정식 데이터 연결 필요',
      `최신 변경 감지 확인 실패 (${e.message}). 기존 평가를 보존하며 최신 가치 유지는 주장하지 않아.`,'wait');
  }finally{$('refreshBtn').disabled=false;}
}
if(window.__POGO_TEST_MODE__)window.__POGO_V5_TESTS={applyMetaPatch,findPokemon,metaContext,leagueIvCompare,leagueIvStatus,raidIvAssess,verdict,moveLabel,moveKey,koreanToKeys,koreanKeyCandidates,resolveSearchName};
function init(){
  if(validCatalog(S.db))activate(S.db);
  for(const cacheKey of ['pogo.meta.catalog.v5','pogo.meta.catalog.v4']){try{const previous=JSON.parse(localStorage.getItem(cacheKey)||'null');if(validCatalog(previous)&&!previous.sample&&previous.pokemon.length>=700){activate(previous);break;}}catch{}}
  $('form').addEventListener('submit',handleSubmit);
  $('pkname').addEventListener('focus',showKoreanKeyboardHint);
  $('pkname').addEventListener('input',showKoreanKeyboardHint);
  showKoreanKeyboardHint();
  $('refreshBtn').addEventListener('click',()=>checkUpdates(true));
  document.querySelectorAll('input[name="form"]').forEach(n=>n.addEventListener('change',()=>{$('formHint').textContent=HINTS[n.value];}));
  document.querySelectorAll('.examples button').forEach(n=>n.addEventListener('click',()=>{const nums=n.dataset.ivs.split(',');$('pkname').value=n.dataset.pokemon;['atk','def','hp'].forEach((x,i)=>$(x).value=nums[i]);$('form').requestSubmit();}));
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();S.installedPrompt=e;$('installBtn').hidden=false;});
  $('installBtn').addEventListener('click',async()=>{if(S.installedPrompt){S.installedPrompt.prompt();await S.installedPrompt.userChoice;S.installedPrompt=null;$('installBtn').hidden=true;}});
  checkUpdates();
  if('serviceWorker'in navigator && (location.protocol==='https:'||location.hostname==='localhost'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
init();
})();
