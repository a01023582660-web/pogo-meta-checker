const fs=require('fs');const vm=require('vm');const assert=require('assert');const path=require('path');
const root=path.resolve(__dirname,'..');
const nodes=new Map();
function el(id){
  if(!nodes.has(id)){
    let handlers={};
    nodes.set(id,{
      value:'',textContent:'',innerHTML:'',checked:false,hidden:false,disabled:false,className:'',
      classList:{add(){},remove(){}},
      addEventListener(type,fn){handlers[type]=fn},
      dispatch(type){if(handlers[type])handlers[type]({preventDefault(){}})},
      scrollIntoView(){},requestSubmit(){el('form').dispatch('submit')}
    });
  }
  return nodes.get(id);
}
const radios=['normal','shadow','purified','dynamax','gigantamax','mega','primal'].map(value=>({value,checked:value==='normal',addEventListener(){}}));
const doc={getElementById:el,querySelector(selector){if(selector==='input[name="form"]:checked')return radios.find(r=>r.checked);return null;},querySelectorAll(q){return q==='input[name="form"]'?radios:[];}};
const context={window:{addEventListener(){}},document:doc,navigator:{},console,Date,Math,Number,String,Object,Array,Set,Map,JSON,Promise,
  localStorage:{getItem(){return null},setItem(){}},
  location:{protocol:'file:',hostname:'',pathname:'/index.html'},
  alert(msg){throw new Error('UNEXPECTED ALERT: '+msg)},
  fetch:async()=>{throw new Error('offline')},
  setTimeout,clearTimeout};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'data/starter.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),context);
function run(name,arr){
  el('pkname').value=name;['atk','def','hp'].forEach((k,i)=>el(k).value=String(arr[i]));
  el('form').dispatch('submit');
  return el('result').innerHTML;
}
let html=run('코코리',[15,14,12]);
assert(html.includes('코리갑'),'Evolution picture sequence');
assert(html.includes('91%'),'IV sum');
assert(html.includes('정식 데이터 갱신 필요'),'No fabricated up-to-date ranking');
html=run('이브이',[1,15,10]);
assert(html.includes('샤미드')&&html.includes('님피아'),'Branching evolution');
assert((html.match(/class="evo-card/g)||[]).length===9,'Nine images in Eevee family');
html=run('메타몽',[12,10,10]);
assert(html.includes('참가 불가'),'Ditto bans');
radios.forEach(r=>r.checked=r.value==='shadow');
html=run('코코리',[15,14,12]);
assert(html.includes('그림자')&&html.includes('검증'),'Shadow not represented as normal');
console.log('PASS app IV, evolution, Eevee branching, PvP restrictions, shadow isolation');
const mock=JSON.parse(JSON.stringify(context.window.POGO_STARTER));
mock.sample=false;mock.generated_at='2026-11-13T00:00:00Z';mock.ranks['1500'].donphan={rank:15,score:90,moves:['MUD_SLAP','EARTHQUAKE']};
for(let i=0;i<710;i++)mock.pokemon.push({id:'fixture_mon_'+i,dex:2000+i,en:'Fixture',base:{atk:150,def:150,hp:150},types:['normal'],tags:[],quick:[],charge:[],elite:[],evos:[],released:true});
context.localStorage.getItem=()=>JSON.stringify(mock);
// independent app context to simulate previously validated downloaded snapshot
const nodes2=new Map();
const el2=id=>{if(!nodes2.has(id))nodes2.set(id,{value:'',innerHTML:'',textContent:'',hidden:false,disabled:false,addEventListener(type,fn){this[type]=fn},requestSubmit(){this.submit({preventDefault(){}})},scrollIntoView(){}});return nodes2.get(id)};
const radios2=radios.map(x=>({...x,checked:x.value==='normal'}));
const c2={...context,window:{...context.window}, document:{getElementById:el2,querySelector(q){return q==='input[name="form"]:checked'?radios2.find(x=>x.checked):null},querySelectorAll(q){return q==='input[name="form"]'?radios2:[]}},location:{protocol:'file:',hostname:'',pathname:'/index.html'}};
vm.createContext(c2);vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),c2);
el2('pkname').value='코코리';['atk','def','hp'].forEach((k,i)=>el2(k).value=String([15,14,12][i]));
el2('form').submit({preventDefault(){}});
assert(el2('result').innerHTML.includes('PvPoke 15위'),'Validated live rank mapped in app');
console.log('PASS validated snapshot read and PvP rank mapping');
