import csv
import io
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from update_data import build_catalog, _normalize_move_map, SOURCES

class SnapshotTests(unittest.TestCase):
    def setUp(self):
        gm={'timestamp':'test','pokemon':[
            {'speciesId':'phanpy','dex':231,'speciesName':'Phanpy','baseStats':{'atk':107,'def':98,'hp':207},'types':['ground'],'tags':[],'family':{'evolutions':['donphan']}},
            {'speciesId':'donphan','dex':232,'speciesName':'Donphan','baseStats':{'atk':214,'def':185,'hp':207},'types':['ground'],'tags':[],'family':{'evolutions':[]}},]}
        header='id,identifier,generation_id,evolves_from_species_id,evolution_chain_id,is_legendary,is_mythical\n'
        self.raws={'gm':json.dumps(gm).encode(), 'species':(header+'231,phanpy,2,,123,0,0\n232,donphan,2,231,123,0,0\n').encode(),
             'names':'pokemon_species_id,local_language_id,name,genus\n231,3,코코리,\n232,3,코리갑,\n'.encode()}
        for league in ('great','ultra','master'):
            self.raws[league]=json.dumps([{'speciesId':'donphan','score':72,'moveset':['COUNTER','BODY_SLAM']}]).encode()
    def test_catalog_links(self):
        out=build_catalog(self.raws,strict=False,now='2026-11-13T00:00:00Z')
        self.assertEqual(out['species']['232']['parent'],231)
        self.assertEqual(out['species']['231']['ko'],'코코리')
        self.assertEqual(out['ranks']['1500']['donphan']['rank'],1)
        self.assertFalse(out['raid']['available'])
        self.assertEqual(len(out['pokemon']),2)
    def test_bad_payload_never_publishes(self):
        self.raws['great']=b'not a json document'
        with self.assertRaises(ValueError):build_catalog(self.raws,strict=False)
    def test_rejects_truncated_production(self):
        with self.assertRaises(ValueError):build_catalog(self.raws,strict=True)
    def test_stale_raid_source_rejected(self):
        # Fresh content at a remote URL is not proof the upstream game data is current.
        self.raws['raid_fast']=json.dumps([{'name':f'Fast{i}','power':5,'duration':500,'energy_delta':5} for i in range(40)]).encode()
        self.raws['raid_charged']=json.dumps([{'name':f'Charge{i}','power':50,'duration':1800,'energy_delta':-50} for i in range(50)]).encode()
        self.raws['raid_learnsets']=json.dumps([{'pokemon_id':i,'form':'Normal','fast_moves':['Fast1'],'charged_moves':['Charge1']} for i in range(1,150)]).encode()
        stale={SOURCES[k]:{'last_modified':'Tue, 11 Nov 2025 00:00:00 GMT'} for k in ('raid_fast','raid_charged','raid_learnsets')}
        output=build_catalog(self.raws,strict=False,now='2026-11-13T00:00:00Z',provider_headers=stale)
        self.assertFalse(output['raid']['available'])
        self.assertIn('stale',output['raid']['freshness'])

    def test_raid_move_validation(self):
        self.assertEqual(_normalize_move_map([{'name':'Tackle','power':3,'duration':500,'energy_delta':5}])['tackle']['ms'],500)
        self.assertEqual(_normalize_move_map([{'name':'Bad','power':5,'duration':0,'energy_delta':2}]),{})

if __name__=='__main__':unittest.main()
