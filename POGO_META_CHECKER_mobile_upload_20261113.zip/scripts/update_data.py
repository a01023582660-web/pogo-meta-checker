#!/usr/bin/env python3
"""Validate and atomically publish a deterministic Pokemon GO data snapshot.

Sources: PvPoke (MIT), PokeAPI species CSV and PoGoAPI move data.
Never silently replace a valid catalog with a partial download.
A failed provider leaves previous published data untouched.
"""
from __future__ import annotations
import csv
import datetime as dt
import email.utils
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "data" / "catalog.json"
BASE = 'https://raw.githubusercontent.com'
SOURCES = {
    'gm': f'{BASE}/pvpoke/pvpoke/master/src/data/gamemaster.json',
    'great': f'{BASE}/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-1500.json',
    'ultra': f'{BASE}/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-2500.json',
    'master': f'{BASE}/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-10000.json',
    'species': f'{BASE}/PokeAPI/pokeapi/master/data/v2/csv/pokemon_species.csv',
    'names': f'{BASE}/PokeAPI/pokeapi/master/data/v2/csv/pokemon_species_names.csv',
    'raid_fast': 'https://pogoapi.net/api/v1/fast_moves.json',
    'raid_charged': 'https://pogoapi.net/api/v1/charged_moves.json',
    'raid_learnsets': 'https://pogoapi.net/api/v1/current_pokemon_moves.json',
}
REQUIRED = ('gm','great','ultra','master','species','names')
USER_AGENT = 'POGO-Meta-Checker/4.0 (personal open-source noncommercial snapshot updater)'


PROVIDER_HEADERS = {}

def download(url: str) -> bytes:
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT, 'Accept': 'application/json,text/csv,*/*'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=35) as r:
                raw = r.read(18_000_001)
                PROVIDER_HEADERS[url] = {'last_modified':r.headers.get('Last-Modified'), 'etag':r.headers.get('ETag')}
            if len(raw) > 18_000_000 or len(raw) < 100:
                raise ValueError(f'Unexpected response size {len(raw)}')
            return raw
        except Exception:
            if attempt == 2: raise
            time.sleep((attempt+1)*2)
    raise AssertionError('unreachable')


def parse_csv(raw: bytes):
    return list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))


def safe_int(value, default=None):
    try: return int(value)
    except (TypeError, ValueError): return default


def _normalize_move_map(moves):
    if not isinstance(moves, list): return {}
    output = {}
    for move in moves:
        if not isinstance(move, dict): continue
        name = str(move.get('name') or '').strip().lower()
        power = move.get('power')
        duration = move.get('duration')
        energy = move.get('energy_delta')
        if not name or power is None or duration is None or energy is None: continue
        try:
            p, dur, en = float(power), float(duration), float(energy)
            if dur <= 0 or dur > 10000 or p < 0: continue
            output[name] = {'power':p,'ms':dur,'energy':en, 'type':str(move.get('type') or '').lower()}
        except (ValueError, TypeError): continue
    return output


def build_catalog(raws: dict, *, strict=True, now=None, provider_headers=None) -> dict:
    gm = json.loads(raws['gm'])
    pokemons = gm.get('pokemon')
    if not isinstance(pokemons,list) or len(pokemons)<(700 if strict else 2):
        raise ValueError('PvPoke GM species list invalid or abnormally small')
    ranks = {}
    for key,cap in (('great','1500'),('ultra','2500'),('master','10000')):
        src = json.loads(raws[key])
        if not isinstance(src,list) or len(src)<(150 if strict else 1):
            raise ValueError(f'{key} rankings missing/too short')
        unique = {}
        for i,entry in enumerate(src):
            sid = str(entry.get('speciesId') or '')
            if sid and sid not in unique:
                unique[sid] = {'rank':i+1, 'score':entry.get('score'), 'moves':entry.get('moveset') or []}
        ranks[cap] = unique
    species_csv, names_csv = parse_csv(raws['species']), parse_csv(raws['names'])
    if len(species_csv)<(700 if strict else 2) or len(names_csv)<(500 if strict else 1):
        raise ValueError('PokeAPI species CSV truncated')
    species={}
    for row in species_csv:
        dex=safe_int(row.get('id'))
        if not dex: continue
        species[str(dex)] = {'dex':dex, 'parent':safe_int(row.get('evolves_from_species_id')),
            'chain':safe_int(row.get('evolution_chain_id')),
            'legendary':row.get('is_legendary')=='1', 'mythical':row.get('is_mythical')=='1'}
    for row in names_csv:
        if row.get('local_language_id') != '3':continue
        dex=row.get('pokemon_species_id')
        if dex in species: species[dex]['ko']=row.get('name')
    pk=[]
    for x in pokemons:
        sid=x.get('speciesId')
        dex=safe_int(x.get('dex'))
        if not sid or not dex or not isinstance(x.get('baseStats'),dict):continue
        base=x['baseStats']
        if not all(k in base for k in ('atk','def','hp')):continue
        fam=x.get('family') or {}
        pk.append({'id':sid,'dex':dex,'en':x.get('speciesName') or sid,
          'base':{a:int(base[a]) for a in ('atk','def','hp')},
          'types':x.get('types') or [],'tags':x.get('tags') or [],
          'quick':x.get('fastMoves') or [],'charge':x.get('chargedMoves') or [],
          'elite':x.get('eliteMoves') or [],'evos':fam.get('evolutions') or [],
          'released':x.get('released',True) is not False})
    if len(pk)<(700 if strict else 2):raise ValueError('Too few valid PvPoke Pokemon entries')
    pvp_moves = {}
    for m in gm.get('moves') or []:
        if isinstance(m,dict) and m.get('moveId'):
            pvp_moves[m['moveId']] = {k:m[k] for k in ('power','energy','energyGain','cooldown','type') if k in m}
    raid={'available':False, 'fast':{}, 'charged':{},'learnsets':{}, 'freshness':'source not verified'}
    optional_keys=('raid_fast','raid_charged','raid_learnsets')
    if all(k in raws for k in optional_keys):
        try:
            rfast = _normalize_move_map(json.loads(raws['raid_fast']))
            rcharged = _normalize_move_map(json.loads(raws['raid_charged']))
            sets = json.loads(raws['raid_learnsets'])
            learnsets={}
            for p in sets if isinstance(sets,list) else []:
                dex=safe_int(p.get('pokemon_id'))
                if not dex:continue
                form=str(p.get('form') or 'Normal').lower()
                learnsets[f'{dex}:{form}']={
                    'fast':p.get('fast_moves') or [], 'charge':p.get('charged_moves') or [],
                    'elite_fast':p.get('elite_fast_moves') or [],'elite_charge':p.get('elite_charged_moves') or []}
            if len(rfast)>25 and len(rcharged)>40 and len(learnsets)>100:
                raid={'available':True,'fast':rfast, 'charged':rcharged,'learnsets':learnsets,'freshness':'unverified'}
        except (ValueError,TypeError,KeyError):pass
    now = now or dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
    # Publishing a newly downloaded old upstream file must not count as "fresh".
    # For optional PoGoAPI sources require verifiable modification dates within 90 days.
    if raid['available'] and provider_headers is not None:
        modified = []
        for k in optional_keys:
            value = provider_headers.get(SOURCES[k],{}).get('last_modified')
            try:
                d = email.utils.parsedate_to_datetime(value).astimezone(dt.timezone.utc)
                modified.append(d)
            except (TypeError,ValueError,IndexError,AttributeError):
                modified=[];break
        now_dt = dt.datetime.fromisoformat(now.replace('Z','+00:00')).astimezone(dt.timezone.utc)
        if len(modified)==3 and all(dt.timedelta(0)<=now_dt-d<=dt.timedelta(days=90) for d in modified):
            raid['freshness']='last-modified checked'
        else:
            raid={'available':False,'fast':{},'charged':{},'learnsets':{},'freshness':'stale or unknown upstream Last-Modified'}
    source_info={k:{'url':SOURCES[k], 'sha256':hashlib.sha256(v).hexdigest()} for k,v in raws.items() if k in SOURCES}
    return {'schema':3,'generated_at':now,'pvpoke_timestamp':gm.get('timestamp') or None,
        'sources':source_info, 'pokemon':pk,'species':species,'ranks':ranks,'pvp_moves':pvp_moves,'raid':raid}


def main():
    downloaded={}
    for k,u in SOURCES.items():
        try:
            print(f'Retrieving {k} ...', flush=True)
            downloaded[k]=download(u)
        except Exception as e:
            if k in REQUIRED: raise RuntimeError(f'Mandatory source {k} unavailable; retained previous snapshot') from e
            print(f'Optional provider {k} failed ({e}); raid data not refreshed',file=sys.stderr)
    if any(k not in downloaded for k in REQUIRED):raise RuntimeError('Mandatory sources missing')
    if any(k not in downloaded for k in ('raid_fast','raid_charged','raid_learnsets')) and TARGET.exists():
        print('Optional raid provider partially unavailable. Retaining last validated raid data if possible.')
    out=build_catalog(downloaded,provider_headers=PROVIDER_HEADERS)
    if not out['raid']['available'] and TARGET.exists():
        try:
            old=json.loads(TARGET.read_text(encoding='utf-8'))
            if old.get('schema')==3 and old.get('raid',{}).get('available') and old.get('raid',{}).get('freshness')=='last-modified checked':
                out['raid']=old['raid']
                for k in ('raid_fast','raid_charged','raid_learnsets'):
                    if k in old.get('sources',{}):out['sources'][k]=old['sources'][k]
                out['raid_source_stale']=True
        except (OSError,ValueError): pass
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    blob=json.dumps(out,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    with tempfile.NamedTemporaryFile('wb',dir=TARGET.parent,prefix='.snapshot-',delete=False) as fd:
        fd.write(blob)
        name=fd.name
    os.replace(name,TARGET)
    print(f'Published {len(out["pokemon"])} forms, {len(out["species"])} species, {len(blob):,} bytes; raid provider={out["raid"]["available"]}')

if __name__=='__main__': main()
