/* POGO META v4 — deterministic, inspectable browser analyzer. No AI credentials required. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KINDS={normal:'일반',shadow:'그림자',purified:'정화',dynamax:'다이맥스',gigantamax:'거다이맥스',mega:'메가 활용',primal:'원시 활용'};
const HINTS={normal:'일반 상태를 기준으로 분석해. 그림자·다이맥스 여부는 자동으로 추정하지 않아.',shadow:'선택한 개체가 실제 그림자 포켓몬일 때만 사용해. 일반 종족의 순위로 대체하지 않아.',purified:'정화가 완료된 현재 개체값을 입력해. +2를 다시 적용하지 않아.',dynamax:'실제로 맥스배틀에서 얻은 다이맥스 개체만 선택해.',gigantamax:'거다이맥스 가능 개체를 별도로 확보한 경우에만 선택해.',mega:'메가진화는 일반·정화 개체의 일시적 변신이야. 그림자 포켓몬은 메가진화할 수 없어.',primal:'원시회귀 가능 종족만 선택해. 그림자 상태에서는 원시회귀할 수 없어.'};
const TYPES={normal:'노말',fire:'불꽃',water:'물',electric:'전기',grass:'풀',ice:'얼음',fighting:'격투',poison:'독',ground:'땅',flying:'비행',psychic:'에스퍼',bug:'벌레',rock:'바위',ghost:'고스트',dragon:'드래곤',dark:'악',steel:'강철',fairy:'페어리'};
const LABELS={THUNDER_SHOCK:'전기쇼크',WILD_CHARGE:'와일드볼트',BULLDOZE:'땅고르기',FAIRY_WIND:'요정의바람',GIGATON_HAMMER:'거대해머',BODY_SLAM:'누르기',POWER_UP_PUNCH:'그로우펀치',SNARL:'바크아웃',DARK_PULSE:'악의파동',BRUTAL_SWING:'세차게휘두르기',FLAME_SPIN:'회오리불꽃',FIRE_SPIN:'회오리불꽃',BLAST_BURN:'블라스트번',PSYSHOCK:'사이코쇼크',SWIFT:'스피드스타',TRAILBLAZE:'개척하기',MUD_SLAP:'진흙뿌리기',EARTHQUAKE:'지진',CHARM:'애교부리기',SHADOW_CLAW:'섀도클로',COUNTER:'카운터',DRAGON_BREATH:'용의숨결',SHADOW_BALL:'섀도볼',SURF:'파도타기',HYDRO_CANNON:'하이드로캐논',ICICLE_SPEAR:'고드름침',PRECIPICE_BLADES:'단애의칼',ORIGIN_PULSE:'근원의파동',SPACIAL_REND:'공간절단',PSYSTRIKE:'사이코브레이크',METAL_CLAW:'메탈클로',CLOSE_COMBAT:'인파이트',AQUA_TAIL:'아쿠아테일',ICE_BEAM:'냉동빔',ROCK_SLIDE:'스톤샤워',FEINT_ATTACK:'속여때리기'};
// CP multipliers, levels 1.0–50.0 in half-level increments; no buddy level 51 assumed.
const CPM = [0.0939999967813491,0.135137430784308,0.166397869586944,0.192650914456886,0.215732470154762,0.236572655026622,0.255720049142837,0.273530381100769,0.290249884128570,0.306057381335773,0.321087598800659,0.335445032295077,0.349212676286697,0.362457748778790,0.375235587358474,0.387592411085168,0.399567276239395,0.411193549517250,0.422500014305114,0.432926413410414,0.443107545375824,0.453059953871985,0.462798386812210,0.472336077786704,0.481684952974319,0.490855810259008,0.499858438968658,0.508701756943992,0.517393946647644,0.525942508771329,0.534354329109191,0.542635762230353,0.550792694091796,0.558830599438087,0.566754519939422,0.574569148039264,0.582278907299041,0.589887911977272,0.597400009632110,0.604823657502073,0.612157285213470,0.619404110566050,0.626567125320434,0.633649181622743,0.640652954578399,0.647580963301656,0.654435634613037,0.661219263506722,0.667934000492096,0.674581899290818,0.681164920330047,0.687684905887771,0.694143652915954,0.700542893277978,0.706884205341339,0.713169102333341,0.719399094581604,0.725575616972598,0.731700003147125,0.734741011137376,0.737769484519958,0.740785574597326,0.743789434432983,0.746781208702482,0.749761044979095,0.752729105305821,0.755685508251190,0.758630366519684,0.761563837528228,0.764486065255226,0.767397165298461,0.770297273971590,0.773186504840850,0.776064945942412,0.778932750225067,0.781790064808426,0.784636974334716,0.787473583646825,0.790300011634826,0.792803950958807,0.795300006866455,0.797803921486970,0.800300002098083,0.802803892322847,0.805299997329711,0.807803863460723,0.810299992561340,0.812803834895026,0.815299987792968,0.817803806620319,0.820299983024597,0.822803778631297,0.825299978256225,0.827803750922782,0.830299973487854,0.832803753381377,0.835300028324127,0.837803755931569,0.840300023555755];
const S = {db:window.POGO_STARTER||null, full:false, byId:new Map(), byDex:new Map(), byName:new Map(), voiceText:'', aiAvailable:false, installedPrompt:null, busy:false};
function validCatalog(v){return !!(v&&v.schema===3&&Array.isArray(v.pokemon)&&v.pokemon.length>=30&&v.species&&v.ranks&&v.ranks['1500']&&v.ranks['2500']&&v.ranks['10000']);}
function indexCatalog(){
  S.byId=new Map();S.byDex=new Map();S.byName=new Map();
  for(const p of (S.db?.pokemon||[])){
    S.byId.set(p.id,p);
    if(!S.byDex.has(p.dex))S.byDex.set(p.dex,[]);
    S.byDex.get(p.dex).push(p);
    const spec=S.db.species[String(p.dex)]||{};
    const names=[p.id,p.en,spec.ko];
    for(let str of names){if(!str)continue;str=norm(str);if(!S.byName.has(str))S.byName.set(str,[]);S.byName.get(str).push(p)}
  }
}
function norm(v){return String(v||'').trim().toLowerCase().replace(/[\s_()·\-]/g,'');}
function speciesName(dex){let d=S.db.species[String(dex)];return d?.ko||S.byDex.get(dex)?.[0]?.en||`#${dex}`}
function findPokemon(raw){
  const v=norm(raw);let found=S.byName.get(v)||[];
  if(!found.length){const parsed=String(raw).replace(/^그림자\s*|^정화\s*|^메가\s*/,'');found=S.byName.get(norm(parsed))||[];}
  return found.find(x=>x.id===x.id.replace(/_(shadow|mega[^_]*|primal)$/,''))||found.find(x=>!x.id.includes('_shadow')&&!x.id.includes('_mega')&&!x.id.includes('_primal'))||found[0]||null;
}
function getLine(current){
  if(!current)return [];
  const origin=S.db.species[String(current.dex)];
  if(!origin?.chain)return [{depth:0,pokemons:[current.dex]}];
  const family=Object.values(S.db.species).filter(p=>p.chain===origin.chain&&S.byDex.has(p.dex)&&S.byDex.get(p.dex).some(x=>x.released!==false));
  const children=new Map();for(const p of family){let id=Number(p.parent||0);if(!children.has(id))children.set(id,[]);children.get(id).push(p.dex)}
  let roots=family.filter(p=>!p.parent||!family.some(x=>x.dex===p.parent)).map(p=>p.dex);
  if(!roots.length)roots=[current.dex];
  const stages=[],seen=new Set();let group=roots,depth=0;
  while(group.length&&depth<14){group=group.filter(d=>!seen.has(d));if(!group.length)break;stages.push({depth,pokemons:group});group.forEach(d=>seen.add(d));group=group.flatMap(d=>children.get(d)||[]);depth++}
  return stages;
}
function img(dex,ko,clazz=''){
  const url=`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${Number(dex)}.png`;
  return `<img class="${clazz}" src="${url}" loading="lazy" alt="${esc(ko)} 포켓몬 이미지" onerror="this.onerror=null;this.style.opacity='.12';this.alt='이미지 연결 실패';">`;
}
function evoView(stages,currentDex,form){
  if(!stages.length)return `<p class="smallnote">진화 정보 없음 · 최신 검증 필요</p>`;
  let out='<div class="evo-grid">';
  for(let i=0;i<stages.length;i++){
    const s=stages[i];if(i>0)out+='<div class="evo-arr" aria-label="진화">→</div>';
    out+='<div class="evo-stage"><div class="'+(s.pokemons.length>1?'evo-branched':'evo-cluster')+'">';
    for(const dex of s.pokemons){const name=speciesName(dex);out+=`<div class="evo-card ${dex===currentDex?'current':''}">${img(dex,name)}<strong>${esc(name)}</strong><small>도감 #${dex}${dex===currentDex?' · 선택':''}</small>${form==='shadow'?'<small>🌑 그림자 계열 참고</small>':''}</div>`;}
    out+='</div></div>';
  }
  return out+'</div><p class="smallnote">이미지: PokeAPI 스프라이트(온라인). 진화 순서: 포켓몬 도감 진화 계열 기준. Pokémon GO의 사탕·아이템·시간·미구현 여부 등 구체적인 진화 조건은 별도로 확인해야 해. 분기 진화도 표시해. 그림자 선택 시 이미지는 일반형 자료를 사용할 수 있어.</p>';
}
function scoreClass(v){return v===3?'':v===2?'mid':v===1?'low':v===0?'low':String(v).includes('불가')?'off':'unknown'}
function grade(v){const text=Number.isInteger(v)?['☆☆☆','★☆☆','★★☆','★★★'][v]:v||'검증 필요';return `<span class="score ${scoreClass(v)}">${esc(text)}</span>`}
function rating(label,val,detail){return `<div class="rating"><div><b>${esc(label)}</b>${detail?`<small>${esc(detail)}</small>`:''}</div>${grade(val)}</div>`}
function panel(n,title,content,cls=''){return `<section class="panel ${cls}"><h3 class="sec-title"><b>${n}</b> ${esc(title)}</h3>${content}</section>`}
function percent(v){return Math.round(v.reduce((a,b)=>a+b,0)/45*100)}
function classification(p){const x=S.db.species[String(p.dex)]||{};const t=p.tags||[];if(t.includes('ultrabeast'))return '울트라비스트';if(x.mythical||t.includes('mythical'))return '환상의 포켓몬';if(x.legendary||t.includes('legendary'))return '전설의 포켓몬';return '일반 포켓몬'}
function mainForm(p,kind){
  if(kind==='shadow')return S.byId.get(p.id.endsWith('_shadow')?p.id:p.id+'_shadow')||null;
  if(kind==='mega'||kind==='primal'){
    let variants=(S.byDex.get(p.dex)||[]).filter(x=>x.id.includes(kind==='mega'?'_mega':'_primal'));
    // Mega/Primal on a final evolution often belongs to a different Dex than the input.
    return variants[0]||null;
  }
  return p;
}
function familyMembers(stages,kind){const fam=stages.flatMap(s=>s.pokemons.flatMap(d=>S.byDex.get(d)||[]));
  return fam.filter(p=>p.released!==false&& !p.id.includes('_mega')&&!p.id.includes('_primal')&&!p.id.includes('_gigantamax')&&(kind==='shadow'?p.id.includes('_shadow'):!p.id.includes('_shadow')));
}
function findTransformation(stages,kind){const test=kind==='mega'?'_mega':'_primal';return stages.flatMap(s=>s.pokemons.flatMap(d=>S.byDex.get(d)||[])).filter(p=>p.id.includes(test));}
function leaguePokemon(fam,cap){const map=S.db.ranks[String(cap)]||{};return fam.map(p=>({p,r:map[p.id]})).filter(x=>x.r&&Number.isInteger(x.r.rank)).sort((a,b)=>a.r.rank-b.r.rank)[0]||null;}
function cp(base,iv,k){return Math.max(10,Math.floor((base.atk+iv[0])*Math.sqrt(base.def+iv[1])*Math.sqrt(base.hp+iv[2])*k*k/10));}
function sp(base,iv,cap){let left=0,right=CPM.length-1,found=-1;while(left<=right){const mid=(left+right)>>1;if(cp(base,iv,CPM[mid])<=cap){found=mid;left=mid+1}else right=mid-1;}if(found<0)return 0;const k=CPM[found];return (base.atk+iv[0])*k*(base.def+iv[1])*k*Math.floor((base.hp+iv[2])*k)}
function ivPlace(p,ivs,cap){if(!p.base)return null;const yours=sp(p.base,ivs,cap);if(!yours)return null;let better=0;for(let a=0;a<=15;a++)for(let d=0;d<=15;d++)for(let h=0;h<=15;h++){if(sp(p.base,[a,d,h],cap)>yours+1e-9)better++}return 1+better;}
function rankGrade(rank){if(rank<=60)return 3;if(rank<=200)return 2;if(rank<=450)return 1;return 0}
function pvpAnalysis(p,kind,stages,ivs){
  if(p.dex===132)return {html:['슈퍼리그','하이퍼리그','마스터리그'].map(x=>rating(x,'참가 불가','메타몽은 GO배틀리그에 참여할 수 없어.')).join(''),best:null};
  if(['mega','primal'].includes(kind))return {html:['슈퍼리그','하이퍼리그','마스터리그'].map(x=>rating(x,'참가 불가','메가·원시 변신 상태로 일반 GO배틀리그는 참가할 수 없어. 특별 규칙 예외.')).join(''),best:null};
  let fam=familyMembers(stages,kind),all=[],html='';
  for(const [label,cap] of [['슈퍼리그',1500],['하이퍼리그',2500],['마스터리그',10000]]){
    const match=leaguePokemon(fam,cap);if(!S.full||!Object.keys(S.db.ranks[String(cap)]||{}).length){html+=rating(label,'최신 검증 필요','검증된 PvPoke 순위 데이터가 아직 없어.');continue;}
    if(!fam.length){html+=rating(label,'최신 검증 필요','현재 선택한 형태의 게임 데이터가 확인되지 않아.');continue;}
    if(!match){html+=rating(label,0,'공개 종합랭킹에서 해당 진화체·형태가 확인되지 않아.');continue;}
    const place=cap===10000?null:ivPlace(match.p,ivs,cap);const g=rankGrade(match.r.rank);
    const detail=`${speciesName(match.p.dex)}${kind==='shadow'?' (그림자)':''} · PvPoke ${match.r.rank}위`+(place?` · IV 스탯곱 ${place}/4096위`:cap===10000?' · 공격·방어·체력 고개체 권장':'');
    html+=rating(label,g,detail);
    all.push({label,cap,grade:g,rank:match.r.rank,p:match.p,ivPlace:place,moves:match.r.moves});
  }
  return {html,best:all.sort((a,b)=>b.grade-a.grade||a.rank-b.rank)[0]||null,all};
}
function normalizeMove(s){return String(s||'').trim().toLowerCase();}
function moveLabel(move){return LABELS[move]||String(move||'').replaceAll('_',' ').toLowerCase().replace(/\b[a-z]/g,c=>c.toUpperCase());}
function raidPotential(p,kind,ivs){
  const raid=S.db.raid;
  if(!S.full||!raid?.available||S.db.raid_source_stale)return null;
  const baseVariant=kind==='mega'||kind==='primal'?p:null;
  const sets=raid.learnsets||{};
  const learn=sets[`${p.dex}:normal`]||Object.entries(sets).find(([k])=>k.startsWith(p.dex+':')&&k.endsWith(':normal'))?.[1];
  if(!learn||!p.base)return null;
  let best=null;
  const moves1=[...new Set([...(learn.fast||[]),...(learn.elite_fast||[])])];
  const moves2=[...new Set([...(learn.charge||[]),...(learn.elite_charge||[])])];
  for(const fastName of moves1){const f=raid.fast[normalizeMove(fastName)];if(!f||f.energy<=0||f.ms<=0)continue;
    for(const chName of moves2){const c=raid.charged[normalizeMove(chName)];if(!c||c.energy>=0||c.ms<=0)continue;
      const num=Math.max(1,Math.ceil(Math.abs(c.energy)/f.energy));
      const stab1=(p.types||[]).includes(f.type)?1.2:1;
      const stab2=(p.types||[]).includes(c.type)?1.2:1;
      const dps=((num*f.power*stab1)+(c.power*stab2))/(num*f.ms+c.ms)*1000;
      const atkFactor=((p.base?.atk||0)+ivs[0])*(kind==='shadow'?1.2:1);
      const score=dps*atkFactor/100;
      if(!best||best.score<score)best={score,fast:fastName,charged:chName,skillType:c.type,elite:(learn.elite_fast||[]).includes(fastName)||(learn.elite_charge||[]).includes(chName)};
    }
  }
  return best;
}
let cachedRaidMax=null;
function raidMaxForType(type){if(!S.full||!S.db.raid.available)return 0;if(!cachedRaidMax)cachedRaidMax=new Map();if(cachedRaidMax.has(type))return cachedRaidMax.get(type);
 let top=0;
 for(const p of S.db.pokemon){if(!p.base||p.released===false||p.id.includes('_shadow')||p.id.includes('_mega')||p.id.includes('_primal'))continue;
   if(!(p.types||[]).includes(type))continue;
   const r=raidPotential(p,'normal',[15,15,15]);if(r&&r.skillType===type)top=Math.max(top,r.score);
 }
 cachedRaidMax.set(type,top);return top;
}
function raidSection(p,kind,stages,ivs){
  const family=stages.flatMap(s=>s.pokemons.flatMap(d=>S.byDex.get(d)||[]));
  let candidates=[];
  if(kind==='mega'||kind==='primal'){
    candidates=findTransformation(stages,kind).filter(x=>x.released!==false);
    if(!candidates.length)return {html:rating('레이드','최신 검증 필요','선택한 진화 계열에서 메가·원시 형태를 확인하지 못함. 해당 형태를 실제로 사용할 수 있는지 먼저 확인해.'),grade:null};
  }else if(kind==='shadow'){
    candidates=family.filter(x=>x.released!==false&&x.id.endsWith('_shadow'));
    if(!candidates.length)return {html:rating('레이드','최신 검증 필요','해당 계열에서 확인된 그림자 형태가 없어. 일반형 성능을 그대로 적용하지 않아.'),grade:null};
  }else{
    candidates=family.filter(x=>x.released!==false&&!x.id.includes('_shadow')&&!x.id.includes('_mega')&&!x.id.includes('_primal')&&!x.id.includes('_gigantamax'));
  }
  const found=candidates.map(p=>({p,score:raidPotential(p,kind,ivs)})).filter(x=>x.score).sort((a,b)=>b.score.score-a.score.score)[0];
  if(!found)return {html:rating('레이드','최신 검증 필요','사용 가능한 최신 PvE 기술 데이터가 없거나 해당 형태의 기술·시간 데이터가 부족해.'),grade:null};
  const assess=found.p,score=found.score;
  const max=raidMaxForType(score.skillType);const rel=max?score.score/max:null;
  if(!rel||!Number.isFinite(rel))return {html:rating('레이드','최신 검증 필요','동일 타입 비교군 자료 부족.'),grade:null};
  // Heuristic normalized to strongest ordinary-form attacker; NOT raid DPS/TDO simulation.
  const g=rel>=.84?3:rel>=.67?2:rel>=.45?1:0;
  const caution=score.elite?' · 이벤트/대단한 기술머신 확인 필요':'';
  return {html:rating('레이드 기본 화력 (추정)',g,`${speciesName(assess.dex)}${kind==='shadow'?' (그림자)':''} · ${TYPES[score.skillType]||score.skillType} 타입 최상위 일반형 추정 화력 대비 ${Math.round(rel*100)}%${caution}`),grade:g,
    note:'★ 표시는 기술 수치 기반 자체 추정 등급이며 실제 레이드 필수급 인증이 아니야. 보스별 상성, TDO·내구·회피, 날씨 및 메가 팀 버프 미반영. 특히 상위 비교군이 최신 게임 데이터인지 확인해야 해.',move:[score.fast,score.charged].map(moveLabel).join(' / ')};
}
function rocketSection(p,kind,ivs){
  const text=kind==='shadow'?'그림자 화력 보너스는 적용되지만 내구력이 낮아지고 화풀이 기술 제한이 있어.':'상대 포켓몬 타입·기술·실드와 편성에 따라 효율이 달라져.';
  const moves=S.db.pvp_moves||{};let spam='';
  if(S.full&&p.quick?.length&&p.charge?.length&&Object.keys(moves).length){
    const speed=p.quick.flatMap(f=>p.charge.map(c=>({f,c,quick:moves[f],charge:moves[c]})))
      .filter(x=>x.quick?.energyGain>0&&x.charge?.energy>0&&x.quick?.cooldown>0)
      .map(x=>({...x,turns:Math.ceil(x.charge.energy/x.quick.energyGain)*x.quick.cooldown})).sort((a,b)=>a.turns-b.turns)[0];
    if(speed)spam=`차징 기술 준비 시간 참고: ${moveLabel(speed.f)} / ${moveLabel(speed.c)} 약 ${speed.turns}턴(기술·실드·교체 상황에 따라 달라짐).`;
  }
  let target='';
  const advantages={normal:[],fire:['풀','얼음','벌레','강철'],water:['불꽃','땅','바위'],electric:['물','비행'],grass:['물','땅','바위'],ice:['풀','땅','비행','드래곤'],fighting:['노말','얼음','바위','악','강철'],poison:['풀','페어리'],ground:['불꽃','전기','독','바위','강철'],flying:['풀','격투','벌레'],psychic:['격투','독'],bug:['풀','에스퍼','악'],rock:['불꽃','얼음','비행','벌레'],ghost:['에스퍼','고스트'],dragon:['드래곤'],dark:['에스퍼','고스트'],steel:['얼음','바위','페어리'],fairy:['격투','드래곤','악']};
  if(S.full&&p.quick?.length&&Object.keys(moves).length){
    const options=p.quick.map(id=>({id,info:moves[id]})).filter(x=>x.info?.type&&x.info?.power);
    const candidate=options.sort((a,b)=>(b.info.power/(b.info.cooldown||1000))-(a.info.power/(a.info.cooldown||1000)))[0];
    if(candidate?.info?.type){const against=advantages[candidate.info.type]||[];if(against.length)target=`${moveLabel(candidate.id)} 기준 타입 상성상 ${against.join('·')} 상대에게 유리할 수 있어. 단, 개별 적 기술·내구·실드는 미반영.`;}
  }
  return {html:rating('조무래기','최신 검증 필요',target||text)+rating('리더 · 알로 / 시에라 / 클리프','최신 검증 필요','현재 편성·실드 제거 속도 및 상성 확인 전 확정 불가.')+rating('보스 · 비주기','최신 검증 필요','현재 보스 편성 및 대진 기술 확인 필요.'),note:[spam,target].filter(Boolean).join(' ')||'상대의 실제 기술·타입·편성 검증 전 판정 유보.'};
}
function maxSection(kind){if(kind==='dynamax'||kind==='gigantamax')return rating('맥스배틀','최신 검증 필요','기입한 개체가 해당 맥스 형태인지 확인해야 해. 맥스기술 위력·회복·방어 역할 및 종족 출시 여부의 검증 자료가 없어.');return rating('맥스배틀','참가 불가','선택한 개체가 별도의 맥스 능력을 갖지 않았다면 참가할 수 없어. 메가·원시는 맥스배틀에 적용되지 않아.');}
function verdict(pvp,raid,form,p){
  const best=pvp.best,rank=best?.rank,iv=best?.ivPlace;
  if(['mega','primal'].includes(form)&&!raid.grade)return {txt:'⏸️ 형태 검증 전 보류',note:'메가진화·원시회귀 구현 여부와 레이드 전용 성능 확인 후 투자해야 해.'};
  if(form==='shadow'&&!mainForm(p,form))return {txt:'⏸️ 그림자 형태 검증 필요',note:'현재 연결된 자료에서 해당 그림자 형태를 확인하지 못했어.'};
  if(best?.grade===3){
    if(best.cap===10000){if($('atk').value==='15'&&+($('def').value)>=14&&+($('hp').value)>=14)return {txt:'✅ 고개체 육성 추천',note:'마스터리그 상위권 종족과 높은 개체값이 확인돼. 기술·사탕XL 투자 전 최종 검증해.'};return {txt:'⚖️ 고개체 재검토',note:`${best.label} ${rank}위 종족이지만 최적 개체값이 중요해. 현재 개체의 육성은 조건부야.`};}
    if(iv!==null&&iv<=250)return {txt:'✅ PvP 육성 추천',note:`${best.label} ${rank}위·스탯곱 ${iv}/4096위. 실제 팀 조합과 기술을 확인해.`};
    return {txt:'⚖️ 종족은 우수 · IV 검토',note:`${best.label} ${rank}위지만 현재 개체의 PvP 스탯곱 순위는 ${iv||'미확인'}위야.`};
  }
  if(raid.grade===3 && S.db.raid?.available)return {txt:'⚖️ 레이드 화력 유망',note:'자체 화력 추정치가 높아. 실제 보스별 시뮬레이션을 검증하기 전에는 대규모 투자를 보류해.'};
  if(best?.grade===2)return {txt:'⚖️ 조건부 육성',note:`${best.label} PvPoke ${rank}위. 개체값과 파티 상성을 확인해.`};
  if(!S.full)return {txt:'⏸️ 정식 데이터 갱신 필요',note:'현재는 오프라인 시연용 도감 자료만 있어. IV·진화 이미지는 확인할 수 있지만 메타 등급은 확정할 수 없어.'};
  return {txt:'⏸️ 육성 보류',note:'공개 랭킹 및 가용 자료만으로 별의모래·XL사탕 투자 필요성이 확인되지 않았어.'};
}
function render(name,form,ivs){
  const p=findPokemon(name),pct=percent(ivs);
  if(!p){$('result').innerHTML=`<section class="panel"><h3>포켓몬을 찾지 못했어</h3><p class="smallnote">${esc(name)} · 현재 데이터에 한국어 이름이 없거나 도감이 갱신되지 않았을 수 있어. 상단에서 업데이트를 확인하고 다시 검색해 줘. 도감 전체 자료가 없더라도 IV는 ${ivs.join('/')} = ${pct}%야.</p></section>`;return;}
  const stages=getLine(p),type=p.types?.filter(t=>t!=='none').map(t=>TYPES[t]||t).join(' · ')||'타입 자료 없음';
  const title=speciesName(p.dex),cls=classification(p);
  const current = mainForm(p,form),f= current||p;
  const pvp=pvpAnalysis(p,form,stages,ivs), raid=raidSection(p,form,stages,ivs), rocket=rocketSection(f,form,ivs);
  const decision=verdict(pvp,raid,form,p);
  const moves=pvp.best?.moves?.length?pvp.best.moves.map(moveLabel).join(' / '):(raid.move||'추천 기술 검증 필요');
  const typeNote=form==='shadow'?'그림자는 공격 피해 +20% · 받는 피해 +20% (보통의 전투 조건). 화풀이 제거 이벤트 확인 필요.':form==='purified'?'정화 후 개체값을 그대로 사용해. 일반형 전투 성능 기준으로 비교하고 은혜갚기는 별도 확인.':form==='dynamax'||form==='gigantamax'?'개체가 해당 맥스 능력을 실제로 보유하는지 먼저 확인해야 해. 일반 포켓몬이 자동으로 전환되지는 않아.':form==='mega'||form==='primal'?'메가·원시는 전투 중 활용 형태이며 일반 GO배틀리그에서는 통상 사용 불가. 실제 변신 가능 종족인지 확인해야 해.':'일반 포켓몬 기준. 전투 중 맥스 변신 불가.';
  let hero=`<section class="panel"><div class="pk-hero">${img(p.dex,title)}<div><h2>${esc(title)}</h2><div class="dex">도감 #${p.dex}</div><div class="badges"><span class="tag">${esc(cls)}</span><span class="tag">${esc(type)}</span><span class="tag">${esc(KINDS[form])}</span></div></div></div><div class="ivmeter"><div><small>현재 IV · 공 / 방 / 체</small><b>${ivs.join(' / ')}</b><div class="meter"><i style="width:${pct}%"></i></div></div><div><small>합계 ${ivs.reduce((a,b)=>a+b)}/45</small><strong>${pct}%</strong></div></div><div class="info">${esc(typeNote)}</div></section>`;
  let skillContent=`<p class="smallnote">${esc(moves)}</p>`+(pvp.best?`<p class="smallnote">기준: ${esc(pvp.best.label)} · ${esc(speciesName(pvp.best.p.dex))} · 이벤트/대단한 기술머신 필요 여부 별도 확인</p>`:'');
  S.voiceText=`${title}. 개체값 ${pct}퍼센트. ${decision.txt}. ${decision.note}`;
  let sourceTime=S.full?(S.db.generated_at||'갱신 시각 확인 불가'):'정식 데이터 미연결';
  $('result').innerHTML=hero+
    panel('02','진화 순서 · 이미지 계보',evoView(stages,p.dex,form),'evo-panel')+
    panel('03','레이드',raid.html+(raid.note?`<p class="smallnote">${esc(raid.note)}</p>`:''))+
    panel('04','GO배틀리그',pvp.html+'<p class="smallnote">PvPoke 전체 리그 종족 순위는 팀 시너지나 실제 승률을 보장하지 않아. 스탯곱 IV 순위는 레벨 50·CP 제한 기준의 근사 계산이며 최소 포획 레벨·베스트 파트너 등을 제외해.</p>')+
    panel('05','GO로켓단',rocket.html+`<p class="smallnote">${esc(rocket.note)}</p>`)+
    panel('06','맥스배틀',maxSection(form))+
    panel('07','추천 기술',skillContent)+
    `<section class="panel decision-panel"><h3 class="sec-title"><b>08</b> 최종 육성 판정</h3><div class="decision">${esc(decision.txt)}</div><p>${esc(decision.note)}</p><p class="smallnote">투자 관점: 검증된 메타 자료와 보유 IV를 구분하고, 근거가 부족하면 보류해. 실제 레이드 보스별 결과와 리더 로테이션은 별도 검증이 필요해.</p><div class="summarylist"><span>${esc(cls)}</span><span>${esc(KINDS[form])}</span><span>IV ${pct}%</span></div><div class="sources">게임 데이터: ${esc(sourceTime)} · PvPoke GM: ${esc(S.db.pvpoke_timestamp||'시각 미표기')}<br>레이드: ${esc(S.db.raid?.available?'PoGoAPI 기술 데이터 기반 추정':'전용 데이터 없음')} · 로켓단 로테이션/맥스배틀: 검증 필요</div><button type="button" class="listen" id="readBtn">🔊 결과 읽어주기</button></section><div id="aiExtra"></div>`;
  $('readBtn').addEventListener('click',()=>speak(S.voiceText));
  if($('voiceToggle').checked)speak(S.voiceText);
  if($('aiToggle').checked)showAIExplanation(name,form,ivs);
}
function speak(t){
  if(!('speechSynthesis'in window)){alert('이 기기/브라우저는 음성 읽기를 지원하지 않아.');return;}
  try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ko-KR';u.rate=1;u.pitch=1;speechSynthesis.speak(u);}catch(err){console.warn('TTS disabled',err)}
}
async function showAIExplanation(name,form,ivs){
  const mount=$('aiExtra');if(!mount)return;
  mount.innerHTML=panel('✦','AI 추가 설명','<p class="smallnote">선택 기능 확인 중…</p>','ai-out');
  // Optional server only; never block deterministic results or place keys in browser.
  try{
    const r=await fetch('./api/status',{cache:'no-store'});if(!r.ok)throw new Error('선택형 AI 서버 없음');
    const status=await r.json();if(!status.ai_enabled)throw new Error('AI 서버 미설정');
    const ac=new AbortController(),t=setTimeout(()=>ac.abort(),45000);let res;
    try{res=await fetch('./api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,form,atk:ivs[0],def:ivs[1],hp:ivs[2]}),signal:ac.signal})}finally{clearTimeout(t)}
    if(!res.ok)throw new Error('AI 서버 응답 실패');const data=await res.json();
    const a=data.analysis||{};mount.innerHTML=panel('✦','AI 추가 설명',`<p class="smallnote">${esc(a.reason||a.explanation||'추가 설명 없음')}</p><p class="smallnote">AI 설명은 참고용이며, 위 데이터 기반 판정을 바꾸지 않아.</p>`,'ai-out');
  }catch(e){mount.innerHTML=panel('✦','AI 추가 설명',`<p class="smallnote">선택형 AI 서버가 연결되지 않았어. 데이터 기반 분석은 정상 작동해. (${esc(e.message)})</p>`,'ai-out');}
}
function handleSubmit(e){e?.preventDefault();const name=$('pkname').value.trim(),kind=document.querySelector('input[name="form"]:checked')?.value||'normal';
  const ivs=['atk','def','hp'].map(k=>Number($(k).value));
  if(!name)return alert('포켓몬 이름을 입력해.');
  if(['atk','def','hp'].some(k=>$(k).value==='')||ivs.some(v=>!Number.isInteger(v)||v<0||v>15))return alert('공격·방어·체력은 각각 0~15 정수로 입력해야 해.');
  render(name,kind,ivs);$('result').scrollIntoView({behavior:'smooth',block:'start'});
}
function setSync(msg,sub,ok='wait'){$('syncText').textContent=msg;$('syncMeta').textContent=sub||'';$('syncDot').className='live-dot '+(ok==='ok'?'ok':ok==='error'?'warn':'');}
function activate(db){S.db=db;S.full=!db.sample;indexCatalog();cachedRaidMax=null;
  if(S.full){const age=Date.now()-Date.parse(db.generated_at||'');const old=Number.isFinite(age)&&age>8*86400000;const source=String(db.pvpoke_timestamp||'원본 일자 미확인');setSync(old?'저장된 데이터 · 최신성 재확인 필요':'검증된 게임 데이터 사용 중',`DB 생성 ${String(db.generated_at||'시각 정보 없음').slice(0,16).replace('T',' ')} UTC · PvPoke 원본 ${source} · ${db.pokemon.length}개 형태`,old?'wait':'ok');}
  else setSync('오프라인 시연용 도감 데이터','정식 전체 데이터가 아직 배포되지 않았어. 리그·레이드 등급은 보류해.','wait');
}
async function checkUpdates(manual=false){
  if(location.protocol==='file:'||location.protocol==='content:'){setSync('로컬 시연 모드','content:// 또는 file:// 파일 열기 상태에서는 원격 자동 갱신 불가 · HTTPS 배포 필요','wait');return;}
  const endpoint='./data/catalog.json?v='+Math.floor(Date.now()/3600000);
  if(manual){$('refreshBtn').disabled=true;setSync('최신 자료 확인 중…','새 데이터가 검증되면 반영해.');}
  try{
    const ctrl=new AbortController();const timeout=setTimeout(()=>ctrl.abort(),17000);let r;
    try{r=await fetch(endpoint,{cache:'no-store',signal:ctrl.signal})}finally{clearTimeout(timeout)}
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const payload=await r.json();if(!validCatalog(payload)||payload.sample||payload.pokemon.length<700)throw new Error('정식 데이터 검증 실패');
    if(!S.full||String(payload.generated_at)>String(S.db.generated_at))activate(payload);
    try{localStorage.setItem('pogo.meta.catalog.v4',JSON.stringify(payload));}catch{}
    setSync('검증된 데이터 동기화 완료',`DB ${String(payload.generated_at).slice(0,16).replace('T',' ')} UTC · PvPoke 기준 ${payload.pvpoke_timestamp||'확인 불가'} · 이전 자료 보관 가능`,'ok');
  }catch(e){if(S.full)setSync('저장된 검증 데이터 사용 중',`최신 확인 실패 (${e.message}). 이전 자료를 유지해.`,'wait');
    else setSync('정식 데이터 아직 연결되지 않음',`업데이트 파일 없음/오류 (${e.message}). GitHub Actions 첫 실행 또는 배포 필요.`,'wait');}
  finally{$('refreshBtn').disabled=false;}
}
function init(){
  if(validCatalog(S.db))activate(S.db);
  try{const previous=JSON.parse(localStorage.getItem('pogo.meta.catalog.v4')||'null');if(validCatalog(previous)&&!previous.sample&&previous.pokemon.length>=700)activate(previous);}catch{}
  $('form').addEventListener('submit',handleSubmit);
  $('refreshBtn').addEventListener('click',()=>checkUpdates(true));
  document.querySelectorAll('input[name="form"]').forEach(n=>n.addEventListener('change',()=>{$('formHint').textContent=HINTS[n.value];}));
  document.querySelectorAll('.examples button').forEach(n=>n.addEventListener('click',()=>{const nums=n.dataset.ivs.split(',');$('pkname').value=n.dataset.pokemon;['atk','def','hp'].forEach((x,i)=>$(x).value=nums[i]);$('form').requestSubmit();}));
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();S.installedPrompt=e;$('installBtn').hidden=false;});
  $('installBtn').addEventListener('click',async()=>{if(S.installedPrompt){S.installedPrompt.prompt();await S.installedPrompt.userChoice;S.installedPrompt=null;$('installBtn').hidden=true;}});
  checkUpdates();
  if('serviceWorker'in navigator && (location.protocol==='https:'||location.hostname==='localhost'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
init();
})();
